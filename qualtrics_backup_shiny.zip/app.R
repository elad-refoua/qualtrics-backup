## ===========================================================================
## app.R
## ---------------------------------------------------------------------------
## Shiny user interface for the Qualtrics backup tool.
##
## Purpose
## -------
## Provide a safe, GUI-driven way to run the backup without ever persisting
## the API token to disk, and without requiring the user to edit any file.
##
## What the user does
## ------------------
##   1. Paste an API token (hidden input).
##   2. Pick / edit the output folder.
##   3. Click "Test connection" to verify the token and see the survey list.
##   4. Pick which surveys to back up (or leave "all" selected).
##   5. Click "Start backup". Watch the progress bar + live log.
##   6. Click "Open output folder" to inspect the result.
##
## Security model
## --------------
##   - Token is held ONLY in a `reactiveVal` inside the Shiny session.
##   - Token is NEVER written to any file, NEVER appended to the log area,
##     NEVER shown in the browser after the initial paste.
##   - App binds to 127.0.0.1 (localhost) only - the launcher (run_app.R)
##     enforces this. No one on the network can reach this UI.
##   - A "Clear session" button zeroes the token reactive on demand.
##   - On session end (browser close), the reactive is garbage-collected.
##
## Architecture
## ------------
## The app is a thin shell over run_backup_session() in qualtrics_backup.R.
## All heavy logic (API calls, file writes, schema construction) lives in
## the library. This file is purely UI + orchestration + log plumbing.
##
## Author: Elad Refoua + Claude Code
## ===========================================================================


## ==== 1. Dependencies ======================================================
## Shiny is required. bslib / DT are optional niceties.

required_shiny <- c("shiny")
missing_shiny <- character()
for (pkg in required_shiny) {
  if (!suppressWarnings(suppressMessages(
    require(pkg, character.only = TRUE, quietly = TRUE)
  ))) {
    missing_shiny <- c(missing_shiny, pkg)
  }
}
if (length(missing_shiny) > 0) {
  stop(
    "The Shiny app needs these packages: ",
    paste(missing_shiny, collapse = ", "),
    "\nInstall with: install.packages(c(",
    paste(shQuote(missing_shiny), collapse = ", "), "))",
    call. = FALSE
  )
}


## ==== 2. Source the backup library =========================================
## We source the library file so all functions (run_backup_session,
## list_surveys, connect_account, etc.) are available in the app's env.
## The library file has a guard (`if (sys.nframe() == 0L) main()`) that
## prevents main() from auto-running when sourced.
source("qualtrics_backup.R", local = FALSE)


## ==== 3. Small helpers =====================================================

## Null-coalesce used in the server code. Defined here (not relying on the
## library's copy) so this file is source()-robust even if the library changes.
`%||%` <- function(a, b) if (is.null(a) || length(a) == 0) b else a

## Open a folder in the OS's file manager. Uses safe, shell-free invocations.
##   Windows: shell.exec() opens Explorer (no shell interpolation).
##   macOS:   system2("open", path) - execve-style, no shell.
##   Linux:   system2("xdg-open", path) - execve-style, no shell.
open_folder_in_explorer <- function(path) {
  path <- normalizePath(path, winslash = "\\", mustWork = FALSE)
  if (.Platform$OS.type == "windows") {
    shell.exec(path)
  } else if (Sys.info()[["sysname"]] == "Darwin") {
    system2("open", path)
  } else {
    system2("xdg-open", path)
  }
}


## ==== 4. UI definition =====================================================

## Safety banner shown at the top of every page load.
safety_banner <- tags$div(
  style = paste(
    "background: #fff3cd; border-left: 5px solid #f5c518;",
    "padding: 10px 16px; margin-bottom: 20px; border-radius: 4px;",
    "font-size: 14px;"
  ),
  tags$strong("Security reminder: "),
  "Your Qualtrics API token is entered here and held only in this Shiny ",
  "session. It is NEVER written to disk or logs. Do not screenshot the ",
  "page while the token is entered. Close the browser tab when done."
)

ui <- fluidPage(
  title = "Qualtrics Backup",

  tags$head(tags$style(HTML("
    body { font-family: 'Segoe UI', Arial, sans-serif; max-width: 1000px;
           margin: 1em auto; padding: 0 1em; }
    h2 { color: #336; }
    .card { border: 1px solid #ddd; border-radius: 6px; padding: 16px 20px;
            margin-bottom: 18px; background: #fafafa; }
    .card h3 { margin-top: 0; color: #336; font-size: 18px; }
    #log-area { background: #1e1e1e; color: #d4d4d4; padding: 10px 14px;
                border-radius: 4px; font-family: 'Consolas', monospace;
                font-size: 13px; height: 260px; overflow-y: auto;
                white-space: pre-wrap; }
    .log-info { color: #58a6ff; }
    .log-success { color: #56d364; }
    .log-warning { color: #f0b429; }
    .log-danger { color: #ff7b72; }
    .status-ok { color: #2a7a2a; font-weight: 500; }
    .status-err { color: #b94a48; font-weight: 500; }
    details.help { background: #fff; border: 1px solid #cfd8ea;
                   border-radius: 6px; padding: 10px 16px; margin: 10px 0; }
    details.help summary { cursor: pointer; font-weight: 600; color: #336; }
    details.help ol, details.help ul { margin: 8px 0 4px; }
    details.help li { margin: 4px 0; }
    .picker-box { max-height: 340px; overflow-y: auto; background: #fff;
                  border: 1px solid #ddd; border-radius: 4px;
                  padding: 8px 12px; }
    .picker-count { color: #666; font-size: 13px; margin: 6px 0; }
  ")),
  ## Receive streamed log lines DURING a run. Shiny's normal reactive flush
  ## waits until the observer returns; this custom handler paints each line
  ## the moment the server sends it, so the 'Live log' is genuinely live.
  tags$script(HTML("
    Shiny.addCustomMessageHandler('append_log_line', function(msg) {
      var area = document.getElementById('log-area');
      if (!area) return;
      var line = document.createElement('div');
      line.innerHTML = msg.html;
      area.appendChild(line);
      area.scrollTop = area.scrollHeight;
    });
  "))),

  tags$h2("Qualtrics backup tool"),
  tags$p("Download every survey + response from a Qualtrics account into a ",
         "local open-format archive. ", tags$em("Read-only on Qualtrics.")),

  safety_banner,

  ## ---- Beginner help: what this tool does + what you get -----------------
  tags$details(class = "help",
    tags$summary("What does this tool do? What will I get? (click - written for someone who knows almost nothing)"),
    tags$p("This tool connects to your Qualtrics account, and for every survey ",
           "you pick it downloads EVERYTHING into one folder on your computer:"),
    tags$ul(
      tags$li(tags$strong("The questionnaire itself"), " - a preview file ",
              "(preview.html) that looks like the real survey and opens in any ",
              "browser with no internet, plus a Word version (preview.docx)."),
      tags$li(tags$strong("All the answers people gave"), " - as numbers ",
              "(for SPSS/R) and as the exact text respondents clicked ",
              "(responses_labels, also as an Excel file)."),
      tags$li(tags$strong("A QSF file"), " - QSF is Qualtrics' own survey ",
              "format. If your survey is ever deleted, you can restore a ",
              "working copy: in Qualtrics choose Create New Project > Survey > ",
              "Import a QSF file and select this file."),
      tags$li(tags$strong("A codebook"), " - a table that says which number in ",
              "the data means which answer (e.g. 1 = 'strongly disagree')."),
      tags$li(tags$strong("A portable open-format copy"), " - so the survey ",
              "can be rebuilt outside Qualtrics (REDCap, LimeSurvey, etc.).")
    ),
    tags$p("After the backup finishes, open the file ", tags$code("_index.html"),
           " in the output folder - it lists every survey with links to all ",
           "of these files, plus a full glossary. Everything works offline. ",
           "The tool only READS from Qualtrics - it never changes or deletes ",
           "anything in your account.")
  ),

  ## ---- Card 1: Connection -----------------------------------------------
  tags$div(class = "card",
    tags$h3("1. Connect"),
    fluidRow(
      column(6,
        textInput("base_url",
                  "Qualtrics base URL (no https://)",
                  value = "biusocialsciences.eu.qualtrics.com",
                  width = "100%")
      ),
      column(6,
        textInput("account_label",
                  "Account label (for the output subfolder)",
                  value = "ISF",
                  width = "100%")
      )
    ),
    passwordInput("api_token",
                  "API token (hidden - paste from Qualtrics > Account Settings > Qualtrics IDs > API)",
                  width = "100%"),

    ## ---- Beginner help: how to get an API token + find your base URL -----
    tags$details(class = "help",
      tags$summary("How do I get my API token? And what is the base URL? (click for step-by-step)"),
      tags$p(tags$strong("What is an API token?"), " A private key (a long ",
             "string of letters and numbers) that lets this tool read the ",
             "surveys of YOUR Qualtrics account. It is like a password - do ",
             "not email it or share it. This app keeps it only in memory and ",
             "never saves it to disk."),
      tags$p(tags$strong("Getting your token (2 minutes):")),
      tags$ol(
        tags$li("Log into Qualtrics in your browser."),
        tags$li("Click your account icon (top-right corner) and choose ",
                tags$strong("Account Settings"), "."),
        tags$li("In the left sidebar click ", tags$strong("Qualtrics IDs"), "."),
        tags$li("Find the box named ", tags$strong("API"), ". If a token is ",
                "already shown, copy it. If not, click ",
                tags$strong("Generate Token"), " and copy the result."),
        tags$li("Paste it into the token field above.")
      ),
      tags$p(tags$em("No 'Generate Token' button?"), " Your institution's ",
             "Qualtrics administrator has to enable API access for your ",
             "account - ask them."),
      tags$p(tags$strong("What is the base URL?"), " The address of your ",
             "institution's Qualtrics server. Look at your browser's address ",
             "bar while logged into Qualtrics: it looks like ",
             tags$code("something.qualtrics.com"), " (for example ",
             tags$code("biusocialsciences.eu.qualtrics.com"), "). Type that ",
             "part - without https:// - into the base URL field above. ",
             "You can also find it under Account Settings > Qualtrics IDs ",
             "in the 'User' box (Datacenter ID)."),
      tags$p(tags$strong("Rotating (replacing) a token:"), " generating a new ",
             "token in Qualtrics invalidates the old one - do that if you ",
             "ever suspect the token leaked.")
    ),

    actionButton("test_conn", "Test connection & list surveys",
                 class = "btn-primary"),
    actionButton("clear_token", "Clear token from session",
                 class = "btn-default",
                 style = "margin-left: 10px;"),
    tags$div(id = "conn-status", style = "margin-top: 10px;",
             textOutput("conn_status_text"))
  ),

  ## ---- Card 2: Output options -------------------------------------------
  tags$div(class = "card",
    tags$h3("2. Output"),
    textInput("backup_root",
              "Backup root folder (subfolders for account/date go under this)",
              value = file.path(path.expand("~"), "Qualtrics Backups"),
              width = "100%"),
    fluidRow(
      column(6,
        textInput("survey_filter",
                  "Optional survey-name regex filter (e.g. 'study 2.*BQ')",
                  value = "", width = "100%")
      ),
      column(6,
        sliderInput("politeness_delay",
                    "API politeness delay (seconds between calls)",
                    min = 0, max = 3, value = 0.5, step = 0.1)
      )
    ),
    fluidRow(
      column(4, checkboxInput("skip_empty",
                              "Skip empty surveys (zero responses)",
                              value = FALSE)),
      column(4, checkboxInput("resume",
                              "Resume mode (skip already-done surveys)",
                              value = TRUE)),
      column(4, checkboxInput("encrypt_output",
                              "Encrypt final folder (AES-256)",
                              value = FALSE))
    ),
    conditionalPanel(
      condition = "input.encrypt_output == true",
      passwordInput("encryption_passphrase",
                    "Encryption passphrase (required if encryption is on)",
                    width = "100%")
    )
  ),

  ## ---- Card 3: Survey picker (conditional on successful test) -----------
  conditionalPanel(
    condition = "output.have_surveys == true",
    tags$div(class = "card",
      tags$h3("3. Pick surveys to back up"),
      tags$p("All surveys are selected by default. Uncheck any you want to ",
             "exclude from this run. Surveys are sorted alphabetically."),
      textInput("picker_search", NULL,
                placeholder = "Type to filter the list (does not change your selection)...",
                width = "60%"),
      tags$div(class = "picker-count", textOutput("picker_count", inline = TRUE)),
      tags$div(class = "picker-box", uiOutput("survey_picker_ui")),
      fluidRow(
        column(6, actionButton("select_all", "Select all (shown)")),
        column(6, actionButton("deselect_all", "Deselect all (shown)"))
      )
    )
  ),

  ## ---- Card 4: Run --------------------------------------------------------
  tags$div(class = "card",
    tags$h3("4. Run backup"),
    actionButton("run_backup", "Start backup",
                 class = "btn-success",
                 icon = icon("play")),
    tags$div(style = "margin-top: 14px;",
      uiOutput("progress_ui")
    ),
    tags$h4("Live log"),
    htmlOutput("log_area")
  ),

  ## ---- Card 5: Results (conditional on a completed run) -----------------
  conditionalPanel(
    condition = "output.have_result == true",
    tags$div(class = "card",
      tags$h3("5. Result"),
      uiOutput("result_summary"),
      actionButton("open_folder", "Open output folder",
                   class = "btn-primary")
    )
  ),

  tags$hr(),
  tags$div(style = "font-size: 12px; color: #666; margin-top: 1em;",
    ## Plain text (not links): Shiny only serves files from a www/ folder,
    ## so linking the docs here would 404.
    "Qualtrics Backup Tool - full documentation in the README.md and ",
    "PROJECT.md files inside the app folder."
  )
)


## ==== 5. Server logic ======================================================

server <- function(input, output, session) {

  ## ---- Reactive state ----------------------------------------------------
  ## The token is held in a reactiveVal so it's scoped to this session only.
  rv_token <- reactiveVal(NULL)
  rv_base_url <- reactiveVal(NULL)   # snapshotted WITH the token at test time
  rv_surveys <- reactiveVal(NULL)
  rv_selected <- reactiveVal(character())  # selection survives list filtering
  rv_log <- reactiveVal(character())
  rv_progress <- reactiveValues(current = 0, total = 0, name = NULL)
  rv_conn_status <- reactiveVal("")
  rv_result <- reactiveVal(NULL)
  rv_running <- reactiveVal(FALSE)   # re-entry guard for Start backup

  ## ---- Helpers -----------------------------------------------------------

  ## Append a log line with a severity class. Also streams the line to the
  ## browser IMMEDIATELY via a custom message - Shiny's normal reactive
  ## flush waits until the whole backup observer returns, which made the
  ## 'Live log' effectively dead during a run.
  append_log <- function(level, message) {
    ## Sanitize: tokens are 40+ alphanumeric chars - redact any such substring
    ## defensively, on top of the fact that we never pass the token to log.
    safe_msg <- gsub("[A-Za-z0-9]{35,}", "[REDACTED]", message)
    safe_msg <- htmltools::htmlEscape(safe_msg)
    stamped  <- sprintf("%s [%s] %s",
                        format(Sys.time(), "%H:%M:%S"),
                        toupper(level), safe_msg)
    styled <- sprintf('<span class="log-%s">%s</span>', level, stamped)
    rv_log(c(rv_log(), styled))
    tryCatch(
      session$sendCustomMessage("append_log_line", list(html = styled)),
      error = function(e) NULL
    )
  }

  log_callback <- function(level, message) {
    append_log(level, message)
  }

  ## The backup-run progress callback. We create a Shiny Progress handle
  ## inside the run observer (so it's scoped to the run) and attach it here.
  ## shiny_progress is set to a Progress$new() just before the backup starts
  ## and nullified when the run finishes. Calls to its $set() method flush
  ## through Shiny's internal write queue - which is what makes the progress
  ## bar visibly update during the otherwise-blocking backup loop.
  shiny_progress <- NULL

  progress_callback <- function(current, total, survey_name) {
    rv_progress$current <- current
    rv_progress$total <- total
    rv_progress$name <- survey_name
    ## Forward to the Shiny progress handle so the browser updates live.
    if (!is.null(shiny_progress)) {
      tryCatch(
        shiny_progress$set(
          value = current / max(total, 1),
          message = sprintf("Backing up survey %d of %d", current, total),
          detail = survey_name
        ),
        error = function(e) NULL
      )
    }
  }

  ## ---- Outputs that drive conditional panels ----------------------------

  output$have_surveys <- reactive({
    !is.null(rv_surveys()) && nrow(rv_surveys()) > 0
  })
  outputOptions(output, "have_surveys", suspendWhenHidden = FALSE)

  output$have_result <- reactive({
    !is.null(rv_result())
  })
  outputOptions(output, "have_result", suspendWhenHidden = FALSE)

  output$conn_status_text <- renderText({ rv_conn_status() })

  ## ---- Test connection ---------------------------------------------------

  observeEvent(input$test_conn, {
    ## Trim both: pasted from an email/Slack/browser address bar, a token or
    ## base URL very easily carries an invisible leading/trailing space or
    ## newline, which breaks the connection with a generic "Unauthorized"
    ## and no hint that the copy-paste is the actual problem (same class of
    ## bug as the backup-root trailing-space fix below - see there for the
    ## reproduction).
    api_token <- trimws(input$api_token)
    base_url  <- trimws(input$base_url)
    req(nzchar(api_token), nzchar(base_url))

    ## Capture the token AND base URL into reactives together - the run must
    ## use the pair that was actually tested, not a base URL edited later.
    rv_token(api_token)
    rv_base_url(base_url)

    rv_conn_status("Connecting...")
    rv_log(character())
    append_log("info", sprintf("Testing connection to %s...", base_url))

    ## Validate the optional name filter BEFORE using it, so a broken regex
    ## is reported as a filter problem - not as "Connection failed".
    filter_regex <- if (nzchar(input$survey_filter)) input$survey_filter else NULL
    if (!is.null(filter_regex)) {
      regex_ok <- tryCatch({ grepl(filter_regex, ""); TRUE },
                           error = function(e) FALSE)
      if (!regex_ok) {
        rv_conn_status(sprintf(
          "The survey-name filter '%s' is not a valid regular expression - fix it or clear the field.",
          filter_regex))
        append_log("danger", "Invalid survey-name filter regex - connection not attempted.")
        return()
      }
    }

    ## Wrap in withProgress so the user sees a spinner / progress bar while
    ## the API calls happen. Without this, Shiny's single-threaded UI looks
    ## frozen during the (potentially multi-second) listing step.
    withProgress(message = "Connecting to Qualtrics", value = 0, {
      tryCatch({
        incProgress(0.2, detail = "Authenticating...")
        connect_account(rv_token(), base_url)

        incProgress(0.3, detail = "Fetching survey list...")
        ## FAST path: list surveys WITHOUT per-survey metadata (which would
        ## be N extra API calls). Response counts show as "?" in the picker.
        surveys <- list_surveys(filter_regex,
                                include_response_counts = FALSE)
        ## Alphabetical order makes a 90-survey list navigable.
        surveys <- surveys[order(tolower(surveys$name)), ]
        incProgress(0.5, detail = sprintf("Found %d surveys", nrow(surveys)))

        rv_surveys(surveys)
        rv_selected(surveys$id)   # all selected by default
        rv_conn_status(sprintf(
          "Connected. Found %d surveys (filter: %s).",
          nrow(surveys),
          if (is.null(filter_regex)) "none" else filter_regex
        ))
        append_log("success",
                   sprintf("Connected. %d surveys available.", nrow(surveys)))
      }, error = function(e) {
        rv_surveys(NULL)
        rv_conn_status(sprintf("Connection failed: %s", conditionMessage(e)))
        append_log("danger",
                   sprintf("Connection failed: %s", conditionMessage(e)))
      })
    })
  })

  ## ---- Clear token from session -----------------------------------------
  observeEvent(input$clear_token, {
    rv_token(NULL)
    rv_base_url(NULL)
    rv_surveys(NULL)
    rv_selected(character())
    updateTextInput(session, "api_token", value = "")
    ## connect_account() copies the token into qualtRics' env vars - clear
    ## those too, otherwise 'Clear token' leaves a live copy in the process.
    Sys.unsetenv(c("QUALTRICS_API_KEY", "QUALTRICS_BASE_URL"))
    rv_conn_status("Token cleared from session.")
    append_log("info", "Token cleared from session memory.")
  })

  ## ---- Survey picker -----------------------------------------------------
  ## The checkbox group shows only surveys matching the search box, but the
  ## SELECTION lives in rv_selected and survives filtering: hiding a survey
  ## does not deselect it.

  visible_surveys <- reactive({
    surveys <- rv_surveys()
    req(surveys)
    q <- tolower(trimws(input$picker_search %||% ""))
    if (nzchar(q)) {
      surveys <- surveys[grepl(q, tolower(surveys$name), fixed = TRUE), ]
    }
    surveys
  })

  output$survey_picker_ui <- renderUI({
    surveys <- visible_surveys()
    if (nrow(surveys) == 0) {
      return(tags$div(style = "color:#888;", "No surveys match the filter."))
    }
    ## Response counts are unknown by default (fast listing). Show "?" rather
    ## than misleading "0 responses". User can still pick any survey.
    count_label <- ifelse(
      is.na(surveys$response_count),
      "? responses",
      sprintf("%d responses", surveys$response_count)
    )
    choices <- setNames(
      surveys$id,
      sprintf("%s  [%s]", surveys$name, count_label)
    )
    checkboxGroupInput("selected_surveys", NULL,
                       choices = choices,
                       selected = intersect(rv_selected(), surveys$id))
  })

  ## Keep rv_selected in sync with checkbox changes on the VISIBLE subset:
  ## checked-visible ids are added, unchecked-visible ids are removed,
  ## hidden ids keep their previous state.
  observeEvent(input$selected_surveys, {
    vis <- visible_surveys()$id
    checked_vis <- intersect(input$selected_surveys %||% character(), vis)
    rv_selected(union(setdiff(rv_selected(), vis), checked_vis))
  }, ignoreNULL = FALSE)

  output$picker_count <- renderText({
    surveys <- rv_surveys()
    req(surveys)
    sprintf("%d of %d surveys selected (%d shown)",
            length(rv_selected()), nrow(surveys), nrow(visible_surveys()))
  })

  observeEvent(input$select_all, {
    vis <- visible_surveys()$id
    rv_selected(union(rv_selected(), vis))
    updateCheckboxGroupInput(session, "selected_surveys", selected = vis)
  })

  observeEvent(input$deselect_all, {
    vis <- visible_surveys()$id
    rv_selected(setdiff(rv_selected(), vis))
    updateCheckboxGroupInput(session, "selected_surveys",
                             selected = character(0))
  })

  ## ---- Progress UI ------------------------------------------------------

  output$progress_ui <- renderUI({
    if (rv_progress$total == 0) {
      return(tags$div(style = "color: #888;", "Not running yet."))
    }
    pct <- round(100 * rv_progress$current / rv_progress$total)
    tags$div(
      tags$div(sprintf("[%d / %d] %s",
                       rv_progress$current, rv_progress$total,
                       rv_progress$name %||% "")),
      tags$div(style = "background: #eee; border-radius: 4px; overflow: hidden; height: 20px; margin-top: 4px;",
        tags$div(style = sprintf(
          "background: #336; height: 100%%; width: %d%%; transition: width 0.3s;",
          pct
        ))
      ),
      tags$div(style = "font-size: 12px; color: #666; margin-top: 2px;",
               sprintf("%d%%", pct))
    )
  })

  ## ---- Log area ---------------------------------------------------------

  output$log_area <- renderUI({
    lines <- rv_log()
    if (length(lines) == 0) {
      return(tags$div(id = "log-area",
                      style = "color: #888;", "No log messages yet."))
    }
    tail_lines <- tail(lines, 500)
    tags$div(id = "log-area",
             HTML(paste(tail_lines, collapse = "<br>")))
  })

  ## ---- Run backup -------------------------------------------------------

  observeEvent(input$run_backup, {
    if (isTRUE(rv_running())) {
      append_log("warning",
                 "A backup is already running - ignoring the extra click.")
      return()
    }
    if (is.null(rv_token()) || !nzchar(rv_token())) {
      append_log("danger", "No token in session. Click 'Test connection' first.")
      return()
    }
    if (!nzchar(trimws(input$backup_root))) {
      append_log("danger", "Backup root folder is empty.")
      return()
    }
    if (is.null(rv_surveys()) || nrow(rv_surveys()) == 0) {
      append_log("danger", "No surveys available. Click 'Test connection' first.")
      return()
    }
    selected_ids <- rv_selected()
    if (is.null(selected_ids) || length(selected_ids) == 0) {
      append_log("danger", "No surveys selected.")
      return()
    }
    if (isTRUE(input$encrypt_output) &&
        (!nzchar(input$encryption_passphrase %||% ""))) {
      append_log("danger",
                 "Encryption is ON but passphrase is empty - aborting.")
      return()
    }

    rv_running(TRUE)
    on.exit(rv_running(FALSE), add = TRUE)

    ## Snapshot inputs so changes while running don't affect the current run.
    ## base_url comes from the SNAPSHOT taken at 'Test connection' so the
    ## token and datacenter always match.
    ## trimws() on both free-text path fields: a Windows folder name that ends
    ## in a trailing space makes dir.create() fail outright (confirmed live -
    ## dir.create() returns FALSE for a path with a trailing-space segment,
    ## even with recursive = TRUE) with no useful error beyond "could not
    ## create the output folder". Easy to hit by accident (autocomplete,
    ## copy-paste, a stray keystroke) and invisible in a normal text box.
    run_args <- list(
      account_name = trimws(input$account_label),
      api_key      = rv_token(),
      base_url     = rv_base_url() %||% input$base_url,
      backup_root  = trimws(input$backup_root),
      survey_filter = NULL,
      survey_subset_ids = selected_ids,
      skip_empty   = input$skip_empty,
      resume       = input$resume,
      politeness_delay = input$politeness_delay,
      encrypt_output = input$encrypt_output,
      encryption_passphrase = input$encryption_passphrase,
      on_progress  = progress_callback,
      on_log       = log_callback
    )

    rv_log(character())
    rv_progress$current <- 0
    rv_progress$total <- length(selected_ids)
    rv_progress$name <- NULL
    rv_result(NULL)

    append_log("info", sprintf(
      "Starting backup: account=%s, surveys=%d, folder=%s",
      run_args$account_name, length(selected_ids), run_args$backup_root
    ))

    ## Create a Shiny Progress handle. Its $set() calls flush the browser UI
    ## even while we're in the middle of an otherwise-blocking R call -
    ## that's the trick to keep Shiny feeling responsive during heavy work.
    shiny_progress <<- shiny::Progress$new(session, min = 0, max = 1)
    shiny_progress$set(value = 0,
                       message = "Starting backup...",
                       detail = sprintf("%d surveys queued", length(selected_ids)))

    ## Ensure we always close the progress handle, even on error.
    on.exit({
      if (!is.null(shiny_progress)) {
        tryCatch(shiny_progress$close(), error = function(e) NULL)
        shiny_progress <<- NULL
      }
    }, add = TRUE)

    ## Heavy lifting. Shiny is single-threaded so this blocks the UI, but the
    ## Progress$new() handle above gives the browser live updates through
    ## Shiny's internal message bus. For tens of surveys, blocking is fine;
    ## for larger workloads, wrap in future::future().
    result <- tryCatch(
      do.call(run_backup_session, run_args),
      error = function(e) {
        append_log("danger", sprintf("FATAL: %s", conditionMessage(e)))
        NULL
      }
    )

    rv_result(result)
    if (!is.null(result)) {
      append_log("success", sprintf(
        "Run complete: %d ok / %d failed.",
        result$surveys_ok, result$surveys_failed
      ))
    }
  })

  ## ---- Result summary ----------------------------------------------------

  output$result_summary <- renderUI({
    r <- rv_result()
    req(r)
    tags$div(
      tags$p(
        tags$strong("Account: "), r$account_name, tags$br(),
        tags$strong("Output folder: "), tags$code(r$account_root), tags$br(),
        tags$strong("Surveys attempted: "), r$surveys_attempted, tags$br(),
        tags$strong("Surveys ok: "),
        tags$span(class = "status-ok", r$surveys_ok), tags$br(),
        tags$strong("Surveys failed: "),
        tags$span(class = if (r$surveys_failed == 0) "status-ok" else "status-err",
                  r$surveys_failed), tags$br(),
        if (!is.na(r$errors_log)) tags$div(
          tags$strong("Errors log: "), tags$code(r$errors_log)
        )
      ),
      tags$p(
        "Open ", tags$code("_index.html"), " inside the output folder to ",
        "browse every survey's preview, responses, and portable JSON."
      )
    )
  })

  observeEvent(input$open_folder, {
    r <- rv_result()
    req(r)
    if (is.null(r$account_root) || is.na(r$account_root) ||
        !dir.exists(r$account_root)) {
      append_log("warning", "Output folder does not exist (nothing was written).")
      return()
    }
    tryCatch(open_folder_in_explorer(r$account_root),
             error = function(e) append_log("warning",
               sprintf("Could not open the folder: %s", conditionMessage(e))))
  })

  ## ---- Session end: zero out sensitive state ----------------------------
  session$onSessionEnded(function() {
    isolate({
      rv_token(NULL)
      rv_base_url(NULL)
      rv_surveys(NULL)
      rv_selected(character())
      rv_log(character())
    })
    ## Also scrub the process-wide copies qualtRics keeps in env vars.
    Sys.unsetenv(c("QUALTRICS_API_KEY", "QUALTRICS_BASE_URL"))
  })
}


## ==== 6. Launch ============================================================
## Exposes the shinyApp object as the entry point. The launcher (run_app.R)
## invokes shiny::runApp() explicitly with safe host/port settings. If you
## run this file with `Rscript app.R`, this line starts the app.
shinyApp(ui = ui, server = server)
