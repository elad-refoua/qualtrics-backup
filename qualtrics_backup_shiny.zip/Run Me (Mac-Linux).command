#!/usr/bin/env bash
# ===========================================================
#  Qualtrics Backup - Mac / Linux one-click launcher
# ===========================================================
#  On Mac: double-click this file (first time: right-click -> Open).
#  On Linux: run  bash "Run Me (Mac-Linux).command"
#
#  It:
#    1. Moves to the folder this script lives in.
#    2. Finds Rscript on your machine.
#    3. If R is missing, opens the download page.
#    4. Runs run_app.R. The app auto-installs missing R packages.
# ===========================================================

set -u

# Go to the folder this script lives in so relative paths work.
cd "$(dirname "$0")"

echo
echo "============================================================"
echo "  Qualtrics Backup - starting..."
echo "============================================================"
echo "  Folder: $(pwd)"
echo

# Locate Rscript. Try PATH, then common install locations.
RSCRIPT=""
if command -v Rscript >/dev/null 2>&1; then
    RSCRIPT="$(command -v Rscript)"
elif [ -x "/Library/Frameworks/R.framework/Resources/Rscript" ]; then
    RSCRIPT="/Library/Frameworks/R.framework/Resources/Rscript"
elif [ -x "/usr/local/bin/Rscript" ]; then
    RSCRIPT="/usr/local/bin/Rscript"
elif [ -x "/opt/homebrew/bin/Rscript" ]; then
    RSCRIPT="/opt/homebrew/bin/Rscript"
fi

if [ -z "$RSCRIPT" ]; then
    echo
    echo "============================================================"
    echo "  R is NOT installed on this computer."
    echo "============================================================"
    echo
    echo "  Install R from: https://cran.r-project.org/"
    echo
    # Try to open the page automatically
    if command -v open >/dev/null 2>&1; then
        open "https://cran.r-project.org/" 2>/dev/null || true
    elif command -v xdg-open >/dev/null 2>&1; then
        xdg-open "https://cran.r-project.org/" 2>/dev/null || true
    fi
    echo "  After installing, run this file again."
    echo
    read -n 1 -s -r -p "Press any key to exit..."
    exit 1
fi

echo "  Using R at: $RSCRIPT"
echo
echo "  First run will install R packages (2-5 minutes)."
echo "  After that, launches are instant."
echo "============================================================"
echo

"$RSCRIPT" run_app.R

echo
echo "============================================================"
echo "  App stopped."
echo "============================================================"
read -n 1 -s -r -p "Press any key to close this window..."
