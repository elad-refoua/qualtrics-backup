## ===========================================================================
## qualtrics_backup_v2.R
## ---------------------------------------------------------------------------
## Comprehensive Qualtrics backup tool.
##
## V2 (2026-07-16) - response-export accounting. Parallel file; the original
## qualtrics_backup.R is untouched (house refactor rule). Origin: the
## 2026-07-12 run on the lab machine finished "35 ok, 2 failed" and it took a
## manual investigation to learn WHAT was lost (answer: the two surveys'
## response data - everything else was saved). Diagnosis + evidence:
## diagnosis_2026-07-16/ and DIAGNOSIS_2026-07-16.md in this repo.
## What changed, all inside backup_one_survey() + run_backup_session():
##   1. The survey's metadata (with its official response count) is now
##      fetched FIRST. If the survey has 0 recorded responses, the response
##      download is skipped with a plain "nothing to export - not an error"
##      log line and a NO_RESPONSES.txt marker in the survey folder.
##   2. A REAL response-export failure is retried once; if it still fails,
##      MISSING_RESPONSES_README.txt is written into the survey folder saying
##      exactly what is missing, how many responses exist in Qualtrics, and
##      the most likely fix (404/400 here usually mean the survey is SHARED
##      into this account but OWNED elsewhere - export needs the owner's token).
##   3. End of run prints a RESPONSE BACKUP SUMMARY separating "empty survey
##      (fine)" from "HAS DATA - BACKUP INCOMPLETE (act)", and writes it to
##      _responses_summary.txt in the account folder.
##   4. Clearer plain-language wording on response-export errors.
## Everything else is identical to qualtrics_backup.R.
##
## Purpose
## -------
## For every survey in every configured Qualtrics account, download:
##   - Response data (numeric values + label-substituted values)
##   - Full survey definition (questions, choices, blocks, flow, logic)
##   - QSF (Qualtrics' editable survey format - re-importable into Qualtrics)
##   - Codebook (flat tidy table of question -> choice mappings)
##   - Portable, platform-neutral JSON (open schema, see PROJECT.md)
##   - Migration notes (Qualtrics-specific features that can't transfer cleanly)
##   - Standalone HTML preview of the questionnaire
##   - Metadata + display order info
##
## Output structure
## ----------------
## <BACKUP_ROOT>/<account>/<YYYY-MM-DD>/
##   README.md            <- legend explaining what's in this backup
##   _index.csv           <- machine-readable list of all surveys
##   _index.html          <- clickable mini-site for the whole backup
##   _errors.log          <- per-survey failures, written if anything fails
##   _responses_summary.txt <- (v2) which surveys' responses are/aren't backed up
##   <survey_name>__<survey_id>/
##     responses_numeric.rds
##     responses_numeric.csv
##     responses_labels.csv
##     survey_definition.json
##     survey.qsf
##     questions.csv
##     codebook.csv
##     metadata.json
##     display_order.csv
##     preview.html
##     survey_portable.json
##     migration_notes.md
##
## Credentials
## -----------
## This script NEVER stores Qualtrics API tokens in source code. Tokens are
## loaded at runtime from one of three sources, tried in this order:
##   (1) Environment variable QUALTRICS_API_TOKEN_<ACCOUNT_NAME>
##   (2) External file ~/.qualtrics_credentials.json (NOT in any project folder,
##       NOT synced to Dropbox/iCloud/etc.)
##   (3) OS credential store via the `keyring` package
## See setup_credentials.R for one-time credential configuration.
##
## Safety
## ------
## - Read-only against Qualtrics. Never writes, modifies, or deletes surveys.
## - Sanitized logging: tokens never appear in any printed message or file.
## - Per-survey try/catch: one failure does not abort the whole backup.
## - Resume mode: re-running on the same day skips already-completed surveys.
##
## Author: Elad Refoua + Claude Code
## Created: 2026-04-23
## License: MIT-style - free to use, modify, and share.
## ===========================================================================


## ==== 0. Clean R session ===================================================
## Wipe the workspace so a TOP-LEVEL run (Rscript qualtrics_backup.R) starts
## from a known empty state. When this file is source()d - by app.R, by
## regenerate_previews.R, or by a user's own script - we must NOT wipe the
## caller's global environment.
if (sys.nframe() == 0L) {
  rm(list = ls())        # Remove all objects from the global environment
  cat("\014")            # Clear the console (Ctrl+L equivalent)
}
## Locale: prefer UTF-8 (Windows 10+) so qualtRics::fetch_survey()'s temp
## filenames (which use the survey name) survive on Hebrew surveys.
## DO NOT force "Hebrew" - that maps to CP1255 on Windows and causes mojibake
## when qualtRics writes a temp file with Hebrew name then tries to read it
## back ("file does not exist" because R encoded the path differently).
try(Sys.setlocale("LC_CTYPE", ".UTF-8"), silent = TRUE)
## Close any leftover graphics device from a previous session.
if (!is.null(dev.list())) dev.off()


## ==== 1. Required packages =================================================
## We list every package explicitly with its purpose so future-you can audit
## the dependency surface. Install once with:
##   install.packages(c("qualtRics","httr","jsonlite","tibble","dplyr",
##                      "purrr","readr","cli","htmltools","fs","keyring"))

## Hard requirements - script cannot run without these.
required_packages <- c(
  "qualtRics",   # Official R client for Qualtrics API (responses, metadata)
  "httr",        # HTTP requests for endpoints qualtRics doesn't wrap
  "jsonlite",    # JSON read/write with UTF-8 + Hebrew support
  "tibble",      # Modern data frames with safe printing
  "dplyr",       # Tidyverse data manipulation
  "purrr",       # Functional iteration with safe error handling
  "readr",       # write_excel_csv() preserves UTF-8 BOM for Excel + Hebrew
  "cli",         # Pretty progress bars and status messages
  "htmltools",   # HTML-safe DOM construction for preview.html
  "fs"           # Filesystem ops (path normalization, permissions)
)

## Optional - only needed if the user chose credential method (C) keyring.
## If absent, load_credentials() just skips that fallback and errors cleanly
## when neither env var nor credentials file is set.
optional_packages <- c(
  "keyring"      # OS-native credential store (third credential fallback)
)

## Load each REQUIRED package, recording which ones fail to install/load.
## We fail loudly because the script cannot do useful work without them.
missing_packages <- character()
for (pkg in required_packages) {
  if (!suppressWarnings(suppressMessages(
    require(pkg, character.only = TRUE, quietly = TRUE)
  ))) {
    missing_packages <- c(missing_packages, pkg)
  }
}
if (length(missing_packages) > 0) {
  ## Stop with a clear, actionable install command.
  stop(
    "Missing R packages: ", paste(missing_packages, collapse = ", "),
    "\nInstall with:\n  install.packages(c(",
    paste(shQuote(missing_packages), collapse = ", "),
    "))",
    call. = FALSE
  )
}

## Try to load optional packages. Don't fail if they're missing - just flag it
## so downstream code (load_credentials) can skip the fallback gracefully.
has_optional <- setNames(
  vapply(optional_packages, function(p) {
    suppressWarnings(suppressMessages(
      requireNamespace(p, quietly = TRUE)
    ))
  }, logical(1)),
  optional_packages
)


## ==== 2. CONFIG ============================================================
## Runtime behavior. Tokens are NOT here on purpose - see Credentials section.

## Accounts to back up. The NAME is used to look up the token (env var or
## credentials file). To add a new account, just add an entry here AND store
## its token via setup_credentials.R.
ACCOUNTS <- list(
  ISF = list(base_url = "biusocialsciences.eu.qualtrics.com"),
  BSF = list(base_url = "biusocialsciences.eu.qualtrics.com")
)

## Where on disk to write backups. One subfolder per account per date.
## Default: a "Qualtrics Backups" folder inside the user's home directory
## (~/Qualtrics Backups). Adjust if your storage layout differs.
BACKUP_ROOT <- file.path(path.expand("~"), "Qualtrics Backups")

## Optional regex to limit which surveys are backed up.
##   NULL          -> back up every survey in the account
##   "study 2.*BQ" -> back up only surveys whose name matches this pattern
SURVEY_FILTER <- NULL

## If TRUE, surveys with zero responses are skipped (saves API calls).
## The survey's structure (definition, QSF, preview) is still small and useful,
## so consider FALSE if you want a true "everything" backup.
SKIP_EMPTY <- FALSE

## If TRUE, re-running on the same date will skip surveys whose folder already
## contains all expected artifacts. Makes incremental re-runs cheap.
RESUME <- TRUE

## If TRUE, after writing the per-account folder, tar + openssl-encrypt it.
## Off by default. When on, you'll be prompted for a passphrase interactively.
ENCRYPT_OUTPUT <- FALSE

## How long to wait between API calls (seconds). Qualtrics tolerates fast bursts
## but a small pause keeps us friendly and avoids accidental rate-limit trips.
API_POLITENESS_DELAY <- 0.5


## ==== 3. Credential loading ================================================
## Goal: never have a Qualtrics API token visible in source code, logs, or
## error messages. The function below tries three sources in order of
## preference and returns the token. It NEVER prints the token.

## Path to the optional credentials file. Lives in the user's home directory,
## OUTSIDE any project folder, OUTSIDE Dropbox. Format: a JSON object whose
## keys are account names and values are tokens. Example:
##   { "ISF": "abc123...", "BSF": "def456..." }
CREDENTIALS_FILE <- file.path(path.expand("~"), ".qualtrics_credentials.json")

#' Load a Qualtrics API token for a given account name.
#'
#' Tries three sources in order:
#'   (1) Environment variable QUALTRICS_API_TOKEN_<ACCOUNT_NAME>
#'   (2) JSON file at CREDENTIALS_FILE
#'   (3) OS credential store via keyring (service = "qualtrics")
#'
#' @param account_name Character. The account name as defined in ACCOUNTS.
#' @return Character. The API token. Stops with an instructive error if none
#'         of the three sources has the token. The error message NEVER echoes
#'         the token itself.
#' @side_effects Reads env vars / file / OS keyring. No writes.
load_credentials <- function(account_name) {
  ## --- Source 1: environment variable ---
  ## Convention: env var name is uppercased account name with prefix.
  env_var_name <- paste0("QUALTRICS_API_TOKEN_", toupper(account_name))
  env_value <- Sys.getenv(env_var_name, unset = "")
  if (nzchar(env_value)) {
    ## Found - return immediately. Don't log the value.
    return(env_value)
  }

  ## --- Source 2: external credentials file ---
  if (file.exists(CREDENTIALS_FILE)) {
    ## Check file permissions. On unix-like systems the file should be 0600.
    ## On Windows we just check that it exists in the user's home (which has
    ## per-user ACLs by default).
    if (.Platform$OS.type == "unix") {
      file_mode <- file.info(CREDENTIALS_FILE)$mode
      if (!is.na(file_mode) && (as.integer(file_mode) %% 64) != 0) {
        ## Anything other than user-only permissions is a warning, not fatal.
        warning(
          "Credentials file ", CREDENTIALS_FILE,
          " is not user-only-readable. Run setup_credentials.R again to fix.",
          call. = FALSE
        )
      }
    }
    ## Parse the JSON. simplifyVector keeps it as a flat named character vector.
    creds <- jsonlite::fromJSON(CREDENTIALS_FILE, simplifyVector = TRUE)
    if (!is.null(creds[[account_name]]) && nzchar(creds[[account_name]])) {
      return(creds[[account_name]])
    }
  }

  ## --- Source 3: OS keyring (only if the package is installed) ---
  ## The `keyring` package is optional; skip this fallback if it's not present.
  ## keyring::key_get can prompt the user interactively, so we wrap in tryCatch.
  if (isTRUE(has_optional[["keyring"]])) {
    key_value <- tryCatch(
      keyring::key_get(service = "qualtrics", username = account_name),
      error = function(e) NULL
    )
    if (!is.null(key_value) && nzchar(key_value)) {
      return(key_value)
    }
  }

  ## --- Nothing worked. Stop with an actionable, non-leaky error. ---
  keyring_hint <- if (isTRUE(has_optional[["keyring"]])) {
    sprintf("  3) keyring::key_set('qualtrics', '%s')\n", account_name)
  } else {
    "  3) (keyring fallback unavailable - install.packages('keyring') to enable)\n"
  }
  stop(
    "No API token found for account '", account_name, "'.\n",
    "Configure one with ANY of these (in order of preference):\n",
    "  1) Environment variable: ", env_var_name, "\n",
    "  2) Run setup_credentials.R to create ", CREDENTIALS_FILE, "\n",
    keyring_hint,
    "See README.md for details.",
    call. = FALSE
  )
}


## ==== 4. Account connection wrapper ========================================
## Wraps qualtRics::qualtrics_api_credentials() with a clean, repeatable call.
## We pass install = FALSE so the credential is only set for this session and
## never persisted to .Renviron - that protects against accidental leakage of
## a token into a file Elad might later commit or share.

#' Activate Qualtrics API credentials for the current R session.
#'
#' @param api_key  Character. The token returned by load_credentials().
#' @param base_url Character. The Qualtrics datacenter URL (no protocol).
#' @return Invisible NULL. Side effect: qualtRics functions can now make calls.
connect_account <- function(api_key, base_url) {
  qualtRics::qualtrics_api_credentials(
    api_key  = api_key,
    base_url = base_url,
    install  = FALSE,   # Do NOT write the token to .Renviron
    overwrite = TRUE    # Allow swapping accounts within one R session
  )
  invisible(NULL)
}


## ==== 5. Survey enumeration ================================================

#' List all surveys visible to the active credential, optionally filtered.
#'
#' @param filter_regex NULL or a regex to subset survey names.
#' @param include_response_counts Logical. If TRUE, also fetch response counts
#'   by calling metadata() for each survey (one API call per survey). For an
#'   account with 50 surveys this adds ~30 seconds. Set FALSE when you only
#'   need the list (e.g., the Shiny "Test connection" step). When FALSE,
#'   the response_count column is NA for all rows.
#' @param on_progress Optional callback: function(current, total, survey_name).
#'   Called once per survey during the metadata loop. Lets the Shiny app
#'   show "counting responses (5 of 50)..." instead of appearing frozen.
#' @return tibble with columns: id, name, ownerId, lastModified,
#'         creationDate, isActive, response_count.
#' @side_effects One API call to /surveys, plus one metadata() call per survey
#'               if include_response_counts is TRUE.
list_surveys <- function(filter_regex = NULL,
                         include_response_counts = TRUE,
                         on_progress = NULL) {
  ## qualtRics::all_surveys() handles pagination internally.
  all_s <- qualtRics::all_surveys()

  ## Optional name-based filter so users can scope a backup to one study.
  if (!is.null(filter_regex)) {
    all_s <- dplyr::filter(all_s, grepl(filter_regex, name))
  }

  ## Fast path: skip the per-survey metadata loop. Used by the Shiny UI's
  ## "Test connection" step, which should be near-instant.
  if (!include_response_counts) {
    return(dplyr::mutate(all_s, response_count = NA_integer_))
  }

  ## Slow path: look up response counts for each survey.
  ## metadata() is one API call per survey - we add a small sleep to be polite.
  n <- nrow(all_s)
  response_counts <- integer(n)
  for (i in seq_len(n)) {
    if (!is.null(on_progress)) {
      tryCatch(on_progress(i, n, all_s$name[i]),
               error = function(e) NULL)
    }
    Sys.sleep(API_POLITENESS_DELAY)
    md <- tryCatch(qualtRics::metadata(get = c("metadata", "questions", "responsecounts"), surveyID = all_s$id[i]),
                   error = function(e) NULL)
    ## responsecounts$auditable = unique respondents (excludes deleted ones)
    response_counts[i] <- if (is.null(md)) NA_integer_ else {
      as.integer(md$responsecounts$auditable %||% NA_integer_)
    }
  }

  dplyr::mutate(all_s, response_count = response_counts)
}

## Small null-coalesce helper because the above uses %||% which isn't in base R.
`%||%` <- function(a, b) if (is.null(a)) b else a

## ---- Shared structural helpers (added 2026-07-05 hardening pass) ----------

## Safe field accessor: QSF payloads occasionally store list entries as plain
## atomic values (legacy exports store e.g. "Validation": "None" as a bare
## string). `$` on an atomic vector is an ERROR in R, so every access into a
## payload subtree goes through .fld() which returns NULL instead of crashing.
.fld <- function(x, name) if (is.list(x)) x[[name]] else NULL

## Display text of a choice/answer/statement item. Handles both the normal
## {"Display": "..."} shape and the legacy bare-string shape.
.item_display <- function(item) {
  d <- .fld(item, "Display")
  if (!is.null(d)) return(as.character(d))
  if (is.character(item) && length(item) == 1) return(item)
  ""
}

## Resolve a display order: Qualtrics sometimes stores ChoiceOrder/AnswerOrder
## as an EMPTY array (not missing). %||% only guards NULL, so an empty order
## would silently drop every choice. Fall back to names() when empty.
resolve_order <- function(order, items) {
  if (is.null(order) || length(order) == 0) {
    return(names(items) %||% character())
  }
  order
}

## Detect right-to-left text (Hebrew 0590-05FF, Arabic 0600-08FF) by Unicode
## codepoint - locale-independent, no fragile regex ranges on Windows.
.is_rtl_text <- function(x) {
  if (is.null(x) || length(x) == 0 || !nzchar(x[1])) return(FALSE)
  cp <- tryCatch(utf8ToInt(enc2utf8(x[1])), error = function(e) integer())
  any(cp >= 0x0590 & cp <= 0x08FF)
}

## Recursively collect block IDs from a survey flow, in display order.
## Qualtrics nests blocks inside Branch / Group / BlockRandomizer elements
## (each carries its own $Flow); a top-level-only walk silently DROPS most of
## a real survey (verified 2026-07-05: ISF BQ 2019 rendered 3 of 221
## questions before this fix). Returns data.frame(id, conditional) where
## conditional = TRUE when the block sits under a Branch.
.collect_flow_blocks <- function(flow, in_branch = FALSE) {
  out <- data.frame(id = character(), conditional = logical(),
                    stringsAsFactors = FALSE)
  for (f in flow) {
    if (!is.list(f)) next
    if ((identical(f$Type, "Standard") || identical(f$Type, "Block")) &&
        !is.null(f$ID)) {
      out <- rbind(out, data.frame(id = f$ID, conditional = in_branch,
                                   stringsAsFactors = FALSE))
    }
    nested <- f$Flow
    if (!is.null(nested) && length(nested) > 0) {
      out <- rbind(out, .collect_flow_blocks(
        nested, in_branch = in_branch || identical(f$Type, "Branch")))
    }
  }
  out
}

## Full display order of blocks: flow-reachable blocks first (in flow order),
## then blocks that never appear in the flow - except the Trash block.
.ordered_blocks <- function(definition) {
  blocks <- definition$Blocks %||% list()
  fl <- .collect_flow_blocks(.fld(definition$SurveyFlow, "Flow") %||% list())
  fl <- fl[!duplicated(fl$id) & fl$id %in% names(blocks), , drop = FALSE]
  leftover <- setdiff(names(blocks), fl$id)
  leftover <- leftover[vapply(leftover, function(bid) {
    !identical(.fld(blocks[[bid]], "Type"), "Trash")
  }, logical(1))]
  if (length(leftover) > 0) {
    fl <- rbind(fl, data.frame(id = leftover, conditional = FALSE,
                               stringsAsFactors = FALSE))
  }
  fl
}

## QIDs that live in the Trash block (deleted questions still present in the
## QSF). Downstream artifacts label or exclude them so deleted questions are
## never mistaken for live survey content.
.trash_qids <- function(definition) {
  blocks <- definition$Blocks %||% list()
  out <- character()
  for (bid in names(blocks)) {
    b <- blocks[[bid]]
    if (!identical(.fld(b, "Type"), "Trash")) next
    for (el in .fld(b, "BlockElements") %||% list()) {
      qid <- .fld(el, "QuestionID")
      if (!is.null(qid)) out <- c(out, qid)
    }
  }
  unique(out)
}

## Human-readable display-logic conditions: Qualtrics stores per-condition
## Description strings (e.g. "If Q12 Yes Is Selected") inside the DisplayLogic
## tree. Collect them all so previews can show WHY a question appears.
.display_logic_text <- function(q) {
  dl <- .fld(q, "DisplayLogic")
  if (is.null(dl)) return(character())
  out <- character()
  walk <- function(x) {
    if (!is.list(x)) return(invisible(NULL))
    d <- x$Description
    if (!is.null(d) && is.character(d) && length(d) == 1 && nzchar(d)) {
      out <<- c(out, strip_html(d))
    }
    for (el in x) walk(el)
    invisible(NULL)
  }
  walk(dl)
  unique(out)
}

## Slider step from the QSF Configuration: SnapToGrid is a BOOLEAN (whether
## the handle snaps), GridLines holds the number of intervals. The real step
## is (max - min) / GridLines when snapping is on; NA otherwise.
.slider_step <- function(cfg) {
  snap <- isTRUE(.fld(cfg, "SnapToGrid") %||% FALSE)
  grid <- suppressWarnings(as.numeric(.fld(cfg, "GridLines") %||% NA))
  smin <- suppressWarnings(as.numeric(.fld(cfg, "CSSliderMin") %||% NA))
  smax <- suppressWarnings(as.numeric(.fld(cfg, "CSSliderMax") %||% NA))
  if (snap && !is.na(grid) && grid > 0 && !is.na(smin) && !is.na(smax)) {
    (smax - smin) / grid
  } else {
    NA_real_
  }
}


## ---- Survey flow rendering (Elad 2026-07-10) -----------------------------
## Elad's request: a backup must capture not just the questions and data but
## the SURVEY FLOW - "what appeared to whom", i.e. the full branching /
## randomization / embedded-data / quota / end-of-survey logic. The QSF's
## SurveyFlow subtree is the lossless source; the helpers below turn it into
## (a) readable condition text and (b) an indented tree rendering. We NEVER
## silently drop a condition: if we cannot decode an operator we print it raw.

## Map a Qualtrics logic Operator code to a plain-language phrase. Unknown
## operators fall through to the raw code (surrounded by spaces) so a
## condition is never lost, only shown less prettily.
.op_phrase <- function(op) {
  if (is.null(op) || !nzchar(op)) return("?")
  switch(op,
    "Selected"            = "is selected",
    "NotSelected"         = "is not selected",
    "Displayed"           = "was displayed",
    "NotDisplayed"        = "was not displayed",
    "EqualTo"             = "is equal to",
    "NotEqualTo"          = "is not equal to",
    "GreaterThan"         = "is greater than",
    "LessThan"            = "is less than",
    "GreaterThanOrEqual"  = "is >=",
    "LessThanOrEqual"     = "is <=",
    "Is"                  = "is",
    "IsNot"               = "is not",
    "Contains"            = "contains",
    "DoesNotContain"      = "does not contain",
    "Matches"             = "matches",
    "IsEmpty"             = "is empty",
    "IsNotEmpty"          = "is not empty",
    "EmptyOrNull"         = "is empty",
    "IsTrue"              = "is true",
    "IsFalse"             = "is false",
    ## Unknown -> keep the raw code so the condition is never dropped.
    paste0("[", op, "]"))
}

## A single logic Expression -> one readable clause. Qualtrics ALREADY stores
## a human-readable "Description" HTML string on each leaf (e.g.
## "<span class='ConjDesc'>If</span> Q3 Yes Is Selected"); we prefer it
## (stripped of HTML) because it resolves choice/question labels the way
## Qualtrics itself shows them. When Description is missing we rebuild the
## clause from the structured fields so a condition is NEVER silently lost.
.render_logic_expr <- function(expr) {
  desc <- .fld(expr, "Description")
  if (!is.null(desc) && is.character(desc) && length(desc) == 1 && nzchar(desc)) {
    txt <- strip_html(desc)
    ## Qualtrics sometimes stores the FULL readable clause in Description
    ## (e.g. "If guide_1 Is Equal to ..."), but for choice-based conditions
    ## it stores ONLY the conjunction word ("If" / "And" / "Or"). In the
    ## latter case fall through to structured decoding so we don't emit a
    ## bare "If" with no actual condition.
    is_bare_conj <- grepl("^(if|and|or)$", tolower(trimws(txt)))
    if (nzchar(txt) && !is_bare_conj) {
      ## Drop a leading "If " - the branch/skip header already supplies it;
      ## keep "And"/"Or" (they distinguish additional conditions).
      txt <- sub("^[Ii]f\\s+", "", txt)
      return(txt)
    }
  }
  ## Capture a bare conjunction word (And/Or) from Description so a
  ## multi-condition branch reads "... Or answer to QID59 ...".
  conj_prefix <- ""
  if (!is.null(desc)) {
    dtxt <- tolower(trimws(strip_html(desc)))
    if (dtxt %in% c("and", "or")) {
      conj_prefix <- paste0(toupper(substring(dtxt, 1, 1)),
                            substring(dtxt, 2), " ")
    }
  }
  ## --- Fallback: reconstruct from structured fields. ---
  ltype <- .fld(expr, "LogicType") %||% ""
  op    <- .fld(expr, "Operator") %||% ""
  ## What is being tested (left side).
  left <- switch(ltype,
    "Question"       = {
      qid <- .fld(expr, "QuestionID") %||%
             .fld(expr, "QuestionIDFromLocator") %||% "(question)"
      paste0("answer to ", qid)
    },
    "EmbeddedField"  = paste0("embedded field '",
                              .fld(expr, "LeftOperand") %||% "(field)", "'"),
    "Quota"          = paste0("quota '",
                              .fld(expr, "QuotaID") %||%
                              .fld(expr, "LeftOperand") %||% "(quota)", "'"),
    "GeoIP"          = "respondent location",
    "Reference"      = paste0("reference '",
                              .fld(expr, "LeftOperand") %||% "", "'"),
    ## default: use LeftOperand verbatim if present, else the logic type.
    { lo <- .fld(expr, "LeftOperand")
      if (!is.null(lo) && nzchar(lo)) lo else (if (nzchar(ltype)) ltype else "(condition)") }
  )
  right <- .fld(expr, "RightOperand")
  choice <- .fld(expr, "ChoiceLocator")
  right_txt <- if (!is.null(right) && nzchar(as.character(right))) {
    paste0(" ", as.character(right))
  } else if (!is.null(choice) && nzchar(as.character(choice)) &&
             op %in% c("Selected", "NotSelected")) {
    ## e.g. q://QID3/SelectableChoice/2 -> "choice 2"
    ch <- sub(".*/", "", as.character(choice))
    paste0(" choice ", ch)
  } else ""
  clause <- paste0(conj_prefix, left, " ", .op_phrase(op), right_txt)
  ## Prepend an explicit Conjunction field (And/Or) if present and not already
  ## captured via the Description conjunction span above.
  if (!nzchar(conj_prefix)) {
    conj <- .fld(expr, "Conjuction") %||% .fld(expr, "Conjunction")
    if (!is.null(conj) && nzchar(conj) && !identical(tolower(conj), "and")) {
      clause <- paste0(toupper(substring(conj, 1, 1)), substring(conj, 2),
                       " ", clause)
    }
  }
  trimws(clause)
}

## A whole BranchLogic / SkipLogic BooleanExpression tree -> a vector of
## readable clauses (one per Expression leaf, in document order). Walks the
## nested numeric-keyed structure ({"0":{"0":{...Expression},Type:Expression},
## Type:BooleanExpression}) recursively; every Expression leaf yields a clause.
.render_boolean_expression <- function(logic) {
  out <- character()
  walk <- function(x) {
    if (!is.list(x)) return(invisible(NULL))
    if (identical(.fld(x, "Type"), "Expression") &&
        (!is.null(.fld(x, "Operator")) || !is.null(.fld(x, "LogicType")) ||
         !is.null(.fld(x, "Description")))) {
      out <<- c(out, .render_logic_expr(x))
      return(invisible(NULL))
    }
    ## Descend into numeric-keyed children (and any nested lists), skipping the
    ## scalar bookkeeping fields.
    for (nm in names(x)) {
      if (identical(nm, "Type")) next
      child <- x[[nm]]
      if (is.list(child)) walk(child)
    }
    ## Unnamed list (rare) - iterate positionally.
    if (is.null(names(x))) for (child in x) if (is.list(child)) walk(child)
    invisible(NULL)
  }
  walk(logic)
  out[nzchar(out)]
}

## Summarize one EmbeddedData flow element's field assignments into readable
## "field = value" (or "field (set by ...)" when the value is dynamic/piped).
.render_embedded_fields <- function(f) {
  eds <- .fld(f, "EmbeddedData") %||% list()
  vapply(eds, function(ed) {
    field <- .fld(ed, "Field") %||% .fld(ed, "Description") %||% "(field)"
    val   <- .fld(ed, "Value")
    vtype <- .fld(ed, "Type") %||% ""
    if (!is.null(val) && nzchar(as.character(val))) {
      paste0(field, " = ", as.character(val))
    } else if (nzchar(vtype) && !identical(vtype, "Custom")) {
      paste0(field, " (", vtype, ")")
    } else {
      paste0(field, " (set later / dynamic)")
    }
  }, character(1))
}

## Recursively render the SurveyFlow tree to an indented, human-readable set
## of lines. `blocks` maps BL_xxx -> block object so we can print block NAMES
## (not just opaque IDs). Each line is a plain string; the caller joins with
## newlines for the .txt artifact and wraps for HTML. This is the beating
## heart of "what appeared to whom".
.render_flow_lines <- function(flow, blocks, depth = 0) {
  ind <- strrep("    ", depth)
  lines <- character()
  for (f in flow) {
    if (!is.list(f)) next
    type <- .fld(f, "Type") %||% "(unknown)"
    if (type %in% c("Standard", "Block")) {
      bid <- .fld(f, "ID") %||% "(no id)"
      bname <- .fld(blocks[[bid]], "Description") %||% bid
      lines <- c(lines, paste0(ind, "Block: ", bname, "  [", bid, "]"))
    } else if (identical(type, "Branch")) {
      bdesc <- .fld(f, "Description")
      hdr <- paste0(ind, "Branch",
                    if (!is.null(bdesc) && nzchar(bdesc))
                      paste0(" '", strip_html(bdesc), "'") else "", ":")
      clauses <- .render_boolean_expression(.fld(f, "BranchLogic") %||% list())
      if (length(clauses) == 0) {
        lines <- c(lines, paste0(hdr, " (always)"))
      } else {
        lines <- c(lines, paste0(hdr, " if ", clauses[1]))
        if (length(clauses) > 1) {
          lines <- c(lines, paste0(ind, "        ", clauses[-1]))
        }
      }
      lines <- c(lines,
                 .render_flow_lines(.fld(f, "Flow") %||% list(), blocks, depth + 1))
    } else if (identical(type, "BlockRandomizer")) {
      sub  <- .fld(f, "SubSet")
      even <- isTRUE(.fld(f, "EvenPresentation"))
      nested <- .fld(f, "Flow") %||% list()
      n_total <- length(nested)
      pres <- if (!is.null(sub) && nzchar(as.character(sub))) as.character(sub) else "all"
      lines <- c(lines, paste0(
        ind, "Randomizer: present ", pres, " of ", n_total,
        " element(s)", if (even) ", evenly balanced" else "", ":"))
      lines <- c(lines, .render_flow_lines(nested, blocks, depth + 1))
    } else if (identical(type, "Group")) {
      gdesc <- .fld(f, "Description")
      lines <- c(lines, paste0(ind, "Group",
                 if (!is.null(gdesc) && nzchar(gdesc))
                   paste0(" '", strip_html(gdesc), "'") else "", ":"))
      lines <- c(lines,
                 .render_flow_lines(.fld(f, "Flow") %||% list(), blocks, depth + 1))
    } else if (identical(type, "EmbeddedData")) {
      fields <- .render_embedded_fields(f)
      if (length(fields) == 0) {
        lines <- c(lines, paste0(ind, "Set embedded data (no fields)"))
      } else {
        lines <- c(lines, paste0(ind, "Set embedded data:"))
        lines <- c(lines, paste0(ind, "    - ", fields))
      }
    } else if (identical(type, "EndSurvey")) {
      et <- .fld(f, "EndingType") %||% .fld(f, "SurveyTermination") %||% "Default"
      lines <- c(lines, paste0(ind, "End of survey (", et, ")"))
    } else if (identical(type, "Authenticator")) {
      lines <- c(lines, paste0(ind, "Authenticator (respondent must authenticate):"))
      lines <- c(lines,
                 .render_flow_lines(.fld(f, "Flow") %||% list(), blocks, depth + 1))
    } else if (type %in% c("Quota", "ReferenceSurvey", "TableOfContents",
                           "WebService", "Conjoint")) {
      extra <- .fld(f, "Description") %||% .fld(f, "QuotaID") %||% ""
      lines <- c(lines, paste0(ind, type,
                 if (nzchar(extra)) paste0(": ", strip_html(extra)) else ""))
      nested <- .fld(f, "Flow")
      if (!is.null(nested) && length(nested) > 0)
        lines <- c(lines, .render_flow_lines(nested, blocks, depth + 1))
    } else {
      ## Unknown element type: show it raw rather than dropping it.
      lines <- c(lines, paste0(ind, type, " (flow element - see survey_flow.json)"))
      nested <- .fld(f, "Flow")
      if (!is.null(nested) && length(nested) > 0)
        lines <- c(lines, .render_flow_lines(nested, blocks, depth + 1))
    }
  }
  lines
}

## Build the full human-readable flow text for a survey definition. Returns a
## single character string (newline-joined) ready to write to survey_flow.txt.
build_flow_text <- function(definition) {
  flow <- .fld(definition$SurveyFlow, "Flow") %||% list()
  blocks <- definition$Blocks %||% list()
  header <- c(
    "SURVEY FLOW - what appeared to whom",
    paste0("Survey: ", definition$SurveyName %||% "(unnamed)"),
    paste0("Generated: ", format(Sys.time(), "%Y-%m-%d %H:%M")),
    strrep("=", 60),
    "",
    "This is the order and logic Qualtrics used to decide what each",
    "respondent saw: blocks, branch conditions, randomizers, embedded",
    "data, and end-of-survey points. Indentation shows nesting.",
    ""
  )
  body <- if (length(flow) == 0) {
    "(This survey has no explicit flow - blocks are shown in their natural order.)"
  } else {
    .render_flow_lines(flow, blocks, depth = 0)
  }
  paste(c(header, body), collapse = "\n")
}

## Per-question display-logic / skip-logic table. One row per question that
## carries a condition on WHEN it appears (DisplayLogic) or where it jumps
## (SkipLogic). Rendered readably; a question with several conditions gets
## them joined. Also captures carry-forward (choices piped from an earlier
## question) when present. Returns a tibble (possibly zero rows).
build_display_logic_table <- function(definition) {
  questions <- definition$Questions %||% list()
  if (length(questions) == 0) return(tibble::tibble())

  ## QID -> block name (reuse the ordered-blocks attribution logic).
  blocks <- definition$Blocks %||% list()
  qid_to_block <- list()
  .ord_ids <- unique(c(.ordered_blocks(definition)$id, names(blocks)))
  for (bid in .ord_ids) {
    b <- blocks[[bid]]
    if (is.null(b)) next
    bname <- .fld(b, "Description") %||% bid
    for (el in .fld(b, "BlockElements") %||% list()) {
      qid <- .fld(el, "QuestionID")
      if (!is.null(qid) && is.character(qid) && is.null(qid_to_block[[qid]])) {
        qid_to_block[[qid]] <- bname
      }
    }
  }

  rows <- list()
  for (qid in names(questions)) {
    q <- questions[[qid]]
    dl <- .fld(q, "DisplayLogic")
    sl <- .fld(q, "SkipLogic")
    cf <- .fld(q, "DynamicChoices") %||% .fld(q, "DynamicChoicesData")
    ## Display-logic conditions: prefer the per-condition Description strings
    ## Qualtrics stores (collected by .display_logic_text); if absent, decode.
    dl_txt <- character()
    if (!is.null(dl)) {
      dl_txt <- .display_logic_text(q)
      if (length(dl_txt) == 0) dl_txt <- .render_boolean_expression(dl)
    }
    sl_txt <- character()
    if (!is.null(sl)) {
      sl_txt <- .render_boolean_expression(sl)
      if (length(sl_txt) == 0) sl_txt <- "skip logic present (see QSF)"
    }
    has_cf <- !is.null(cf)
    if (length(dl_txt) == 0 && length(sl_txt) == 0 && !has_cf) next
    rows[[length(rows) + 1]] <- tibble::tibble(
      question_id      = qid,
      block_name       = qid_to_block[[qid]] %||% NA_character_,
      question_text    = strip_html(q$QuestionText %||% ""),
      display_logic    = paste(dl_txt, collapse = "  AND/OR  "),
      skip_logic       = paste(sl_txt, collapse = "  ;  "),
      carries_forward_choices = has_cf
    )
  }
  if (length(rows) == 0) return(tibble::tibble())
  dplyr::bind_rows(rows)
}


## ==== 6. Survey definition + QSF download ==================================
## qualtRics doesn't expose the /survey-definitions endpoint (which returns the
## complete questionnaire structure: questions, choices, blocks, flow, logic).
## We hit it directly via httr.

#' GET https://<base_url>/API/v3/survey-definitions/{id}
#' Returns the full Qualtrics-internal survey definition as a parsed list.
#'
#' @param survey_id Character. e.g. "SV_1FW32IWe6Q9i2HA".
#' @param base_url  Character. e.g. "biusocialsciences.eu.qualtrics.com".
#' @param api_key   Character. The bearer token. Sent in X-API-TOKEN header.
#' @return Parsed list (the JSON "result" sub-object).
#' @side_effects One outbound HTTPS GET. No file writes.
fetch_survey_definition <- function(survey_id, base_url, api_key) {
  ## Build the URL once. We use https unconditionally - never plain http.
  url <- paste0("https://", base_url,
                "/API/v3/survey-definitions/", survey_id)

  ## httr::GET with the X-API-TOKEN header (Qualtrics' authentication scheme).
  ## We set a 60-second timeout because some large surveys take time to dump.
  resp <- httr::GET(
    url,
    httr::add_headers(`X-API-TOKEN` = api_key),
    httr::timeout(60)
  )

  ## Hard fail on HTTP errors. http_status() formats the message clearly.
  ## NOTE: we deliberately do NOT include the response body in the error
  ## because Qualtrics sometimes echoes the request URL (which contains IDs
  ## but not the token). Belt and suspenders.
  if (httr::http_error(resp)) {
    stop(
      "Failed to fetch survey definition for ", survey_id, ": ",
      httr::http_status(resp)$message,
      call. = FALSE
    )
  }

  ## Parse JSON with UTF-8 (preserves Hebrew). simplifyVector = FALSE keeps
  ## the structure as nested lists - we want full fidelity, not auto-coerced
  ## tibbles, since the structure is irregular per question type.
  parsed <- jsonlite::fromJSON(
    httr::content(resp, as = "text", encoding = "UTF-8"),
    simplifyVector = FALSE
  )

  ## The actual definition lives under $result. The wrapper has metadata.
  parsed$result
}


#' GET the QSF endpoint and return the body as TEXT.
#' Memory-first: we keep the body in memory so disk-write failures (Hebrew
#' folders, OneDrive sync, long paths) don't lose the data. The caller can
#' then write to disk and/or parse via qsf_to_definition().
#'
#' Robustness: fetches the body as RAW bytes first, then converts to UTF-8
#' text. Some Qualtrics datacenters serve the QSF with a Content-Type that
#' httr's `as = "text"` doesn't auto-decode (e.g. application/octet-stream),
#' which would cause silent failures. Raw + manual decode sidesteps that.
#'
#' @param survey_id Character. The survey ID.
#' @param base_url  Character.
#' @param api_key   Character.
#' @return Character. The QSF body as a UTF-8 JSON string.
fetch_survey_qsf <- function(survey_id, base_url, api_key) {
  url <- paste0("https://", base_url,
                "/API/v3/survey-definitions/", survey_id, "?format=qsf")

  resp <- httr::GET(
    url,
    httr::add_headers(`X-API-TOKEN` = api_key),
    httr::timeout(120)
  )

  status <- httr::status_code(resp)
  if (httr::http_error(resp)) {
    ## Include status code + (truncated) body so the user can see the real
    ## reason (401 unauthorized, 403 forbidden, 404 not found, etc.).
    body_preview <- tryCatch(
      substr(httr::content(resp, as = "text", encoding = "UTF-8"), 1, 200),
      error = function(e) "(could not read body)"
    )
    stop(
      "Failed to fetch QSF for ", survey_id,
      " (HTTP ", status, "): ", body_preview,
      call. = FALSE
    )
  }

  ## Raw bytes -> UTF-8 string (independent of Content-Type header).
  raw_bytes <- httr::content(resp, as = "raw")
  if (length(raw_bytes) == 0) {
    stop("Failed to fetch QSF for ", survey_id,
         " (HTTP ", status, "): empty response body",
         call. = FALSE)
  }
  qsf_text <- rawToChar(raw_bytes)
  Encoding(qsf_text) <- "UTF-8"

  if (!nzchar(qsf_text)) {
    stop("Failed to fetch QSF for ", survey_id,
         " (HTTP ", status, "): empty body after decode",
         call. = FALSE)
  }

  qsf_text
}

#' Write a QSF body string to disk with UTF-8 encoding.
#' Separated so disk failure doesn't lose the body we already have in memory.
#'
#' @param qsf_text Character. The QSF body as returned by fetch_survey_qsf().
#' @param out_path Character. Where to write the .qsf file.
#' @return Invisible NULL.
write_qsf <- function(qsf_text, out_path) {
  con <- file(out_path, open = "w", encoding = "UTF-8")
  on.exit(close(con), add = TRUE)
  writeLines(qsf_text, con = con)
  invisible(NULL)
}


## ==== 6b. QSF -> definition adapter ========================================
## Convert a Qualtrics QSF file (the editable export format) into the same
## structure that fetch_survey_definition() returns. This is our recovery
## path: when /survey-definitions/{id} returns null (token-permission or
## API-quirk), we can still build preview.html + codebook.csv from the QSF.
##
## QSF structure (after stripping the API meta/result wrapper):
##   $SurveyEntry  - top-level survey metadata
##   $SurveyElements - list of {Element, PrimaryAttribute, SecondaryAttribute,
##                              Payload, ...}
## Element types:
##   SQ   = a question (Payload has the question spec)
##   BL   = the blocks object (Payload is a list of blocks, each with elements)
##   FL   = the flow (Payload$Flow)
##   SO/PROJ/QC/RS/SCO/STAT/PL = survey-level config we don't need

#' Convert a parsed QSF file into a Definition-shaped list.
#'
#' @param qsf_parsed The list from jsonlite::fromJSON(qsf_path, simplifyVector=FALSE).
#'   Can be either the wrapped form ({meta:..., result:...}) or the unwrapped
#'   form. We auto-detect.
#' @return A list with the same shape as fetch_survey_definition() output:
#'         $SurveyName, $SurveyID, $SurveyLanguage, $Questions, $Blocks,
#'         $SurveyFlow.
qsf_to_definition <- function(qsf_parsed) {
  ## Auto-unwrap if this is the API-wrapped form.
  inner <- qsf_parsed$result %||% qsf_parsed
  entry <- inner$SurveyEntry %||% list()
  elements <- inner$SurveyElements %||% list()

  ## Build Questions: every SQ element. Key it by PrimaryAttribute (the QID).
  sq_elements <- Filter(function(e) identical(e$Element, "SQ"), elements)
  questions <- list()
  for (e in sq_elements) {
    qid <- e$PrimaryAttribute
    if (is.null(qid)) next
    ## Payload has the full per-question spec (QuestionText, Choices, etc.)
    questions[[qid]] <- e$Payload
  }

  ## Build Blocks: the BL element's Payload is the blocks dictionary.
  ## QSF stores this as a list whose names may be numeric indices ("1","2",...)
  ## while SurveyFlow refers to blocks by their actual IDs ("BL_xxx"). Always
  ## re-key by $ID so downstream lookups (render_preview_html, codebook,
  ## docx) can resolve flow references.
  bl_element <- Filter(function(e) identical(e$Element, "BL"), elements)
  blocks <- list()
  if (length(bl_element) > 0) {
    bl_payload <- bl_element[[1]]$Payload %||% list()
    for (b in bl_payload) {
      if (!is.null(b$ID) && nzchar(b$ID)) {
        blocks[[b$ID]] <- b
      }
    }
  }

  ## Build SurveyFlow: the FL element's Payload contains $Flow.
  fl_element <- Filter(function(e) identical(e$Element, "FL"), elements)
  survey_flow <- if (length(fl_element) > 0) {
    fl_element[[1]]$Payload %||% list(Flow = list())
  } else {
    list(Flow = list())
  }

  list(
    SurveyName     = entry$SurveyName %||% "(unnamed)",
    SurveyID       = entry$SurveyID %||% NA_character_,
    SurveyLanguage = entry$SurveyLanguage %||% "EN",
    Questions      = questions,
    Blocks         = blocks,
    SurveyFlow     = survey_flow
  )
}


## ==== 6c. Questions table (one row per question) ==========================
## Wide-format companion to codebook.csv. Same columns as the codebook (mostly)
## but with choices / statements / scale collapsed into single cells via a
## separator so each question is exactly ONE row. Good for quick scanning and
## for users who don't want the choice-level explosion.

#' Build a one-row-per-question summary table.
#'
#' @param definition Parsed survey definition (from fetch_survey_definition()
#'   or qsf_to_definition()).
#' @param sep Character. Separator used to join multiple choice/statement/
#'   answer labels into a single cell. Default " | ".
#' @return tibble with one row per question. Columns:
#'   question_id, original_qualtrics_id, block_id, block_name,
#'   question_type, question_selector, question_subselector, canonical_type,
#'   question_text, question_description, required,
#'   has_display_logic, has_piped_text, has_javascript, randomize_choices,
#'   n_choices, choices_labels, choices_values, choices_recodes,
#'   n_statements, statements_labels, statements_ids,
#'   n_answers, scale_labels, scale_values, scale_recodes,
#'   slider_min, slider_max, slider_step,
#'   validation_rules
build_questions_table <- function(definition, sep = " | ") {
  questions <- definition$Questions %||% list()
  if (length(questions) == 0) return(tibble::tibble())

  ## QID -> (block_id, block_name) lookup.
  blocks <- definition$Blocks %||% list()
  qid_to_block <- list()
  ## Display order first, first assignment wins - a stale Default container
  ## block that re-references every QID must not steal the block attribution.
  .ord_ids <- unique(c(.ordered_blocks(definition)$id, names(blocks)))
  for (bid in .ord_ids) {
    b <- blocks[[bid]]
    if (is.null(b)) next
    bname <- .fld(b, "Description") %||% bid
    for (el in .fld(b, "BlockElements") %||% list()) {
      qid <- .fld(el, "QuestionID")
      if (!is.null(qid) && is.character(qid) && is.null(qid_to_block[[qid]])) {
        qid_to_block[[qid]] <- list(id = bid, name = bname)
      }
    }
  }

  ## Helper to flatten an ordered list of labeled items into a sep-joined
  ## string in display order. Returns "" if no items. Uses .item_display so
  ## legacy bare-string choices don't crash on `$`.
  join_labeled <- function(items, order, field = "Display") {
    if (length(items) == 0) return("")
    vals <- vapply(order, function(k) {
      if (identical(field, "Display")) {
        .item_display(items[[as.character(k)]])
      } else {
        as.character(.fld(items[[as.character(k)]], field) %||% "")
      }
    }, character(1))
    paste(vals, collapse = sep)
  }

  ## Deleted questions parked in the Trash block - flagged, not hidden.
  trash_set <- .trash_qids(definition)

  rows <- lapply(names(questions), function(qid) {
    q <- questions[[qid]]
    qtype <- q$QuestionType %||% ""
    qsel  <- q$Selector %||% ""
    qsub  <- q$SubSelector %||% ""
    qtype_key <- paste(qtype, qsel, sep = "/")
    canonical <- QUALTRICS_TYPE_MAP[[qtype_key]] %||% "unknown"
    blk <- qid_to_block[[qid]] %||% list(id = NA_character_, name = NA_character_)

    ## Choice/Answer/Statement collection. All access via .fld/resolve_order
    ## so legacy payload shapes (atomic Validation, empty orders, bare-string
    ## choices) degrade gracefully instead of crashing the whole table.
    choices    <- .fld(q, "Choices") %||% list()
    choice_ord <- resolve_order(.fld(q, "ChoiceOrder"), choices)
    recodes    <- .fld(q, "RecodeValues") %||% list()
    answers    <- .fld(q, "Answers") %||% list()
    ans_ord    <- resolve_order(.fld(q, "AnswerOrder"), answers)

    ## For a Matrix, choices = statements (the rows of the grid).
    ## For everything else, choices are just the MC options.
    is_matrix <- identical(qtype, "Matrix")
    is_sbs    <- identical(qtype, "SBS")

    ## Matrix scale recodes: the QSF stores them in RecodeValues KEYED BY
    ## ANSWER IDS (there is no such field as "AnswerRecodeValues" - verified
    ## against real exports 2026-07-05). For non-matrix questions the same
    ## RecodeValues field recodes the choices instead.
    ans_rec <- if (is_matrix) recodes else list()

    ## SBS (side-by-side): the scale columns live in AdditionalQuestions,
    ## each a full sub-question with its own Answers + RecodeValues.
    sbs_subs <- if (is_sbs) .fld(q, "AdditionalQuestions") %||% list() else list()

    ## Compact validation summary (e.g. "ForceResponse=ON; min=0; max=100").
    ## Legacy surveys store Validation as the bare string "None" - guard it.
    vset <- .fld(.fld(q, "Validation"), "Settings") %||% list()
    vnum <- .fld(vset, "ValidNumber") %||% list()
    val_parts <- character()
    if (identical(.fld(vset, "ForceResponse"), "ON"))
      val_parts <- c(val_parts, "ForceResponse=ON")
    if (!is.null(vnum$Min)) val_parts <- c(val_parts, paste0("min=", vnum$Min))
    if (!is.null(vnum$Max)) val_parts <- c(val_parts, paste0("max=", vnum$Max))
    if (!is.null(.fld(vset, "MinChars")))
      val_parts <- c(val_parts, paste0("min_chars=", .fld(vset, "MinChars")))
    val_str <- paste(val_parts, collapse = "; ")

    ## Slider settings. Step = (max-min)/GridLines when SnapToGrid is on;
    ## SnapToGrid itself is a boolean, NOT a step size.
    cfg <- .fld(q, "Configuration") %||% list()
    smin <- .fld(cfg, "CSSliderMin") %||% vnum$Min %||% NA
    smax <- .fld(cfg, "CSSliderMax") %||% vnum$Max %||% NA
    sstep <- .slider_step(cfg)

    tibble::tibble(
      question_id            = qid,
      original_qualtrics_id  = qid,
      block_id               = blk$id,
      block_name             = blk$name,
      question_type          = qtype,
      question_selector      = qsel,
      question_subselector   = qsub,
      canonical_type         = canonical,
      question_text          = q$QuestionText %||% "",
      question_description   = q$QuestionDescription %||% NA_character_,
      required               = identical(.fld(vset, "ForceResponse"), "ON"),
      in_trash               = qid %in% trash_set,
      has_display_logic      = !is.null(.fld(q, "DisplayLogic")),
      has_piped_text         = grepl("${", q$QuestionText %||% "", fixed = TRUE),
      has_javascript         = !is.null(.fld(q, "QuestionJS")) &&
                               nzchar(.fld(q, "QuestionJS") %||% ""),
      randomize_choices      = !is.null(.fld(q, "Randomization")) &&
                               !identical(.fld(.fld(q, "Randomization"), "Advanced"), "None") &&
                               !is.null(.fld(.fld(q, "Randomization"), "Type")),

      ## For non-Matrix: choices = MC/Rank/etc. options.
      ## For Matrix: these are the "statements" - kept under n_choices too
      ## for symmetry, but the dedicated "statements" columns below are
      ## where matrix-row text lives.
      n_choices        = if (is_matrix) 0L else length(choices),
      choices_labels   = if (is_matrix) "" else join_labeled(choices, choice_ord),
      choices_values   = if (is_matrix) "" else paste(as.character(choice_ord),
                                                      collapse = sep),
      choices_recodes  = if (is_matrix) "" else paste(
        vapply(choice_ord, function(cid) {
          as.character(recodes[[as.character(cid)]] %||% cid)
        }, character(1)),
        collapse = sep
      ),

      n_statements     = if (is_matrix) length(choices) else 0L,
      statements_labels = if (is_matrix) join_labeled(choices, choice_ord) else "",
      statements_ids   = if (is_matrix) paste(as.character(choice_ord),
                                              collapse = sep) else "",

      n_answers        = if (is_matrix) length(answers)
                         else if (is_sbs) sum(vapply(sbs_subs, function(s)
                           length(.fld(s, "Answers") %||% list()), integer(1)))
                         else 0L,
      scale_labels     = if (is_matrix) join_labeled(answers, ans_ord)
                         else if (is_sbs) paste(vapply(sbs_subs, function(s) {
                           sub_ans <- .fld(s, "Answers") %||% list()
                           sub_ord <- resolve_order(.fld(s, "AnswerOrder"), sub_ans)
                           paste0(strip_html(.fld(s, "QuestionText") %||% ""), ": ",
                                  join_labeled(sub_ans, sub_ord))
                         }, character(1)), collapse = " || ")
                         else "",
      scale_values     = if (is_matrix) paste(as.character(ans_ord),
                                              collapse = sep) else "",
      scale_recodes    = if (is_matrix) paste(
        vapply(ans_ord, function(aid) {
          as.character(ans_rec[[as.character(aid)]] %||% aid)
        }, character(1)),
        collapse = sep
      ) else "",

      slider_min       = suppressWarnings(as.numeric(smin)),
      slider_max       = suppressWarnings(as.numeric(smax)),
      slider_step      = suppressWarnings(as.numeric(sstep)),

      validation_rules = val_str
    )
  })

  dplyr::bind_rows(rows)
}


## ==== 7. Codebook construction =============================================
## A codebook is a flat tidy table that fully describes every question.
##
## Output shape: one row per atomic "data cell":
##   - Single/multi-choice, rank, constant-sum: one row per choice
##   - Matrix (Likert/Bipolar/TE): one row per (statement x answer)
##   - Text-entry, slider, display-only: one row per question
##
## Columns (24 total):
##   - Question identity: question_id, original_qualtrics_id, block_id, block_name
##   - Question type:     question_type, question_selector, question_subselector,
##                        canonical_type, item_type (choice/statement-answer/etc.)
##   - Question text:     question_text, question_description, required
##   - Flags:             has_display_logic, has_piped_text, has_javascript,
##                        randomize_choices
##   - Choice info (MC):  choice_id, choice_label, recode_value
##   - Matrix info:       statement_id, statement_label, answer_id, answer_label,
##                        answer_recode_value
##   - Slider info:       slider_min, slider_max, slider_step
##
## Columns that don't apply to a given row are NA.

#' Build a comprehensive codebook tibble from a parsed survey definition.
#'
#' @param definition The list returned by fetch_survey_definition(). Expected
#'   to contain $Questions, $Blocks (optional for block assignment).
#' @return tibble. See the columns list in the section header above.
build_codebook <- function(definition) {
  questions <- definition$Questions %||% list()
  if (length(questions) == 0) return(tibble::tibble())

  ## Build a QID -> (block_id, block_name) lookup so we can annotate each
  ## question with the block it lives in.
  blocks <- definition$Blocks %||% list()
  qid_to_block <- list()
  for (bid in names(blocks)) {
    b <- blocks[[bid]]
    bname <- .fld(b, "Description") %||% bid
    for (el in .fld(b, "BlockElements") %||% list()) {
      qid <- .fld(el, "QuestionID")
      if (!is.null(qid) && is.character(qid)) {
        qid_to_block[[qid]] <- list(id = bid, name = bname)
      }
    }
  }

  ## Deleted questions parked in the Trash block - flagged, not hidden.
  trash_set <- .trash_qids(definition)

  ## Shared helper: base columns describing the question (same for every row
  ## emitted by that question).
  question_base <- function(q, qid) {
    qtext <- q$QuestionText %||% ""
    qtype <- q$QuestionType %||% ""
    qsel  <- q$Selector %||% ""
    qsub  <- q$SubSelector %||% ""
    qtype_key <- paste(qtype, qsel, sep = "/")
    canonical <- QUALTRICS_TYPE_MAP[[qtype_key]] %||% "unknown"
    blk <- qid_to_block[[qid]] %||% list(id = NA_character_, name = NA_character_)

    list(
      question_id            = qid,
      original_qualtrics_id  = qid,
      block_id               = blk$id,
      block_name             = blk$name,
      question_type          = qtype,
      question_selector      = qsel,
      question_subselector   = qsub,
      canonical_type         = canonical,
      question_text          = qtext,
      question_description   = q$QuestionDescription %||% NA_character_,
      required               = identical(
        .fld(.fld(.fld(q, "Validation"), "Settings"), "ForceResponse"), "ON"),
      in_trash               = qid %in% trash_set,
      has_display_logic      = !is.null(.fld(q, "DisplayLogic")),
      has_piped_text         = grepl("${", qtext, fixed = TRUE),
      has_javascript         = !is.null(.fld(q, "QuestionJS")) &&
                               nzchar(.fld(q, "QuestionJS") %||% ""),
      randomize_choices      = !is.null(.fld(q, "Randomization")) &&
                               !identical(.fld(.fld(q, "Randomization"), "Advanced"), "None") &&
                               !is.null(.fld(.fld(q, "Randomization"), "Type"))
    )
  }

  ## All possible choice/answer/statement/slider columns start as NA; we fill
  ## only the ones relevant for each row so every row has the same column set.
  na_cols <- list(
    item_type             = NA_character_,
    choice_id             = NA_character_,
    choice_label          = NA_character_,
    recode_value          = NA_character_,
    statement_id          = NA_character_,
    statement_label       = NA_character_,
    answer_id             = NA_character_,
    answer_label          = NA_character_,
    answer_recode_value   = NA_character_,
    slider_min            = NA_real_,
    slider_max            = NA_real_,
    slider_step           = NA_real_
  )

  ## Per-question row builder. Returns a list of row-lists; each row-list is
  ## later bound with the question_base() for that question.
  build_rows_for_question <- function(q, qbase) {
    qtype <- qbase$question_type
    qsel  <- qbase$question_selector

    ## ---- Matrix questions: emit (statement x answer) rows ----------------
    if (identical(qtype, "Matrix")) {
      statements <- .fld(q, "Choices") %||% list()        # rows of the matrix
      statement_order <- resolve_order(.fld(q, "ChoiceOrder"), statements)
      answers <- .fld(q, "Answers") %||% list()           # columns (the scale)
      answer_order <- resolve_order(.fld(q, "AnswerOrder"), answers)
      ## Matrix scale recodes live in RecodeValues KEYED BY ANSWER IDS
      ## ("AnswerRecodeValues" does not exist in real QSFs - verified
      ## 2026-07-05; the old code always fell back to the raw answer id and
      ## published wrong recode values for every recoded matrix).
      answer_recodes <- .fld(q, "RecodeValues") %||% list()

      if (length(statements) == 0) {
        ## Malformed matrix - still emit one row so the question appears.
        return(list(utils::modifyList(na_cols,
                    list(item_type = "matrix_malformed"))))
      }
      if (length(answers) == 0) {
        ## TE matrices (text-entry cells) may have no Answers dictionary:
        ## emit one row per statement so the statement labels survive.
        return(lapply(statement_order, function(sid) {
          sid_c <- as.character(sid)
          utils::modifyList(na_cols, list(
            item_type       = "matrix_statement",
            statement_id    = sid_c,
            statement_label = .item_display(statements[[sid_c]])
          ))
        }))
      }

      rows <- list()
      for (sid in statement_order) {
        sid_c <- as.character(sid)
        for (aid in answer_order) {
          aid_c <- as.character(aid)
          row <- utils::modifyList(na_cols, list(
            item_type           = "matrix_cell",
            statement_id        = sid_c,
            statement_label     = .item_display(statements[[sid_c]]),
            answer_id           = aid_c,
            answer_label        = .item_display(answers[[aid_c]]),
            answer_recode_value = as.character(
              answer_recodes[[aid_c]] %||% aid_c)
          ))
          rows[[length(rows) + 1]] <- row
        }
      }
      return(rows)
    }

    ## ---- Slider questions: one row PER STATEMENT (each is a data column) --
    ## Sliders store one statement per Choices entry and export one column
    ## per statement (QID_1, QID_2, ...). The old single-row version lost
    ## every statement label, making multi-slider data undecodable.
    if (identical(qtype, "Slider")) {
      cfg <- .fld(q, "Configuration") %||% list()
      vnum <- .fld(.fld(.fld(q, "Validation"), "Settings"), "ValidNumber") %||% list()
      smin <- suppressWarnings(as.numeric(
        .fld(cfg, "CSSliderMin") %||% vnum$Min %||% NA))
      smax <- suppressWarnings(as.numeric(
        .fld(cfg, "CSSliderMax") %||% vnum$Max %||% NA))
      sstep <- .slider_step(cfg)
      statements <- .fld(q, "Choices") %||% list()
      statement_order <- resolve_order(.fld(q, "ChoiceOrder"), statements)
      if (length(statement_order) == 0) {
        return(list(utils::modifyList(na_cols, list(
          item_type = "slider",
          slider_min = smin, slider_max = smax, slider_step = sstep
        ))))
      }
      return(lapply(statement_order, function(sid) {
        sid_c <- as.character(sid)
        utils::modifyList(na_cols, list(
          item_type       = "slider_statement",
          statement_id    = sid_c,
          statement_label = .item_display(statements[[sid_c]]),
          slider_min = smin, slider_max = smax, slider_step = sstep
        ))
      }))
    }

    ## ---- Timing / Meta: check BEFORE the generic Choices branch. ---------
    ## These carry Choices (First Click / Browser / ...) but are hidden
    ## instrumentation, not respondent-facing options; emit one labeled row
    ## per metric so the exported columns stay decodable.
    if (qtype %in% c("Timing", "Meta")) {
      metrics <- .fld(q, "Choices") %||% list()
      metric_order <- resolve_order(.fld(q, "ChoiceOrder"), metrics)
      base_type <- if (identical(qtype, "Timing")) "timing" else "meta"
      if (length(metric_order) == 0) {
        return(list(utils::modifyList(na_cols, list(item_type = base_type))))
      }
      return(lapply(metric_order, function(cid) {
        cid_c <- as.character(cid)
        utils::modifyList(na_cols, list(
          item_type    = base_type,
          choice_id    = cid_c,
          choice_label = .item_display(metrics[[cid_c]])
        ))
      }))
    }

    ## ---- SBS (side-by-side): rows x (sub-question x sub-answers) ---------
    ## The scale columns live in AdditionalQuestions - each a full
    ## sub-question with its own Answers/RecodeValues. The old code dropped
    ## them entirely.
    if (identical(qtype, "SBS")) {
      statements <- .fld(q, "Choices") %||% list()
      statement_order <- resolve_order(.fld(q, "ChoiceOrder"), statements)
      subs <- .fld(q, "AdditionalQuestions") %||% list()
      rows <- list()
      for (sid in statement_order) {
        sid_c <- as.character(sid)
        s_lbl <- .item_display(statements[[sid_c]])
        if (length(subs) == 0) {
          rows[[length(rows) + 1]] <- utils::modifyList(na_cols, list(
            item_type = "sbs_row", statement_id = sid_c,
            statement_label = s_lbl))
          next
        }
        for (si in seq_along(subs)) {
          sub <- subs[[si]]
          sub_text <- strip_html(.fld(sub, "QuestionText") %||%
                                 paste0("column ", si))
          sub_ans <- .fld(sub, "Answers") %||% list()
          sub_ord <- resolve_order(.fld(sub, "AnswerOrder"), sub_ans)
          sub_rec <- .fld(sub, "RecodeValues") %||% list()
          if (length(sub_ord) == 0) {
            rows[[length(rows) + 1]] <- utils::modifyList(na_cols, list(
              item_type = "sbs_cell", statement_id = sid_c,
              statement_label = s_lbl,
              answer_id = paste0("sub", si),
              answer_label = sub_text))
            next
          }
          for (aid in sub_ord) {
            aid_c <- as.character(aid)
            rows[[length(rows) + 1]] <- utils::modifyList(na_cols, list(
              item_type           = "sbs_cell",
              statement_id        = sid_c,
              statement_label     = s_lbl,
              answer_id           = paste0("sub", si, ":", aid_c),
              answer_label        = paste0(sub_text, " - ",
                                           .item_display(sub_ans[[aid_c]])),
              answer_recode_value = as.character(sub_rec[[aid_c]] %||% aid_c)
            ))
          }
        }
      }
      if (length(rows) > 0) return(rows)
      return(list(utils::modifyList(na_cols, list(item_type = "sbs_row"))))
    }

    ## ---- Questions with Choices (MC, Rank, CS, etc.): one row per choice --
    choices <- .fld(q, "Choices") %||% list()
    if (length(choices) > 0) {
      choice_order  <- resolve_order(.fld(q, "ChoiceOrder"), choices)
      recode_values <- .fld(q, "RecodeValues") %||% list()
      rows <- list()
      for (cid in choice_order) {
        cid_c <- as.character(cid)
        row <- utils::modifyList(na_cols, list(
          item_type    = "choice",
          choice_id    = cid_c,
          choice_label = .item_display(choices[[cid_c]]),
          ## as.character: Qualtrics mixes integer and string recodes inside
          ## ONE question, which crashed bind_rows (verified 2026-07-05).
          recode_value = as.character(recode_values[[cid_c]] %||% cid_c)
        ))
        rows[[length(rows) + 1]] <- row
      }
      return(rows)
    }

    ## ---- Everything else (TE, display-only, file upload): one row ---------
    item_type <- switch(qtype,
      "TE" = "text_entry",
      "DB" = "display_only",
      "FileUpload" = "file_upload",
      "no_choices"
    )
    list(utils::modifyList(na_cols, list(item_type = item_type)))
  }

  ## Iterate all questions and collect all rows.
  all_rows <- list()
  for (qid in names(questions)) {
    q <- questions[[qid]]
    qbase <- question_base(q, qid)
    item_rows <- build_rows_for_question(q, qbase)
    for (ir in item_rows) {
      all_rows[[length(all_rows) + 1]] <- c(qbase, ir)
    }
  }

  if (length(all_rows) == 0) return(tibble::tibble())

  ## Convert list-of-lists to a tibble, preserving column order.
  col_order <- c(
    "question_id","original_qualtrics_id","block_id","block_name",
    "question_type","question_selector","question_subselector","canonical_type",
    "question_text","question_description","required","in_trash",
    "has_display_logic","has_piped_text","has_javascript","randomize_choices",
    "item_type",
    "choice_id","choice_label","recode_value",
    "statement_id","statement_label",
    "answer_id","answer_label","answer_recode_value",
    "slider_min","slider_max","slider_step"
  )
  df <- dplyr::bind_rows(lapply(all_rows, as.data.frame,
                                stringsAsFactors = FALSE))
  ## Ensure all expected columns exist (in case no row populated some of them).
  for (c in col_order) if (!c %in% names(df)) df[[c]] <- NA
  tibble::as_tibble(df[, col_order])
}


## ==== 8. Portable open-schema construction =================================
## This is the centerpiece for platform independence. We translate Qualtrics's
## opaque internal representation into a self-describing JSON anyone can parse.

## Lookup table: maps (QuestionType, Selector) pairs to canonical types in our
## open schema. If a pair isn't here, we emit "unknown" + a migration note.
## This list grows as we encounter new types in the wild.
QUALTRICS_TYPE_MAP <- list(
  "MC/SAVR"     = "single_choice",   # Multiple-choice, single answer, vertical
  "MC/SAHR"     = "single_choice",   # Single answer, horizontal
  "MC/SACOL"    = "single_choice",   # Single answer, column layout
  "MC/DL"       = "single_choice",   # Drop-down list
  "MC/SB"       = "single_choice",   # Select box
  "MC/NPS"      = "single_choice",   # Net Promoter Score (0-10)
  "MC/MAVR"     = "multi_choice",    # Multi-answer, vertical
  "MC/MAHR"     = "multi_choice",    # Multi-answer, horizontal
  "MC/MACOL"    = "multi_choice",    # Multi-answer, column layout
  "MC/MSB"      = "multi_choice",    # Multi-select box
  "Matrix/Likert"      = "matrix",   # Standard Likert grid
  "Matrix/TE"          = "matrix",   # Matrix with text entry per cell
  "Matrix/Bipolar"     = "matrix",
  "Matrix/RO"          = "matrix",   # Rank-in-matrix
  "Matrix/CS"          = "matrix",   # Constant sum in matrix
  "Matrix/Profile"     = "matrix",
  "Matrix/MaxDiff"     = "matrix",
  "SBS/SBSMatrix"      = "matrix",   # Side-by-side (multi-scale grid)
  "TE/SL"       = "text_short",      # Single-line text entry
  "TE/ML"       = "text_long",       # Multi-line text entry
  "TE/ESTB"     = "text_long",       # Essay text box
  "TE/FORM"     = "form_fields",     # Form: several labeled text fields
  "Slider/HSLIDER"    = "slider",
  "Slider/HBAR"       = "slider",
  "Slider/STAR"       = "slider",    # Star rating
  "RO/Order"    = "rank",            # Rank-order (numbered list)
  "RO/DND"      = "rank",            # Rank-order (drag and drop - UI default)
  "CS/HBAR"     = "constant_sum",
  "CS/HSLIDER"  = "constant_sum",    # Constant sum slider
  "CS/VRTL"     = "constant_sum",    # Constant sum with entry boxes (default)
  "DB/TB"       = "display_only",    # Descriptive text / page break
  "DB/GRB"      = "display_only",    # Graphic block
  "FileUpload/FileUpload" = "file_upload",
  "Draw/Signature"    = "signature", # Signature pad
  "HL/Text"           = "highlight", # Highlight words in a passage
  "Timing/PageTimer"  = "timing",    # Hidden page timer (produces data cols)
  "Meta/Browser"      = "meta"       # Hidden browser info (produces data cols)
)

#' Build the platform-neutral schema from a Qualtrics definition.
#'
#' @param definition The list returned by fetch_survey_definition().
#' @return list with two elements:
#'   $schema - the portable schema (ready for jsonlite::write_json)
#'   $migration_notes - character vector of issues to flag in migration_notes.md
build_portable_schema <- function(definition) {
  notes <- character()  # Accumulator for migration warnings

  ## Top-level survey metadata.
  survey_meta <- list(
    title             = definition$SurveyName %||% "(unnamed)",
    language          = definition$SurveyLanguage %||% "en",
    source_platform   = "qualtrics",
    source_survey_id  = definition$SurveyID %||% NA_character_,
    exported_at       = format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"),
    ## 1.1 (2026-07-05): matrix questions gained statements+scale, choice
    ## values now carry the RECODE value (what appears in the response data)
    ## plus the internal qualtrics_choice_id, sliders carry min/max/step,
    ## SBS questions carry columns, Trash content is excluded from blocks.
    schema_version    = "1.1"
  )

  ## ---- Translate each question ----
  questions <- definition$Questions %||% list()
  trash_set <- .trash_qids(definition)

  ## One choice entry: value = the RECODE (matches responses_numeric data),
  ## qualtrics_choice_id = the internal id, label = display text.
  choice_entry <- function(cid, items, recodes) {
    cid_c <- as.character(cid)
    item <- items[[cid_c]]
    entry <- list(
      value               = as.character(recodes[[cid_c]] %||% cid_c),
      qualtrics_choice_id = cid_c,
      label               = .item_display(item)
    )
    if (!is.null(.fld(item, "TextEntry"))) entry$has_text_entry <- TRUE
    entry
  }

  ## Build a flat named list keyed by QID for fast lookup when assembling blocks.
  translated_questions <- purrr::imap(questions, function(q, qid) {
    ## Decode question type via the lookup table.
    qtype <- q$QuestionType %||% ""
    qtype_key <- paste(qtype, q$Selector %||% "", sep = "/")
    canonical_type <- QUALTRICS_TYPE_MAP[[qtype_key]]
    if (is.null(canonical_type)) {
      canonical_type <- "unknown"
      notes <<- c(notes, sprintf(
        "Question %s: unmapped Qualtrics type '%s' - falls back to 'unknown'.",
        qid, qtype_key
      ))
    }

    ## Detect Qualtrics-specific features that don't transfer cleanly.
    ## Piped text is scanned in the question text AND in every choice/answer
    ## label (gender-adapted Hebrew labels routinely pipe embedded data).
    qtext <- q$QuestionText %||% ""
    all_labels <- c(
      vapply(.fld(q, "Choices") %||% list(), .item_display, character(1)),
      vapply(.fld(q, "Answers") %||% list(), .item_display, character(1))
    )
    if (grepl("${", qtext, fixed = TRUE) ||
        any(grepl("${", all_labels, fixed = TRUE))) {
      notes <<- c(notes, sprintf(
        "Question %s: contains piped text (${...}) which won't transfer literally.",
        qid
      ))
    }
    if (!is.null(.fld(q, "QuestionJS")) && nzchar(.fld(q, "QuestionJS") %||% "")) {
      notes <<- c(notes, sprintf(
        "Question %s: has custom JavaScript - manual port required.",
        qid
      ))
    }
    if (!is.null(.fld(q, "SkipLogic"))) {
      notes <<- c(notes, sprintf(
        "Question %s: has SKIP LOGIC - not represented in the portable schema, manual port required.",
        qid
      ))
    }
    if (!is.null(.fld(q, "DynamicChoices"))) {
      notes <<- c(notes, sprintf(
        "Question %s: uses carry-forward choices (DynamicChoices) - manual port required.",
        qid
      ))
    }
    rnd <- .fld(q, "Randomization")
    if (!is.null(rnd) && !identical(.fld(rnd, "Advanced"), "None") &&
        !is.null(.fld(rnd, "Type"))) {
      notes <<- c(notes, sprintf(
        "Question %s: answer options are randomized (%s) - order in data may differ per respondent.",
        qid, as.character(.fld(rnd, "Type") %||% "?")
      ))
    }
    ## Choice-level display logic hides individual options conditionally.
    ch_items <- .fld(q, "Choices") %||% list()
    has_choice_logic <- any(vapply(ch_items, function(ch) {
      !is.null(.fld(ch, "DisplayLogic"))
    }, logical(1)))
    if (has_choice_logic) {
      notes <<- c(notes, sprintf(
        "Question %s: one or more CHOICES have their own display logic - manual port required.",
        qid
      ))
    }

    is_matrix <- identical(qtype, "Matrix")
    recodes <- .fld(q, "RecodeValues") %||% list()

    ## Build the choices list in display order. For Matrix questions these
    ## are the STATEMENTS (grid rows); the scale lives in Answers below.
    choices_out <- NULL
    if (length(ch_items) > 0) {
      choice_order <- resolve_order(.fld(q, "ChoiceOrder"), ch_items)
      ## Matrix RecodeValues belong to the ANSWERS, not the statements.
      choices_out <- lapply(choice_order, function(cid) {
        choice_entry(cid, ch_items, if (is_matrix) list() else recodes)
      })
    }

    ## Matrix scale: answers + their recode values (RecodeValues is keyed by
    ## answer id for Matrix questions). Without this, no Likert grid could be
    ## rebuilt from the portable schema.
    scale_out <- NULL
    if (is_matrix) {
      answers <- .fld(q, "Answers") %||% list()
      if (length(answers) > 0) {
        ans_order <- resolve_order(.fld(q, "AnswerOrder"), answers)
        scale_out <- lapply(ans_order, function(aid) {
          choice_entry(aid, answers, recodes)
        })
      }
    }

    ## SBS columns: each AdditionalQuestions entry is a sub-question with its
    ## own text + scale.
    columns_out <- NULL
    if (identical(qtype, "SBS")) {
      subs <- .fld(q, "AdditionalQuestions") %||% list()
      if (length(subs) > 0) {
        columns_out <- lapply(seq_along(subs), function(si) {
          sub <- subs[[si]]
          sub_ans <- .fld(sub, "Answers") %||% list()
          sub_ord <- resolve_order(.fld(sub, "AnswerOrder"), sub_ans)
          sub_rec <- .fld(sub, "RecodeValues") %||% list()
          list(
            index = si,
            text  = .fld(sub, "QuestionText") %||% "",
            scale = lapply(sub_ord, function(aid)
              choice_entry(aid, sub_ans, sub_rec))
          )
        })
      }
    }

    ## Slider settings so slider questions are rebuildable.
    settings_out <- NULL
    if (identical(qtype, "Slider") || identical(qtype, "CS")) {
      cfg <- .fld(q, "Configuration") %||% list()
      settings_out <- list(
        min  = suppressWarnings(as.numeric(.fld(cfg, "CSSliderMin") %||% NA)),
        max  = suppressWarnings(as.numeric(.fld(cfg, "CSSliderMax") %||% NA)),
        step = .slider_step(cfg)
      )
    }

    ## Display logic translation: presence + human-readable condition
    ## descriptions + the raw spec for manual porting.
    display_logic <- NULL
    if (!is.null(.fld(q, "DisplayLogic"))) {
      display_logic <- list(
        present = TRUE,
        conditions_text = as.list(.display_logic_text(q)),
        raw_qualtrics_spec = q$DisplayLogic
      )
      notes <<- c(notes, sprintf(
        "Question %s: has display logic - review raw_qualtrics_spec for porting.",
        qid
      ))
    }

    out <- list(
      id                    = qid,
      original_qualtrics_id = qid,
      type                  = canonical_type,
      text                  = qtext,
      required              = identical(
        .fld(.fld(.fld(q, "Validation"), "Settings"), "ForceResponse"), "ON"),
      choices               = choices_out,
      display_logic         = display_logic,
      notes                 = list()
    )
    if (!is.null(scale_out))    out$scale    <- scale_out
    if (!is.null(columns_out))  out$columns  <- columns_out
    if (!is.null(settings_out)) out$settings <- settings_out
    out
  })

  ## ---- Assemble blocks in survey-flow order ----
  ## The Trash block (deleted questions) is EXCLUDED from blocks: a migrator
  ## must not rebuild questions no participant ever saw. Trashed questions
  ## are preserved separately under trashed_questions for completeness.
  blocks <- definition$Blocks %||% list()
  live_block_ids <- names(blocks)[vapply(names(blocks), function(bid) {
    !identical(.fld(blocks[[bid]], "Type"), "Trash")
  }, logical(1))]

  ## Block-level loop & merge: promised by the docs, never detected before.
  for (bid in live_block_ids) {
    loop_opt <- .fld(.fld(blocks[[bid]], "Options"), "Looping")
    if (!is.null(loop_opt)) {
      notes <- c(notes, sprintf(
        "Block %s ('%s'): uses LOOP & MERGE - the portable schema contains one copy only, manual port required.",
        bid, .fld(blocks[[bid]], "Description") %||% ""))
    }
  }

  ## Iterate blocks in DISPLAY order (recursive flow walk first) and assign
  ## each question to the FIRST block that references it - stale Default
  ## container blocks can re-reference every QID, which would duplicate all
  ## questions in the schema.
  ord <- .ordered_blocks(definition)
  ordered_ids <- unique(c(ord$id, live_block_ids))
  ordered_ids <- ordered_ids[ordered_ids %in% live_block_ids]
  seen_qids <- character()
  blocks_out <- list()
  for (bid in ordered_ids) {
    b <- blocks[[bid]]
    block_qids <- vapply(.fld(b, "BlockElements") %||% list(), function(el) {
      .fld(el, "QuestionID") %||% NA_character_
    }, character(1))
    block_qids <- block_qids[!is.na(block_qids)]
    ## Guard: a stale block reference to a QID absent from Questions would
    ## serialize as a literal null in the questions array.
    block_qids <- intersect(block_qids, names(translated_questions))
    block_qids <- setdiff(block_qids, seen_qids)
    if (length(block_qids) == 0) next
    seen_qids <- c(seen_qids, block_qids)

    blocks_out[[length(blocks_out) + 1]] <- list(
      id        = bid,
      title     = .fld(b, "Description") %||% "",
      questions = unname(translated_questions[block_qids])
    )
  }

  trashed_out <- NULL
  if (length(trash_set) > 0) {
    keep <- intersect(trash_set, names(translated_questions))
    if (length(keep) > 0) trashed_out <- unname(translated_questions[keep])
  }

  ## ---- Survey flow (block ordering + branching) ----
  ## Qualtrics's SurveyFlow is a tree of nested {Type, FlowID, ID, Flow}.
  ## We flatten it into a linear sequence, flagging branches as a single
  ## "branch" entry with the raw spec preserved for manual porting. Notes
  ## carry the FlowID/index so 4 branches produce 4 bullets, not 1.
  flow_raw <- .fld(definition$SurveyFlow, "Flow") %||% list()
  flow_out <- lapply(seq_along(flow_raw), function(fi) {
    f <- flow_raw[[fi]]
    if (!is.list(f)) return(list(type = "qualtrics_unknown"))
    if (identical(f$Type, "Standard") || identical(f$Type, "Block")) {
      list(type = "block", ref = f$ID %||% NA_character_)
    } else if (identical(f$Type, "Branch")) {
      notes <<- c(notes, sprintf(
        "Survey flow element %s (%s): Branch - review raw spec for porting.",
        .fld(f, "FlowID") %||% fi, "conditional branch"
      ))
      list(
        type = "branch",
        raw_qualtrics_spec = f
      )
    } else {
      ## Other flow types: EmbeddedData, Authenticator, EndSurvey, etc.
      notes <<- c(notes, sprintf(
        "Survey flow element %s: '%s' - manual port required.",
        .fld(f, "FlowID") %||% fi, f$Type %||% "(unknown)"
      ))
      list(
        type = paste0("qualtrics_", tolower(f$Type %||% "unknown")),
        raw_qualtrics_spec = f
      )
    }
  })

  schema <- list(
    survey = survey_meta,
    blocks = unname(blocks_out),
    flow   = flow_out
  )
  if (!is.null(trashed_out)) schema$trashed_questions <- trashed_out

  list(
    schema = schema,
    migration_notes = unique(notes)
  )
}


## ==== 9. HTML preview rendering ============================================
## Generate a self-contained HTML file that displays the questionnaire. No JS,
## no external CSS - opens in any browser, today and in 2050.

#' Render the survey to a standalone preview HTML that mimics how the survey
#' looks in Qualtrics itself (Elad 2026-07-05): white centered survey column,
#' real (disabled) form controls, matrix grids, page breaks, RTL support.
#' Technical info (QIDs, types, value codes, flags, display-logic conditions)
#' is hidden by default and toggles on with one click; with JavaScript off it
#' is always visible (noscript fallback).
#'
#' @param definition Parsed survey definition.
#' @param survey_name Display name for the page heading.
#' @param out_path Where to write the .html file.
#' @return Invisible NULL.
render_preview_html <- function(definition, survey_name, out_path) {
  questions <- definition$Questions %||% list()
  blocks    <- definition$Blocks    %||% list()

  ## ---- Survey-level direction: title + majority of question texts ---------
  q_texts <- vapply(questions, function(q) strip_html(q$QuestionText %||% ""),
                    character(1))
  n_rtl <- sum(vapply(q_texts, .is_rtl_text, logical(1)))
  survey_rtl <- .is_rtl_text(survey_name) ||
    (length(q_texts) > 0 && n_rtl > length(q_texts) / 2)
  survey_dir <- if (survey_rtl) "rtl" else "ltr"

  ## ---- Qualtrics-like stylesheet (self-contained, no network) -------------
  css <- "
    :root { --q-blue: #0768dd; --q-text: #202124; --q-muted: #6d6e71; }
    * { box-sizing: border-box; }
    html { background: #e8e8e8; }
    body { font-family: Poppins, 'Segoe UI', Tahoma, Arial, sans-serif;
           margin: 0; padding: 24px 12px; color: var(--q-text); }
    .page-head { max-width: 780px; margin: 0 auto 14px; }
    .page-head h1 { font-size: 1.25em; margin: 0 0 6px; color: #333; }
    .meta { font-size: 0.8em; color: var(--q-muted); }
    .skin { max-width: 780px; margin: 0 auto; background: #ffffff;
            border-radius: 6px; box-shadow: 0 1px 6px rgba(0,0,0,0.18);
            padding: 34px 42px 48px; }
    .toolbar { max-width: 780px; margin: 0 auto 12px; text-align: end; }
    .toolbar button { font: inherit; font-size: 0.78em; color: #444;
            background: #fff; border: 1px solid #bbb; border-radius: 4px;
            padding: 4px 10px; cursor: pointer; }
    .toolbar button:hover { background: #f0f6ff; border-color: var(--q-blue); }

    /* Technical info hidden until toggled; always shown without JS. */
    .tech { display: none; }
    body.tech-on .tech { display: revert; }
    body.tech-on span.tech, body.tech-on .flag { display: inline-block; }

    .block-title { font-size: 0.8em; color: var(--q-muted);
            border-bottom: 1px solid #e3e3e3; padding-bottom: 4px;
            margin: 30px 0 4px; letter-spacing: 0.4px; }
    .block-sep { border: none; border-top: 1px solid #ececec; margin: 34px 0; }

    .question { padding: 18px 0 6px; page-break-inside: avoid; }
    .qtext { font-size: 1.02em; font-weight: 400; line-height: 1.5;
             margin: 0 0 14px; }
    .qtext p { margin: 0 0 6px; }
    .required-star { color: #d93025; margin-inline-start: 4px;
                     font-weight: 700; }

    .qbadges { font-size: 0.72em; color: var(--q-muted); margin: 2px 0 8px;
               font-family: Consolas, monospace; direction: ltr;
               text-align: left; }
    .qbadges .flag { background: #fdecea; color: #b3261e;
               border: 1px solid #f5c6c0; border-radius: 3px;
               padding: 0 5px; margin-inline-end: 4px; }
    .logic { font-size: 0.78em; color: #7a4d00; background: #fff8e6;
             border: 1px solid #ffe1a1; border-radius: 3px;
             padding: 2px 8px; margin: 0 0 8px; }
    .code { color: #9aa0a6; font-family: Consolas, monospace;
            font-size: 0.78em; margin-inline-start: 6px; }

    /* Choice lists - Qualtrics-style radio / checkbox rows */
    .opts { margin: 0; padding: 0; list-style: none; }
    .opts li { margin: 0; }
    label.opt { display: flex; align-items: flex-start; gap: 10px;
            padding: 7px 6px; border-radius: 4px; cursor: default;
            font-size: 0.96em; line-height: 1.45; }
    label.opt:hover { background: #f3f7fd; }
    label.opt input { width: 18px; height: 18px; margin: 2px 0 0;
            accent-color: var(--q-blue); flex: 0 0 18px; }
    .opt-label { flex: 1 1 auto; }

    /* Text entry + form fields */
    input.te-line, textarea.te-area, select.te-line { width: 100%;
            font: inherit; font-size: 0.95em; color: #555; background: #fff;
            border: 1px solid #c4c4c4; border-radius: 4px;
            padding: 8px 10px; }
    input.te-line, select.te-line { max-width: 420px; }
    textarea.te-area { resize: none; }
    .form-fields { margin: 0; padding: 0; list-style: none; max-width: 460px; }
    .form-fields li { margin: 0 0 10px; }
    .form-fields .ff-label { display: block; font-size: 0.92em;
            margin-bottom: 3px; }

    /* Matrix */
    .matrix-wrap { overflow-x: auto; }
    table.matrix { border-collapse: collapse; width: 100%;
            font-size: 0.92em; }
    table.matrix th { font-weight: 400; color: var(--q-text);
            padding: 8px 10px; text-align: center; vertical-align: bottom;
            line-height: 1.3; }
    table.matrix td { text-align: center; padding: 7px 10px; }
    table.matrix th.stmt { text-align: start; max-width: 340px;
            vertical-align: middle; }
    table.matrix tbody tr:nth-child(odd) { background: #f7f8f9; }
    table.matrix input { width: 17px; height: 17px;
            accent-color: var(--q-blue); }
    table.matrix input.mtx-te { width: 90%; min-width: 70px; height: auto;
            font: inherit; font-size: 0.9em; border: 1px solid #c4c4c4;
            border-radius: 3px; padding: 4px 6px; background: #fff; }

    /* Slider */
    .slider-row { display: flex; align-items: center; gap: 14px;
            margin: 10px 0; }
    .slider-stmt { flex: 0 0 32%; font-size: 0.93em; }
    .slider-body { flex: 1 1 auto; }
    .slider-track { position: relative; background: #d9dadb; height: 8px;
            border-radius: 4px; margin: 8px 0 6px; }
    .slider-handle { position: absolute; top: -5px; inset-inline-start: 0;
            width: 18px; height: 18px; border-radius: 50%;
            background: var(--q-blue); box-shadow: 0 1px 3px rgba(0,0,0,.35); }
    .slider-ends { display: flex; justify-content: space-between;
            font-size: 0.78em; color: var(--q-muted); }

    /* NPS 0-10 buttons */
    .nps { display: flex; gap: 6px; flex-wrap: wrap; direction: ltr; }
    .nps span { display: inline-flex; align-items: center;
            justify-content: center; width: 40px; height: 34px;
            border: 1px solid #c4c4c4; border-radius: 4px;
            font-size: 0.9em; color: #444; background: #fff; }

    /* Rank order */
    .rank { margin: 0; padding: 0; list-style: none; }
    .rank li { display: flex; align-items: center; gap: 10px;
            border: 1px solid #d9d9d9; border-radius: 4px;
            background: #fafafa; padding: 8px 12px; margin: 6px 0;
            font-size: 0.95em; }
    .rank .grip { color: #b7b7b7; font-size: 1.05em; letter-spacing: 1px; }
    .rank .rank-num { width: 30px; height: 26px; border: 1px solid #c4c4c4;
            border-radius: 4px; background: #fff; color: #888;
            display: inline-flex; align-items: center;
            justify-content: center; font-size: 0.85em; }

    /* Constant sum */
    .csum { margin: 0; padding: 0; list-style: none; max-width: 460px; }
    .csum li { display: flex; align-items: center; gap: 12px;
            padding: 5px 4px; font-size: 0.95em; }
    .csum .cs-label { flex: 1 1 auto; }
    .csum input { width: 74px; font: inherit; font-size: 0.9em;
            border: 1px solid #c4c4c4; border-radius: 4px;
            padding: 5px 8px; text-align: center; background: #fff; }
    .csum-total { border-top: 1px solid #ddd; margin-top: 6px;
            padding-top: 8px; font-weight: 600; }

    /* File upload */
    .upload-box { border: 2px dashed #b9c7dd; border-radius: 6px;
            background: #f7fafd; color: #5f6b7a; text-align: center;
            padding: 26px 12px; font-size: 0.92em; max-width: 460px; }

    /* Highlight question */
    .hl-text { background: #fffde7; border: 1px solid #f2e9a8;
            border-radius: 4px; padding: 12px 14px; line-height: 1.9;
            font-size: 0.97em; }
    .hl-text span:hover { background: #ffe082; }

    /* Page break - mirrors where Qualtrics starts a new page */
    .page-break { display: flex; align-items: center; gap: 10px;
            margin: 26px 0; color: #9aa0a6; font-size: 0.72em;
            text-transform: uppercase; letter-spacing: 1px; }
    .page-break::before, .page-break::after { content: '';
            flex: 1 1 auto; border-top: 2px dashed #d5d5d5; }

    .display-only { color: var(--q-text); }
    .unknown-note { font-size: 0.8em; color: #b3261e; font-style: italic; }
    .empty-note { color: var(--q-muted); font-style: italic;
            font-size: 0.9em; }

    /* Survey flow - what appeared to whom */
    .flow-card { max-width: 780px; margin: 0 auto 14px; background: #ffffff;
            border: 1px solid #dfe3e8; border-radius: 6px;
            box-shadow: 0 1px 4px rgba(0,0,0,0.10); padding: 14px 20px 18px; }
    .flow-card > summary { cursor: pointer; font-size: 0.92em; font-weight: 600;
            color: #333; list-style: revert; }
    .flow-card .flow-intro { font-size: 0.8em; color: var(--q-muted);
            margin: 8px 0 10px; }
    ul.flow-tree { list-style: none; margin: 6px 0 0; padding: 0;
            font-size: 0.86em; line-height: 1.5; }
    ul.flow-tree ul { list-style: none; margin: 0;
            padding-inline-start: 20px;
            border-inline-start: 1px dashed #d5dbe2; }
    ul.flow-tree li { margin: 3px 0; }
    .fl-block  { color: #202124; }
    .fl-block .fl-tag { background: #eef4ff; color: #0768dd; }
    .fl-branch .fl-tag { background: #fff4e5; color: #b3660e; }
    .fl-rand .fl-tag   { background: #f0eaff; color: #6f42c1; }
    .fl-group .fl-tag  { background: #eafaf0; color: #1f883d; }
    .fl-embed .fl-tag  { background: #f2f2f2; color: #555; }
    .fl-end .fl-tag    { background: #fdecea; color: #b3261e; }
    .fl-tag { font-size: 0.82em; font-weight: 600; border-radius: 3px;
            padding: 0 6px; margin-inline-end: 6px; }
    .fl-cond { color: #7a4d00; }
    .fl-id { color: #9aa0a6; font-family: Consolas, monospace;
            font-size: 0.82em; margin-inline-start: 6px; }

    @media print {
      html { background: #fff; }
      .skin { box-shadow: none; padding: 0; }
      .toolbar { display: none; }
      .question { page-break-inside: avoid; }
      .flow-card { box-shadow: none; }
      .flow-card[open] > summary { display: none; }
    }
  "

  ## Tiny inline toggle - works offline; without JS the noscript rule keeps
  ## technical info permanently visible instead of unreachable.
  toggle_js <- "document.body.classList.toggle('tech-on');"

  ## ---- Helper: one choice list as disabled radios / checkboxes ------------
  render_opts <- function(q, input_type) {
    choices    <- .fld(q, "Choices") %||% list()
    choice_ord <- resolve_order(.fld(q, "ChoiceOrder"), choices)
    recode_values <- .fld(q, "RecodeValues") %||% list()
    if (length(choices) == 0) {
      return(htmltools::tags$div(class = "empty-note", "(no answer options)"))
    }
    htmltools::tags$ul(class = "opts",
      lapply(choice_ord, function(cid) {
        cid_c  <- as.character(cid)
        choice <- choices[[cid_c]]
        recode <- as.character(recode_values[[cid_c]] %||% cid_c)
        code_txt <- paste0("[", cid_c,
                           if (!identical(recode, cid_c))
                             paste0("=", recode) else "", "]")
        te_val <- .fld(choice, "TextEntry")
        has_te <- !is.null(te_val) && identical(as.character(te_val), "true")
        htmltools::tags$li(
          htmltools::tags$label(class = "opt",
            htmltools::tags$input(type = input_type, disabled = NA),
            htmltools::tags$span(class = "opt-label",
              htmltools::HTML(.item_display(choice)),
              if (has_te) htmltools::tags$input(
                class = "te-line", type = "text", disabled = NA,
                style = "max-width:220px;margin-inline-start:8px;"
              ),
              htmltools::tags$span(class = "code tech", code_txt)
            )
          )
        )
      })
    )
  }

  ## ---- Helper: matrix as a striped grid of radios/checkboxes/text ---------
  render_matrix <- function(q) {
    statements <- .fld(q, "Choices") %||% list()
    stmt_order <- resolve_order(.fld(q, "ChoiceOrder"), statements)
    answers    <- .fld(q, "Answers") %||% list()
    ans_order  <- resolve_order(.fld(q, "AnswerOrder"), answers)
    sub <- .fld(q, "SubSelector") %||% ""
    sel <- .fld(q, "Selector") %||% ""

    if (length(statements) == 0) {
      return(htmltools::tags$div(class = "empty-note",
                                 "(matrix with no statements)"))
    }
    cell_input <- if (identical(sel, "TE")) "te"
      else if (identical(sub, "MultipleAnswer")) "checkbox" else "radio"

    ## TE matrices may have no Answers dictionary: single text column.
    if (length(ans_order) == 0) ans_order <- ""

    htmltools::tags$div(class = "matrix-wrap",
      htmltools::tags$table(class = "matrix",
        htmltools::tags$thead(
          htmltools::tags$tr(
            htmltools::tags$th(class = "stmt", ""),
            lapply(ans_order, function(aid) {
              lbl <- if (nzchar(aid)) .item_display(answers[[as.character(aid)]]) else ""
              htmltools::tags$th(
                htmltools::HTML(lbl),
                if (nzchar(aid)) htmltools::tags$span(
                  class = "code tech", paste0("[", aid, "]"))
              )
            })
          )
        ),
        htmltools::tags$tbody(
          lapply(stmt_order, function(sid) {
            slbl <- .item_display(statements[[as.character(sid)]])
            htmltools::tags$tr(
              htmltools::tags$th(class = "stmt", htmltools::HTML(slbl)),
              lapply(ans_order, function(aid) {
                htmltools::tags$td(
                  if (identical(cell_input, "te")) {
                    htmltools::tags$input(class = "mtx-te", type = "text",
                                          disabled = NA)
                  } else {
                    htmltools::tags$input(type = cell_input, disabled = NA)
                  }
                )
              })
            )
          })
        )
      )
    )
  }

  ## ---- Helper: slider(s) - one track per statement -------------------------
  render_slider <- function(q) {
    cfg  <- .fld(q, "Configuration") %||% list()
    vmin <- .fld(cfg, "CSSliderMin") %||% "0"
    vmax <- .fld(cfg, "CSSliderMax") %||% "100"
    statements <- .fld(q, "Choices") %||% list()
    stmt_order <- resolve_order(.fld(q, "ChoiceOrder"), statements)

    one_track <- function() {
      htmltools::tags$div(class = "slider-body",
        htmltools::tags$div(class = "slider-track",
          htmltools::tags$div(class = "slider-handle")),
        htmltools::tags$div(class = "slider-ends",
          htmltools::tags$span(as.character(vmin)),
          htmltools::tags$span(as.character(vmax)))
      )
    }
    if (length(stmt_order) == 0) return(one_track())
    lapply(stmt_order, function(sid) {
      slbl <- .item_display(statements[[as.character(sid)]])
      htmltools::tags$div(class = "slider-row",
        htmltools::tags$div(class = "slider-stmt", htmltools::HTML(slbl)),
        one_track()
      )
    })
  }

  ## ---- Helper: one question ------------------------------------------------
  render_question <- function(qid, q) {
    qtext     <- q$QuestionText %||% ""
    qtype     <- q$QuestionType %||% ""
    qsel      <- q$Selector %||% ""
    qtype_key <- paste(qtype, qsel, sep = "/")
    canonical <- QUALTRICS_TYPE_MAP[[qtype_key]] %||% "unknown"
    is_required <- identical(
      .fld(.fld(.fld(q, "Validation"), "Settings"), "ForceResponse"), "ON")
    q_dir <- if (.is_rtl_text(strip_html(qtext))) "rtl" else "ltr"

    flags <- list()
    if (!is.null(.fld(q, "DisplayLogic")))
      flags <- c(flags, list(htmltools::tags$span(class = "flag",
        title = "This question has display logic - it only appears under certain conditions.",
        "display logic")))
    if (!is.null(.fld(q, "SkipLogic")))
      flags <- c(flags, list(htmltools::tags$span(class = "flag",
        title = "This question triggers skip logic.",
        "skip logic")))
    if (!is.null(.fld(q, "QuestionJS")) && nzchar(.fld(q, "QuestionJS") %||% ""))
      flags <- c(flags, list(htmltools::tags$span(class = "flag",
        title = "This question runs custom JavaScript in Qualtrics.",
        "custom JS")))
    if (!is.null(.fld(q, "Randomization")) &&
        !identical(.fld(.fld(q, "Randomization"), "Advanced"), "None") &&
        !is.null(.fld(.fld(q, "Randomization"), "Type")))
      flags <- c(flags, list(htmltools::tags$span(class = "flag",
        title = "Answer options are shown in randomized order.",
        "randomized")))
    if (grepl("${", qtext, fixed = TRUE))
      flags <- c(flags, list(htmltools::tags$span(class = "flag",
        title = "Text is inserted here dynamically (piped text).",
        "piped text")))

    ## Human-readable display-logic conditions (tech mode): the single most
    ## valuable annotation for reconstructing what participants saw.
    logic_lines <- .display_logic_text(q)
    logic_div <- if (length(logic_lines) > 0) {
      htmltools::tags$div(class = "logic tech",
        paste("Shown if:", paste(logic_lines, collapse = " / ")))
    } else NULL

    body_html <-
      if (identical(qtype, "Matrix")) {
        render_matrix(q)
      } else if (identical(qtype, "Slider")) {
        render_slider(q)
      } else if (identical(qtype, "TE") && identical(qsel, "FORM")) {
        ## Form-style text entry: each Choice is a labeled field.
        fields <- .fld(q, "Choices") %||% list()
        f_ord <- resolve_order(.fld(q, "ChoiceOrder"), fields)
        htmltools::tags$ul(class = "form-fields",
          lapply(f_ord, function(cid) {
            htmltools::tags$li(
              htmltools::tags$span(class = "ff-label",
                htmltools::HTML(.item_display(fields[[as.character(cid)]]))),
              htmltools::tags$input(class = "te-line", type = "text",
                                    disabled = NA)
            )
          })
        )
      } else if (identical(qtype, "TE")) {
        if (qsel %in% c("ML", "ESTB")) {
          htmltools::tags$textarea(class = "te-area", rows = "4",
                                   disabled = NA, "")
        } else {
          htmltools::tags$input(class = "te-line", type = "text",
                                disabled = NA)
        }
      } else if (identical(qtype, "MC") && identical(qsel, "NPS")) {
        htmltools::tags$div(class = "nps",
          lapply(0:10, function(i) htmltools::tags$span(i)))
      } else if (identical(qtype, "RO")) {
        choices    <- .fld(q, "Choices") %||% list()
        choice_ord <- resolve_order(.fld(q, "ChoiceOrder"), choices)
        htmltools::tags$ul(class = "rank",
          lapply(choice_ord, function(cid) {
            htmltools::tags$li(
              htmltools::tags$span(class = "rank-num", ""),
              htmltools::tags$span(class = "grip", "::"),
              htmltools::tags$span(
                htmltools::HTML(.item_display(choices[[as.character(cid)]]))),
              htmltools::tags$span(class = "code tech",
                                   paste0("[", cid, "]"))
            )
          })
        )
      } else if (identical(qtype, "CS")) {
        choices    <- .fld(q, "Choices") %||% list()
        choice_ord <- resolve_order(.fld(q, "ChoiceOrder"), choices)
        htmltools::tags$ul(class = "csum",
          lapply(choice_ord, function(cid) {
            htmltools::tags$li(
              htmltools::tags$span(class = "cs-label",
                htmltools::HTML(.item_display(choices[[as.character(cid)]]))),
              htmltools::tags$input(type = "text", disabled = NA,
                                    placeholder = "0")
            )
          }),
          htmltools::tags$li(class = "csum-total",
            htmltools::tags$span(class = "cs-label", "Total"),
            htmltools::tags$input(type = "text", disabled = NA,
                                  placeholder = "0"))
        )
      } else if (identical(qtype, "HL")) {
        ## Highlight question: reconstruct the passage as inline word spans.
        choices    <- .fld(q, "Choices") %||% list()
        choice_ord <- resolve_order(.fld(q, "ChoiceOrder"), choices)
        words <- vapply(choice_ord, function(cid) {
          strip_html(.item_display(choices[[as.character(cid)]]))
        }, character(1))
        htmltools::tagList(
          htmltools::tags$div(class = "hl-text",
            lapply(words, function(w) htmltools::tagList(
              htmltools::tags$span(w), " "))),
          htmltools::tags$div(class = "empty-note",
            "(highlight question - respondents mark words in the text above)")
        )
      } else if (identical(qtype, "FileUpload") || identical(canonical, "file_upload")) {
        htmltools::tags$div(class = "upload-box",
          "Drop files or click here to upload")
      } else if (identical(qtype, "DB")) {
        NULL  ## descriptive text - the question text IS the content
      } else if (qtype %in% c("Timing", "Meta")) {
        htmltools::tags$div(class = "empty-note tech",
          if (identical(qtype, "Timing")) {
            "(hidden page timer - records timing, respondents see nothing)"
          } else {
            "(hidden browser-info question - respondents see nothing)"
          })
      } else if (identical(qtype, "MC")) {
        input_type <- if (canonical == "multi_choice") "checkbox" else "radio"
        ## Dropdown selectors render as a select-looking box.
        if (qsel %in% c("DL", "SB")) {
          htmltools::tags$div(
            htmltools::tags$select(class = "te-line", disabled = NA,
              htmltools::tags$option("Please select...")))
        } else {
          render_opts(q, input_type)
        }
      } else {
        ## Unknown type: show choices if any + honest note.
        ch <- .fld(q, "Choices") %||% list()
        htmltools::tagList(
          if (length(ch) > 0) render_opts(q, "radio"),
          htmltools::tags$div(class = "unknown-note tech",
            paste0("(question type ", qtype_key,
                   " has no exact preview - shown as a generic list)"))
        )
      }

    htmltools::tags$div(class = "question", dir = q_dir,
      htmltools::tags$div(class = "qbadges tech",
        paste(qid, qtype_key, canonical, sep = "  |  "),
        if (length(flags) > 0) htmltools::tagList(" ", flags)
      ),
      logic_div,
      htmltools::tags$div(class = "qtext",
        htmltools::HTML(qtext),
        if (is_required) htmltools::tags$span(class = "required-star",
          title = "Required question", htmltools::HTML("&#42;"))
      ),
      body_html
    )
  }

  ## ---- Blocks: FULL flow walk (nested branches/groups/randomizers too) ----
  ord <- .ordered_blocks(definition)
  rendered_qids <- character()

  ## One block section. Walks BlockElements in order and renders BOTH
  ## questions AND page breaks, so the preview mirrors the full survey.
  ## Each question renders AT MOST ONCE: some surveys keep a stale Default
  ## container block that references every QID on top of the real Standard
  ## blocks - without the rendered_qids guard those questions all doubled.
  render_block <- function(bid, conditional, bi) {
    b <- blocks[[bid]]
    if (is.null(b)) return(NULL)
    els <- .fld(b, "BlockElements") %||% list()
    if (length(els) == 0) return(NULL)
    has_any_q <- any(vapply(els, function(el) {
      qid <- .fld(el, "QuestionID")
      !is.null(qid) && qid %in% names(questions) &&
        !(qid %in% rendered_qids)
    }, logical(1)))
    if (!has_any_q) return(NULL)

    content <- lapply(els, function(el) {
      if (identical(.fld(el, "Type"), "Page Break")) {
        return(htmltools::tags$div(class = "page-break",
          htmltools::tags$span("Page break")))
      }
      qid <- .fld(el, "QuestionID")
      if (is.null(qid) || !(qid %in% names(questions)) ||
          qid %in% rendered_qids) return(NULL)
      rendered_qids <<- c(rendered_qids, qid)
      render_question(qid, questions[[qid]])
    })

    htmltools::tags$section(
      if (bi > 1) htmltools::tags$hr(class = "block-sep"),
      htmltools::tags$div(class = "block-title tech",
        paste0(.fld(b, "Description") %||% bid,
               if (conditional) "  (conditional - shown via branch logic)" else "")),
      content
    )
  }

  block_sections <- lapply(seq_len(nrow(ord)), function(bi) {
    render_block(ord$id[bi], ord$conditional[bi], bi)
  })

  ## Anything in Questions but never rendered (trashed / unassigned) goes to
  ## a technical-only appendix, so the backup preview truly shows EVERYTHING
  ## while the default view still matches what respondents saw.
  leftover_qids <- setdiff(names(questions), rendered_qids)
  leftover_section <- if (length(leftover_qids) > 0) {
    htmltools::tags$section(class = "tech",
      htmltools::tags$hr(class = "block-sep"),
      htmltools::tags$div(class = "block-title",
        sprintf("Unused / trashed questions (%d) - NOT shown to respondents",
                length(leftover_qids))),
      lapply(leftover_qids, function(qid)
        render_question(qid, questions[[qid]]))
    )
  } else NULL

  ## ---- Survey flow section ("what appeared to whom") ----------------------
  ## Render the SurveyFlow tree as a nested <ul> so a human opening the preview
  ## sees the branching/randomization/embedded-data logic, not just the linear
  ## question list. Uses the same decoders as survey_flow.txt.
  flow_html_tree <- function(flow, depth = 0) {
    if (length(flow) == 0) return(NULL)
    items <- lapply(flow, function(f) {
      if (!is.list(f)) return(NULL)
      type <- .fld(f, "Type") %||% "(unknown)"
      tag  <- function(cls, label, main, cond = NULL, idtxt = NULL, kids = NULL) {
        htmltools::tags$li(class = cls,
          htmltools::tags$span(class = "fl-tag", label),
          htmltools::HTML(htmltools::htmlEscape(main)),
          if (!is.null(cond))
            htmltools::tags$span(class = "fl-cond", htmltools::HTML(
              htmltools::htmlEscape(cond))),
          if (!is.null(idtxt))
            htmltools::tags$span(class = "fl-id tech", idtxt),
          kids)
      }
      if (type %in% c("Standard", "Block")) {
        bid <- .fld(f, "ID") %||% "(no id)"
        bname <- .fld(blocks[[bid]], "Description") %||% bid
        tag("fl-block", "Block", bname, idtxt = bid)
      } else if (identical(type, "Branch")) {
        bdesc <- .fld(f, "Description")
        clauses <- .render_boolean_expression(.fld(f, "BranchLogic") %||% list())
        cond <- if (length(clauses) == 0) "(always)"
                else paste0("if ", paste(clauses, collapse = "  /  "))
        main <- if (!is.null(bdesc) && nzchar(bdesc))
          paste0("'", strip_html(bdesc), "' ") else ""
        tag("fl-branch", "Branch", main, cond = cond,
            kids = flow_html_tree(.fld(f, "Flow") %||% list(), depth + 1))
      } else if (identical(type, "BlockRandomizer")) {
        nested <- .fld(f, "Flow") %||% list()
        sub  <- .fld(f, "SubSet")
        even <- isTRUE(.fld(f, "EvenPresentation"))
        pres <- if (!is.null(sub) && nzchar(as.character(sub)))
          as.character(sub) else "all"
        main <- paste0("present ", pres, " of ", length(nested),
                       if (even) ", evenly balanced" else "")
        tag("fl-rand", "Randomizer", main,
            kids = flow_html_tree(nested, depth + 1))
      } else if (identical(type, "Group")) {
        gdesc <- .fld(f, "Description")
        main <- if (!is.null(gdesc) && nzchar(gdesc)) strip_html(gdesc) else ""
        tag("fl-group", "Group", main,
            kids = flow_html_tree(.fld(f, "Flow") %||% list(), depth + 1))
      } else if (identical(type, "EmbeddedData")) {
        fields <- .render_embedded_fields(f)
        tag("fl-embed", "Embedded data",
            if (length(fields) > 0) paste(fields, collapse = "; ") else "(none)")
      } else if (identical(type, "EndSurvey")) {
        et <- .fld(f, "EndingType") %||% "Default"
        tag("fl-end", "End of survey", paste0("(", et, ")"))
      } else if (identical(type, "Authenticator")) {
        tag("fl-branch", "Authenticator", "",
            kids = flow_html_tree(.fld(f, "Flow") %||% list(), depth + 1))
      } else {
        extra <- .fld(f, "Description") %||% ""
        tag("fl-embed", type, if (nzchar(extra)) strip_html(extra) else "",
            kids = { n <- .fld(f, "Flow")
                     if (!is.null(n) && length(n) > 0)
                       flow_html_tree(n, depth + 1) else NULL })
      }
    })
    htmltools::tags$ul(class = if (depth == 0) "flow-tree" else NULL, items)
  }

  flow_root <- .fld(definition$SurveyFlow, "Flow") %||% list()
  flow_section <- htmltools::tags$details(class = "flow-card", open = NA,
    htmltools::tags$summary("Survey flow - what appeared to whom"),
    htmltools::tags$div(class = "flow-intro",
      "The order and logic Qualtrics used to decide what each respondent saw: ",
      "blocks, branch conditions, randomizers, embedded data, and endings. ",
      "Indentation shows nesting."),
    if (length(flow_root) == 0)
      htmltools::tags$div(class = "empty-note",
        "This survey has no explicit flow - blocks run in their natural order.")
    else flow_html_tree(flow_root)
  )

  ## ---- Assemble ------------------------------------------------------------
  ## Head and body are rendered separately and wrapped in a manual <html>
  ## string - htmltools::tags$html() drops its <head> child during rendering
  ## (quirk verified 2026-04-24).
  head_tag <- htmltools::tags$head(
    htmltools::tags$meta(charset = "UTF-8"),
    htmltools::tags$meta(name = "viewport",
                         content = "width=device-width, initial-scale=1"),
    htmltools::tags$title(paste("Survey Preview:", survey_name)),
    htmltools::tags$style(htmltools::HTML(css)),
    htmltools::HTML("<noscript><style>.tech{display:revert}span.tech,.flag{display:inline-block}</style></noscript>")
  )

  body_tag <- htmltools::tags$body(dir = survey_dir,
    htmltools::tags$div(class = "page-head",
      htmltools::tags$h1(survey_name),
      htmltools::tags$div(class = "meta",
        sprintf(
          "Backup preview | Source: Qualtrics (%s) | Questions: %d | Blocks: %d | Generated: %s",
          definition$SurveyID %||% "?",
          length(questions), length(blocks),
          format(Sys.time(), "%Y-%m-%d %H:%M")
        )
      )
    ),
    flow_section,
    htmltools::tags$div(class = "toolbar",
      htmltools::tags$button(type = "button", onclick = toggle_js,
        "Show / hide technical info (QIDs, types, value codes)")
    ),
    htmltools::tags$div(class = "skin", block_sections, leftover_section)
  )

  lang_attr <- htmltools::htmlEscape(definition$SurveyLanguage %||%
                                     (if (survey_rtl) "he" else "en"),
                                     attribute = TRUE)
  html_doc <- paste0(
    "<!DOCTYPE html>\n",
    sprintf('<html lang="%s" dir="%s">\n', lang_attr, survey_dir),
    htmltools::doRenderTags(head_tag), "\n",
    htmltools::doRenderTags(body_tag), "\n",
    "</html>\n"
  )
  con <- file(out_path, open = "w", encoding = "UTF-8")
  writeLines(html_doc, con = con)
  close(con)
  invisible(NULL)
}


## ==== 9b. Logging helper (CLI + callback) ==================================
## Functions that do progress-reporting work call log_it() instead of cli::*
## directly. When an `on_log` callback is supplied (e.g. by the Shiny app),
## messages go there too. If no callback is supplied, we fall back to cli.
##
## This one helper is the reason the same codebase can run from the terminal
## (with pretty cli output) OR from a Shiny server (streaming to the browser).

#' Emit a log message at a given severity.
#' @param on_log Optional callback: function(level, message). NULL for CLI-only.
#' @param level  One of "info", "success", "warning", "danger".
#' @param message Character. The message to emit.
log_it <- function(on_log, level, message) {
  ## Defensive redaction: token-shaped strings (35+ alphanumerics) never
  ## belong in a log, whatever the caller passed.
  message <- gsub("[A-Za-z0-9]{35,}", "[REDACTED]", message)

  ## cli interpolates {braces} via glue - a survey name containing '{' (or a
  ## JSON error body) would CRASH the whole run. Double braces = literal.
  cli_msg <- gsub("}", "}}", gsub("{", "{{", message, fixed = TRUE),
                  fixed = TRUE)

  ## Always print to the CLI (for terminal visibility + R console logs).
  switch(level,
    info    = cli::cli_alert_info(cli_msg),
    success = cli::cli_alert_success(cli_msg),
    warning = cli::cli_alert_warning(cli_msg),
    danger  = cli::cli_alert_danger(cli_msg),
    cli::cli_alert(cli_msg)
  )
  ## If a callback was supplied, forward the message so e.g. Shiny can stream it.
  if (!is.null(on_log)) {
    tryCatch(on_log(level, message), error = function(e) {
      ## A broken callback must not crash the backup.
      cli::cli_alert_warning("on_log callback failed")
    })
  }
  invisible(NULL)
}


## ==== 9c. Filesystem helpers ===============================================

#' Sanitize a survey name so it's safe to use as a folder name.
#'
#' Replaces ONLY the characters that would actually break a filesystem path.
#' Unicode characters (Hebrew, Arabic, Chinese, emoji, etc.) pass through
#' unchanged. Windows's forbidden set is the union of: < > : " / \ | ? *,
#' control chars 0x00-0x1F, and trailing dots/spaces.
#'
#' The earlier implementation used a character-class regex with a Hebrew
#' Unicode range escape, which required PCRE UTF mode - not reliable across
#' R builds and Windows locales, and caused "invalid regular expression"
#' errors when the locale was CP1255 instead of UTF-8.
#'
#' @param name Character. Raw survey name.
#' @param max_len Integer. Truncate to this length. 80 is a sensible default
#'   that leaves room for the "__<SV_id>" suffix under Windows's 260-char
#'   path limit.
#' @return Character. Sanitized name.
safe_folder_name <- function(name, max_len = 80) {
  ## Windows-forbidden chars: < > : " / \ | ? *  (no Unicode, no control chars
  ## in practice - Qualtrics survey names don't contain bytes <0x20).
  ## Do NOT use \x00-\x1f without perl=TRUE: basic R regex would treat that
  ## as literal ranges and eat digits and letters.
  safe <- gsub('[<>:"/\\\\|?*]', "_", name)
  ## Strip control chars too via perl mode, just in case.
  safe <- gsub("[\\x00-\\x1f]", "_", safe, perl = TRUE)
  safe <- substr(safe, 1, max_len)
  ## Trim AFTER truncating too - truncation can reintroduce a trailing dot
  ## or space, which Windows forbids.
  safe <- gsub("[. ]+$", "", safe)
  ## Windows reserved device names (CON, PRN, AUX, NUL, COM1-9, LPT1-9)
  ## cannot be used as file/folder names, with or without an extension.
  if (grepl("^(?i)(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])$", safe, perl = TRUE)) {
    safe <- paste0(safe, "_")
  }
  if (!nzchar(safe)) safe <- "unnamed"
  safe
}


## ==== 9d. Word (.docx) export ==============================================
## Build a Word document from a parsed survey definition. Uses `officer` for
## a clean native .docx (no pandoc dependency). Matrix questions render as
## real Word tables via `flextable`. HTML tags inside question text are
## stripped so plain text lands on the page - Word has its own paragraph
## formatting and can't render arbitrary HTML.

#' Strip HTML tags + decode a few common entities. Used only inside the docx
#' renderer - the HTML preview keeps full formatting via HTML() passthrough.
#' @param x Character vector.
#' @return Character vector with tags removed.
strip_html <- function(x) {
  if (is.null(x) || length(x) == 0) return("")
  ## Block-level boundaries become spaces BEFORE tag removal - otherwise
  ## "line one<br>line two" would glue into "line oneline two".
  s <- gsub("(?i)<(br|/p|/div|/li|/tr|/h[1-6])[^>]*>", " ", x, perl = TRUE)
  s <- gsub("<[^>]+>", "", s)      # remaining tags
  s <- gsub("&nbsp;", " ", s, fixed = TRUE)
  s <- gsub("&amp;", "&", s, fixed = TRUE)
  s <- gsub("&lt;", "<", s, fixed = TRUE)
  s <- gsub("&gt;", ">", s, fixed = TRUE)
  s <- gsub("&quot;", '"', s, fixed = TRUE)
  s <- gsub("&#39;", "'", s, fixed = TRUE)
  s <- gsub("&apos;", "'", s, fixed = TRUE)
  ## Common typographic entities -> ASCII equivalents (CP1255-safe).
  s <- gsub("&(ndash|mdash);", "-", s)
  s <- gsub("&(ldquo|rdquo);", '"', s)
  s <- gsub("&(lsquo|rsquo);", "'", s)
  s <- gsub("&hellip;", "...", s, fixed = TRUE)
  ## Numeric entities (decimal + hex) -> the actual character.
  decode_num <- function(str) {
    m <- gregexpr("&#x?[0-9A-Fa-f]+;", str)
    regmatches(str, m) <- lapply(regmatches(str, m), function(ents) {
      vapply(ents, function(e) {
        code <- sub("^&#x?", "", sub(";$", "", e))
        n <- if (grepl("^&#x", e)) strtoi(code, 16L) else strtoi(code, 10L)
        if (!is.na(n) && n > 31 && n < 0x10FFFF) intToUtf8(n) else e
      }, character(1))
    })
    str
  }
  s <- tryCatch(decode_num(s), error = function(e) s)
  s <- gsub("[[:space:]]+", " ", s) # collapse whitespace
  trimws(s)
}

#' Render a survey definition to a .docx file.
#'
#' Output structure:
#'   Heading 1: survey name
#'   Normal:    meta line (source, question count, block count, generated)
#'   Per block:
#'     Heading 2: block name
#'     Per question:
#'       Small gray line: QID | canonical type | required flag
#'       Normal:          question text (HTML stripped)
#'       If MC/Rank/CS:   bulleted list of choices
#'       If Matrix:       flextable - statements as rows, answers as columns
#'       If Slider:       "[slider: min - max, step: N]"
#'       If TE:           "[free text]"
#'
#' Requires the `officer` and `flextable` R packages.
#'
#' @param definition Parsed survey definition.
#' @param survey_name Survey name (used as the doc heading).
#' @param out_path Where to write the .docx.
#' @return Invisible NULL.
render_preview_docx <- function(definition, survey_name, out_path) {
  if (!requireNamespace("officer", quietly = TRUE) ||
      !requireNamespace("flextable", quietly = TRUE)) {
    stop("render_preview_docx needs the 'officer' and 'flextable' packages.")
  }

  questions <- definition$Questions %||% list()
  blocks    <- definition$Blocks    %||% list()

  doc <- officer::read_docx()

  ## Title + meta.
  doc <- officer::body_add_par(doc, survey_name, style = "heading 1")
  doc <- officer::body_add_par(doc,
    sprintf("Source: Qualtrics (%s)  |  Questions: %d  |  Blocks: %d  |  Generated: %s",
            definition$SurveyID %||% "?",
            length(questions), length(blocks),
            format(Sys.time(), "%Y-%m-%d %H:%M")),
    style = "Normal")

  ## ---- Survey flow ("what appeared to whom") ----
  ## Reuse the same indented renderer as survey_flow.txt so Word readers see
  ## the branching/randomization/embedded-data logic. Each line is a
  ## monospace paragraph; leading spaces show nesting.
  flow_root_docx <- .fld(definition$SurveyFlow, "Flow") %||% list()
  doc <- officer::body_add_par(doc, "Survey flow - what appeared to whom",
                               style = "heading 2")
  if (length(flow_root_docx) == 0) {
    doc <- officer::body_add_par(doc,
      "This survey has no explicit flow - blocks run in their natural order.",
      style = "Normal")
  } else {
    for (fl_line in .render_flow_lines(flow_root_docx, blocks, depth = 0)) {
      doc <- officer::body_add_fpar(doc, officer::fpar(
        officer::ftext(fl_line,
                       prop = officer::fp_text(font.size = 9,
                                               font.family = "Consolas"))))
    }
  }

  ## Block order: FULL recursive flow walk (Branch/Group/BlockRandomizer
  ## children included), then leftover non-Trash blocks - same logic as the
  ## HTML preview, so Word and HTML show the same complete survey.
  ord_blocks <- .ordered_blocks(definition)

  ## Per-question renderer into the current `doc` (returns the modified doc).
  add_question <- function(doc, qid, q) {
    qtype <- q$QuestionType %||% ""
    qsel  <- q$Selector %||% ""
    qtype_key <- paste(qtype, qsel, sep = "/")
    canonical <- QUALTRICS_TYPE_MAP[[qtype_key]] %||% "unknown"
    is_required <- identical(
      .fld(.fld(.fld(q, "Validation"), "Settings"), "ForceResponse"), "ON")

    ## Info line (QID + type + required).
    info_parts <- c(qid, canonical)
    if (is_required) info_parts <- c(info_parts, "* required")
    if (!is.null(.fld(q, "DisplayLogic"))) {
      logic_lines <- .display_logic_text(q)
      info_parts <- c(info_parts, if (length(logic_lines) > 0) {
        paste0("[shown if: ", paste(logic_lines, collapse = " / "), "]")
      } else "[display logic]")
    }
    if (grepl("${", q$QuestionText %||% "", fixed = TRUE))
      info_parts <- c(info_parts, "[piped text]")
    info_line <- paste(info_parts, collapse = "  |  ")

    info_par <- officer::fpar(
      officer::ftext(info_line,
                     prop = officer::fp_text(color = "#666666",
                                             font.size = 9,
                                             italic = TRUE))
    )
    doc <- officer::body_add_fpar(doc, info_par)

    ## Question text (HTML stripped).
    qtext_plain <- strip_html(q$QuestionText %||% "")
    if (nzchar(qtext_plain)) {
      doc <- officer::body_add_par(doc, qtext_plain, style = "Normal")
    }

    ## Body per type.
    if (identical(qtype, "Matrix")) {
      stmts    <- .fld(q, "Choices") %||% list()
      stmt_ord <- resolve_order(.fld(q, "ChoiceOrder"), stmts)
      ans      <- .fld(q, "Answers") %||% list()
      ans_ord  <- resolve_order(.fld(q, "AnswerOrder"), ans)

      if (length(stmt_ord) > 0 && length(ans_ord) == 0) {
        ## TE matrix without an Answers dictionary: list the statements.
        for (sid in stmt_ord) {
          doc <- officer::body_add_par(doc,
            paste0("• ", strip_html(.item_display(stmts[[as.character(sid)]])),
                   "  [text entry]"),
            style = "Normal")
        }
      } else if (length(stmt_ord) > 0 && length(ans_ord) > 0) {
        ## Build a data frame: first column = statement, others = scale labels
        ## with "[aid]" placeholder for each cell so the grid is visible.
        ans_labels <- vapply(ans_ord, function(aid) {
          strip_html(.item_display(ans[[as.character(aid)]]))
        }, character(1))
        ## flextable rejects duplicate column names. If two answer options
        ## share the same display text (or are blank), append the answer ID
        ## as a disambiguator. Also fall back if a label is empty.
        ans_labels[!nzchar(ans_labels)] <- paste0("ans_", ans_ord[!nzchar(ans_labels)])
        if (anyDuplicated(ans_labels)) {
          dup_idx <- duplicated(ans_labels) | duplicated(ans_labels, fromLast = TRUE)
          ans_labels[dup_idx] <- paste0(ans_labels[dup_idx], " [", ans_ord[dup_idx], "]")
        }
        ## Also dedupe Statement vs ans_labels collision (rare but possible).
        col_names <- c("Statement", ans_labels)
        col_names <- make.unique(col_names, sep = "_")

        rows_df <- data.frame(matrix(NA_character_,
                                     nrow = length(stmt_ord),
                                     ncol = length(ans_ord) + 1),
                              stringsAsFactors = FALSE)
        names(rows_df) <- col_names
        for (i in seq_along(stmt_ord)) {
          rows_df$Statement[i] <- strip_html(
            .item_display(stmts[[as.character(stmt_ord[i])]]))
          for (j in seq_along(ans_ord)) {
            rows_df[i, j + 1] <- paste0("[", ans_ord[j], "]")
          }
        }
        ft <- flextable::flextable(rows_df)
        ft <- flextable::autofit(ft)
        ft <- flextable::bold(ft, part = "header")
        if (length(ans_ord) >= 1) {
          ft <- flextable::align(ft, j = seq(2, length(ans_ord) + 1),
                                 align = "center", part = "all")
        }
        doc <- flextable::body_add_flextable(doc, ft)
      }
    } else if (identical(qtype, "Slider")) {
      cfg <- .fld(q, "Configuration") %||% list()
      vnum <- .fld(.fld(.fld(q, "Validation"), "Settings"), "ValidNumber") %||% list()
      vmin <- .fld(cfg, "CSSliderMin") %||% vnum$Min %||% "?"
      vmax <- .fld(cfg, "CSSliderMax") %||% vnum$Max %||% "?"
      step <- .slider_step(cfg)
      line <- sprintf("[slider: %s - %s%s]", vmin, vmax,
                      if (!is.na(step))
                        sprintf(", step: %s", format(step)) else "")
      doc <- officer::body_add_par(doc, line, style = "Normal")
      ## One line per statement - each is its own data column.
      sl_stmts <- .fld(q, "Choices") %||% list()
      for (sid in resolve_order(.fld(q, "ChoiceOrder"), sl_stmts)) {
        doc <- officer::body_add_par(doc,
          paste0("• ",
                 strip_html(.item_display(sl_stmts[[as.character(sid)]])),
                 "  [slider track]"),
          style = "Normal")
      }
    } else if (identical(qtype, "TE") && identical(qsel, "FORM")) {
      ## Form fields: each Choice is a labeled text field.
      fields <- .fld(q, "Choices") %||% list()
      for (cid in resolve_order(.fld(q, "ChoiceOrder"), fields)) {
        doc <- officer::body_add_par(doc,
          paste0("• ",
                 strip_html(.item_display(fields[[as.character(cid)]])),
                 ": ____________"),
          style = "Normal")
      }
    } else if (identical(qtype, "TE")) {
      te_label <- if (identical(qsel, "ML") || identical(qsel, "ESTB"))
        "[free text, multi-line]" else "[free text, single-line]"
      doc <- officer::body_add_par(doc, te_label, style = "Normal")
    } else {
      ## MC / Rank / Constant-sum / etc - bulleted list of choices.
      choices <- .fld(q, "Choices") %||% list()
      choice_ord <- resolve_order(.fld(q, "ChoiceOrder"), choices)
      recodes <- .fld(q, "RecodeValues") %||% list()

      if (length(choices) > 0) {
        ## Officer's default template lacks a "List Bullet" style, so we
        ## prefix a bullet (the backslash-u2022 escape below) on "Normal" paragraphs.
        ## Works universally. (v2: comment de-unicoded; code was already fine.)
        for (cid in choice_ord) {
          cid_c <- as.character(cid)
          lbl <- strip_html(.item_display(choices[[cid_c]]))
          rec <- recodes[[cid_c]] %||% cid_c
          tag <- if (as.character(rec) != cid_c)
            sprintf("[%s=%s]", cid_c, rec) else sprintf("[%s]", cid_c)
          doc <- officer::body_add_par(doc,
                                       paste0("\u2022 ", tag, " ", lbl),
                                       style = "Normal")
        }
      } else {
        doc <- officer::body_add_par(doc, "[display only - no input]",
                                     style = "Normal")
      }
    }

    ## Empty line between questions.
    doc <- officer::body_add_par(doc, "", style = "Normal")
    doc
  }

  ## Walk blocks in order, emitting a heading + questions + page breaks.
  ## Each question at MOST once (stale Default container blocks can
  ## reference every QID a second time - skip already-rendered ones).
  rendered_qids <- character()
  for (bi in seq_len(nrow(ord_blocks))) {
    bid <- ord_blocks$id[bi]
    b <- blocks[[bid]]
    if (is.null(b)) next
    els <- .fld(b, "BlockElements") %||% list()
    block_qids <- vapply(els, function(el) {
      .fld(el, "QuestionID") %||% NA_character_
    }, character(1))
    fresh <- block_qids[!is.na(block_qids) &
                        block_qids %in% names(questions) &
                        !(block_qids %in% rendered_qids)]
    if (length(fresh) == 0) next

    heading <- paste0(.fld(b, "Description") %||% bid,
                      if (ord_blocks$conditional[bi])
                        "  (conditional - shown via branch logic)" else "")
    doc <- officer::body_add_par(doc, heading, style = "heading 2")

    for (el in els) {
      if (identical(.fld(el, "Type"), "Page Break")) {
        doc <- officer::body_add_par(doc,
          "--------------------  page break  --------------------",
          style = "Normal")
        next
      }
      qid <- .fld(el, "QuestionID")
      if (is.null(qid) || !(qid %in% names(questions)) ||
          qid %in% rendered_qids) next
      rendered_qids <- c(rendered_qids, qid)
      doc <- add_question(doc, qid, questions[[qid]])
    }
  }

  ## Trashed / unassigned questions: appended at the end, clearly labeled,
  ## so the Word preview also shows EVERYTHING without misrepresenting what
  ## respondents saw.
  leftover <- setdiff(names(questions), rendered_qids)
  if (length(leftover) > 0) {
    doc <- officer::body_add_par(
      doc,
      sprintf("Unused / trashed questions (%d) - NOT shown to respondents",
              length(leftover)),
      style = "heading 2")
    for (qid in leftover) {
      doc <- add_question(doc, qid, questions[[qid]])
    }
  }

  ## Write.
  print(doc, target = out_path)
  invisible(NULL)
}


## ==== 10. Per-survey orchestrator ==========================================

## Helper: list of artifact filenames so we can do "are we already done?" checks.
SURVEY_ARTIFACT_FILES <- c(
  "responses_numeric.rds",
  "responses_numeric.csv",
  "responses_labels.csv",
  "responses_labels.xlsx",          # Excel mirror - safer for Hebrew + open-text
  "survey_definition.json",
  "survey.qsf",
  "questions.csv",
  "questions.xlsx",                 # Excel mirror
  "codebook.csv",
  "codebook.xlsx",                  # Excel mirror
  "metadata.json",
  "display_order.csv",
  "survey_flow.json",               # raw SurveyFlow subtree (lossless)
  "survey_flow.txt",                # human-readable indented flow tree
  "display_logic.csv",              # per-question display/skip logic, readable
  "preview.html",
  "preview.docx",
  "survey_portable.json",
  "migration_notes.md"
)

## (v2) The subset of artifacts that comes from the RESPONSE export (the two
## fetch_survey calls). display_order.csv belongs here because it is derived
## from the numeric response download. Kept in ONE place so the skip / retry /
## summary logic below and the resume check all agree on what "responses" means
## (same 5 files the index writer treats as response files).
RESPONSE_ARTIFACT_FILES <- c(
  "responses_numeric.rds",
  "responses_numeric.csv",
  "responses_labels.csv",
  "responses_labels.xlsx",
  "display_order.csv"
)

## (v2) Marker file written INSTEAD of response files when Qualtrics reports
## 0 recorded responses for the survey - so a human (and the resume check)
## can tell "nothing existed to download" apart from "download failed".
NO_RESPONSES_MARKER <- "NO_RESPONSES.txt"

## (v2) README written into a survey folder when the response export failed
## for real (after a retry) - names exactly what is missing and why it matters.
MISSING_RESPONSES_README <- "MISSING_RESPONSES_README.txt"

## Maps a raw Qualtrics/qualtRics error message to a plain-language explanation.
## Evidence for the 404/400 readings: Qualtrics community threads 11090 + 7932
## and ropensci/qualtRics issues #384 / #246 / #292 (shared, non-owned surveys
## fail response export while owned surveys work) - see DIAGNOSIS_2026-07-16.md.
## reason: this hint text is needed in THREE places (both response artifact
## blocks and the missing-responses README); inlining would duplicate a
## paragraph twice and let the copies drift apart.
.export_error_hint <- function(error_message) {
  if (grepl("404|cannot be found|not found", error_message, ignore.case = TRUE)) {
    paste0(
      " PLAIN LANGUAGE: a 404 here usually does NOT mean a wrong survey ID. ",
      "It usually means this API token's account does not OWN the survey ",
      "(for example, it was shared into the account by a collaborator), so ",
      "Qualtrics hides the response-export resource. The survey structure ",
      "still downloads fine, which is why only the responses failed. ",
      "FIX: re-run this survey with the OWNER account's API token, or have ",
      "the owner copy/export the data."
    )
  } else if (grepl("400|bad request", error_message, ignore.case = TRUE)) {
    paste0(
      " PLAIN LANGUAGE: a 400 'bad request' on the response export, when the ",
      "same run succeeds for other surveys, is a known pattern for surveys ",
      "SHARED into this account but owned by another user/account ",
      "(ropensci/qualtRics issues #384, #246). ",
      "FIX: re-run this survey with the OWNER account's API token."
    )
  } else {
    ""  # No specific plain-language reading for other errors - say nothing.
  }
}

#' The artifacts a run on THIS machine can actually produce. The .xlsx
#' mirrors need writexl; preview.docx needs officer + flextable. Without
#' this distinction, machines lacking the optional packages could never
#' satisfy the resume check (RESUME silently re-downloaded everything,
#' forever) and every survey was reported FAILED because preview.docx
#' errored - even though all data artifacts succeeded.
expected_artifact_files <- function() {
  files <- SURVEY_ARTIFACT_FILES
  if (!requireNamespace("writexl", quietly = TRUE)) {
    files <- setdiff(files, c("responses_labels.xlsx", "questions.xlsx",
                              "codebook.xlsx"))
  }
  if (!requireNamespace("officer", quietly = TRUE) ||
      !requireNamespace("flextable", quietly = TRUE)) {
    files <- setdiff(files, "preview.docx")
  }
  files
}

#' Back up one survey: download all 16 artifacts.
#'
#' @param account_name Character. For logging only.
#' @param survey_row One row from list_surveys() (id, name, response_count, ...).
#' @param account_root Character. Path of the account-date folder.
#' @param api_key Character. For direct httr calls (qualtRics is already wired).
#' @param base_url Character.
#' @param resume  Logical. If TRUE, skip a survey whose folder already has all
#'                12 artifacts. Defaults to the global RESUME if defined.
#' @param on_log  Optional callback for streaming log messages. See log_it().
#' @return List with $ok (logical) and $errors (character vector).
backup_one_survey <- function(account_name, survey_row, account_root,
                              api_key, base_url,
                              resume = if (exists("RESUME")) RESUME else TRUE,
                              on_log = NULL) {
  errors <- character()

  ## Sanitize the survey name for use in a folder name.
  safe_name <- safe_folder_name(survey_row$name)
  out_dir <- file.path(account_root, paste0(safe_name, "__", survey_row$id))

  ## Resume optimization: if every artifact THIS machine can produce already
  ## exists, skip. (Optional-package artifacts are excluded from the check.)
  ## (v2) A folder ALSO counts as complete when all non-response artifacts
  ## exist and NO_RESPONSES.txt marks the survey as having 0 responses -
  ## otherwise empty surveys would be re-attempted forever.
  if (resume && dir.exists(out_dir)) {
    expected <- expected_artifact_files()
    have <- file.exists(file.path(out_dir, expected))
    have_all <- all(have)
    non_resp_ok <- all(have[!(expected %in% RESPONSE_ARTIFACT_FILES)])
    marked_empty <- file.exists(file.path(out_dir, NO_RESPONSES_MARKER))
    if (have_all || (non_resp_ok && marked_empty)) {
      log_it(on_log, "info",
             sprintf("Skipping (already backed up): %s", survey_row$name))
      ## Report the response status of the EXISTING folder so the end-of-run
      ## summary stays truthful on resumed runs.
      resumed_status <- if (all(file.exists(file.path(out_dir, c(
        "responses_numeric.csv", "responses_labels.csv"))))) "ok" else "empty"
      return(list(ok = TRUE, errors = character(),
                  responses_status = resumed_status,
                  response_count = NA_integer_))
    }
  }

  ## Create the folder (recursive=TRUE handles parents too).
  dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

  ## Helper that runs an artifact-producing block, catches errors, and logs.
  ## We define it locally so it captures `errors`, `out_dir`, `on_log`, etc.
  try_artifact <- function(label, expr) {
    tryCatch(
      eval.parent(expr),
      error = function(e) {
        msg <- sprintf("[%s] %s: %s", survey_row$name, label, conditionMessage(e))
        log_it(on_log, "warning", msg)
        errors <<- c(errors, msg)
      }
    )
  }

  ## ---- Artifact 0 (v2): survey metadata FIRST - it carries the count -----
  ## Qualtrics' metadata endpoint reports how many responses the survey holds
  ## (responsecounts$auditable). Fetching it BEFORE the response export lets
  ## us (a) skip surveys that have nothing to export, and (b) state in plain
  ## numbers how much data is at stake when an export fails. The metadata.json
  ## artifact further below REUSES this object - no extra API call overall.
  survey_metadata <- tryCatch({
    Sys.sleep(API_POLITENESS_DELAY)
    qualtRics::metadata(get = c("metadata", "questions", "responsecounts"),
                        surveyID = survey_row$id)
  }, error = function(e) {
    log_it(on_log, "warning", sprintf(
      "[%s] Could not read survey metadata upfront (%s) - will still attempt the response export.",
      survey_row$name, conditionMessage(e)))
    NULL
  })
  ## The official number of stored responses; NA when metadata was unreadable.
  ## "auditable" = real recorded responses (excludes deleted + preview ones).
  response_count <- if (!is.null(survey_metadata)) {
    as.integer(survey_metadata$responsecounts$auditable %||% NA_integer_)
  } else NA_integer_

  ## ---- Artifact 1+2+3: response data ----
  ## We do TWO calls to fetch_survey: once with label=FALSE (numeric), once
  ## with label=TRUE (human-readable strings). Both are useful: numeric for
  ## analysis, labels for "what did the respondent actually see and click".
  ## (v2) Three-way logic around the export:
  ##   count == 0            -> nothing exists to export: skip + marker file,
  ##                            logged plainly as NOT an error;
  ##   count > 0 or unknown  -> export; on failure retry ONCE; if it still
  ##                            fails, MISSING_RESPONSES_README.txt is written
  ##                            below so the gap cannot hide in a green run.
  if (!is.na(response_count) && response_count == 0) {
    log_it(on_log, "info", sprintf(
      "[%s] Survey has 0 recorded responses - nothing to export (not an error). Structure is still backed up.",
      survey_row$name))
    ## Marker file: tells humans AND the resume check that the response files
    ## are absent because nothing existed - not because a download failed.
    marker_con <- file(file.path(out_dir, NO_RESPONSES_MARKER),
                       open = "w", encoding = "UTF-8")
    writeLines(c(
      "This survey had 0 recorded responses in Qualtrics at backup time,",
      "so there was no response data to download. This is NOT an error.",
      sprintf("Survey: %s (ID: %s)", survey_row$name, survey_row$id),
      sprintf("Checked: %s (metadata responsecounts$auditable == 0)",
              format(Sys.time())),
      "All structure artifacts (QSF, codebook, previews, flow) are unaffected."
    ), con = marker_con)
    close(marker_con)
  } else {

  try_artifact("responses_numeric", quote({
    Sys.sleep(API_POLITENESS_DELAY)
    ## (v2) First attempt; if it fails, wait and retry once (rides out
    ## transient API/network hiccups). A second failure raises an error
    ## enriched with a plain-language hint; try_artifact logs + records it.
    z_num <- tryCatch({
      qualtRics::fetch_survey(
        surveyID = survey_row$id,
        verbose = FALSE,
        force_request = TRUE,
        label = FALSE,                # Numeric values
        convert = FALSE,              # Don't auto-coerce types
        include_display_order = TRUE  # For artifact 9 (display_order.csv)
      )
    }, error = function(first_err) {
      log_it(on_log, "warning", sprintf(
        "[%s] Response download (numeric) failed once: %s - retrying once in 5 seconds.",
        survey_row$name, conditionMessage(first_err)))
      Sys.sleep(5)
      tryCatch({
        qualtRics::fetch_survey(
          surveyID = survey_row$id,
          verbose = FALSE,
          force_request = TRUE,
          label = FALSE,
          convert = FALSE,
          include_display_order = TRUE
        )
      }, error = function(second_err) {
        stop(paste0(conditionMessage(second_err),
                    .export_error_hint(conditionMessage(second_err))),
             call. = FALSE)
      })
    })
    ## Strip Qualtrics's "...N" suffix that appears on duplicated columns
    ## (typically when male/female versions exist).
    names(z_num) <- gsub("\\.\\.\\.[0-9]+$", "", names(z_num))
    saveRDS(z_num, file = file.path(out_dir, "responses_numeric.rds"))
    readr::write_excel_csv(  # write_excel_csv writes UTF-8 BOM for Excel
      z_num,
      file = file.path(out_dir, "responses_numeric.csv")
    )
    ## Also save display order info derived from the same fetch.
    display_cols <- grep("_DO_|_DO$", names(z_num), value = TRUE)
    if (length(display_cols) > 0) {
      readr::write_excel_csv(
        z_num[, c("ResponseId", display_cols), drop = FALSE],
        file = file.path(out_dir, "display_order.csv")
      )
    } else {
      ## No display-order columns - write a placeholder so downstream "all
      ## artifacts present" checks succeed for the resume optimization.
      writeLines(
        "# No display-order columns in this survey (no randomization).",
        con = file.path(out_dir, "display_order.csv")
      )
    }
  }))

  try_artifact("responses_labels", quote({
    Sys.sleep(API_POLITENESS_DELAY)
    ## (v2) Same retry-once pattern as the numeric download above.
    z_lbl <- tryCatch({
      qualtRics::fetch_survey(
        surveyID = survey_row$id,
        verbose = FALSE,
        force_request = TRUE,
        label = TRUE,                 # Substituted choice labels
        convert = FALSE
      )
    }, error = function(first_err) {
      log_it(on_log, "warning", sprintf(
        "[%s] Response download (labels) failed once: %s - retrying once in 5 seconds.",
        survey_row$name, conditionMessage(first_err)))
      Sys.sleep(5)
      tryCatch({
        qualtRics::fetch_survey(
          surveyID = survey_row$id,
          verbose = FALSE,
          force_request = TRUE,
          label = TRUE,
          convert = FALSE
        )
      }, error = function(second_err) {
        stop(paste0(conditionMessage(second_err),
                    .export_error_hint(conditionMessage(second_err))),
             call. = FALSE)
      })
    })
    names(z_lbl) <- gsub("\\.\\.\\.[0-9]+$", "", names(z_lbl))
    readr::write_excel_csv(z_lbl,
                           file = file.path(out_dir, "responses_labels.csv"))
    ## Also write an .xlsx mirror. CSV with Hebrew open-text answers can
    ## confuse Excel even with the BOM (stray commas, line breaks inside
    ## cells). Excel reads .xlsx natively without ambiguity.
    if (requireNamespace("writexl", quietly = TRUE)) {
      tryCatch(
        writexl::write_xlsx(as.data.frame(z_lbl),
                            path = file.path(out_dir, "responses_labels.xlsx")),
        error = function(e) {
          log_it(on_log, "warning",
                 sprintf("[%s] responses_labels.xlsx failed: %s",
                         survey_row$name, conditionMessage(e)))
        }
      )
    }
  }))

  ## (v2) If the two key response files are STILL missing here, the export
  ## failed for real (initial attempt + retry). Write a README into the
  ## survey folder so anyone who opens it sees at once what is missing,
  ## how much data is at stake, and what to do about it.
  responses_written <- all(file.exists(file.path(out_dir, c(
    "responses_numeric.csv", "responses_labels.csv"))))
  if (!responses_written) {
    ## Pull the recorded error lines for THIS survey's response artifacts so
    ## the README carries the exact evidence, not a paraphrase.
    response_errors <- errors[grepl("responses_numeric|responses_labels",
                                    errors)]
    count_text <- if (is.na(response_count)) {
      "UNKNOWN (the metadata call failed too) - assume responses exist until proven otherwise."
    } else {
      sprintf("%d recorded responses exist in Qualtrics (responsecounts$auditable).",
              response_count)
    }
    readme_con <- file(file.path(out_dir, MISSING_RESPONSES_README),
                       open = "w", encoding = "UTF-8")
    writeLines(c(
      "MISSING RESPONSES - THIS SURVEY'S BACKUP IS INCOMPLETE",
      "=======================================================",
      "",
      sprintf("Survey: %s (ID: %s)", survey_row$name, survey_row$id),
      sprintf("Backup attempt: %s", format(Sys.time())),
      "",
      "WHAT IS MISSING",
      "The response data files could not be downloaded (tried twice):",
      paste0("  - ", RESPONSE_ARTIFACT_FILES),
      "",
      "HOW MUCH DATA IS AT STAKE",
      paste0("  ", count_text),
      "",
      "WHY IT MATTERS",
      "If responses exist, real participant data is NOT in this backup.",
      "The survey STRUCTURE (questions, logic, previews) was saved fine -",
      "only the collected answers are missing from this folder.",
      "",
      "THE ERRORS WE GOT",
      if (length(response_errors) > 0) paste0("  ", response_errors) else
        "  (no error text captured)",
      "",
      "WHAT TO DO",
      "1. Open metadata.json in this folder and check responsecounts.auditable.",
      "2. If it is 0, nothing was lost - you can ignore this.",
      "3. If it is > 0: the usual cause is that the survey is OWNED by a",
      "   different Qualtrics account and only SHARED with this one. Re-run",
      "   the backup for this survey using the owner account's API token,",
      "   or ask the owner to export/copy the data.",
      "4. If ownership is not the issue, retry later (transient API errors",
      "   do happen) and check the account's API permissions."
    ), con = readme_con)
    close(readme_con)
    log_it(on_log, "warning", sprintf(
      "[%s] Responses NOT backed up after a retry - wrote %s into the survey folder (%s).",
      survey_row$name, MISSING_RESPONSES_README, count_text))
  }

  }  ## end of (v2) three-way response logic

  ## ---- QSF download: MEMORY-FIRST, THEN disk ----
  ## We pull the QSF body into memory before attempting to write it to disk.
  ## Reason: on Windows + Hebrew folder names + OneDrive paths, disk write
  ## sometimes fails ("Failed to open file ..."). If we wrote-then-parsed,
  ## a write failure would lose the data and cascade-fail every downstream
  ## artifact. With memory-first, the data survives even if disk write fails.
  qsf_path <- file.path(out_dir, "survey.qsf")
  definition <- NULL
  qsf_err <- NULL  # Holds the original fetch error for cascade messages.

  ## Step 1: download QSF body into memory.
  ## We assign the RESULT of tryCatch to qsf_text - NOT via `<<-` inside the
  ## expr block, which silently fails (R's `<<-` skips the function's own
  ## frame and writes to the global env instead - subtle scoping trap).
  qsf_text <- tryCatch({
    Sys.sleep(API_POLITENESS_DELAY)
    fetch_survey_qsf(survey_row$id, base_url, api_key)
  }, error = function(e) {
    ## `<<-` here works correctly because we're inside an anonymous function
    ## whose enclosing env IS backup_one_survey's frame.
    qsf_err <<- conditionMessage(e)
    msg <- sprintf("[%s] QSF download: %s", survey_row$name, qsf_err)
    log_it(on_log, "warning", msg)
    errors <<- c(errors, msg)
    NULL  # explicit return so qsf_text becomes NULL on error
  })

  ## Step 1b: if QSF endpoint failed, fall back to /survey-definitions/{id}
  ## (the JSON endpoint) and use that for downstream artifacts. Some tokens
  ## have access to one but not the other.
  if (is.null(qsf_text)) {
    fallback_def <- tryCatch({
      Sys.sleep(API_POLITENESS_DELAY)
      fetch_survey_definition(survey_row$id, base_url, api_key)
    }, error = function(e) {
      log_it(on_log, "warning",
             sprintf("[%s] Fallback survey-definitions also failed: %s",
                     survey_row$name, conditionMessage(e)))
      NULL
    })
    if (!is.null(fallback_def) && !is.null(fallback_def$Questions)) {
      definition <- fallback_def
      log_it(on_log, "info",
             sprintf("[%s] QSF unavailable - using survey-definitions endpoint instead.",
                     survey_row$name))
    }
  }

  ## Step 2: parse QSF text -> definition (in memory, no disk needed).
  if (!is.null(qsf_text)) {
    definition <- tryCatch(
      qsf_to_definition(jsonlite::fromJSON(qsf_text, simplifyVector = FALSE)),
      error = function(e) {
        log_it(on_log, "warning",
               sprintf("[%s] QSF parse failed: %s",
                       survey_row$name, conditionMessage(e)))
        NULL
      }
    )
  }

  ## Helper: cascade reason string for downstream "no definition" warnings.
  no_def_reason <- function() {
    if (!is.null(qsf_err)) {
      paste0("survey definition unavailable - QSF download failed: ", qsf_err)
    } else {
      "survey definition unavailable"
    }
  }

  ## Step 3: write QSF to disk as its own artifact.
  try_artifact("survey.qsf", quote({
    if (is.null(qsf_text)) {
      stop(no_def_reason(), call. = FALSE)
    }
    write_qsf(qsf_text, qsf_path)
  }))

  ## ---- Artifact 4: survey definition JSON (separate API call, may be null) ----
  ## We keep this as its own artifact for completeness even when it returns
  ## null (some tokens lack the permission for /survey-definitions/{id}).
  ## The QSF (above) is the reliable source for the structure.
  ##
  ## NOTE the fetch happens OUTSIDE the quoted block: an earlier version did
  ## `definition <<- api_definition` INSIDE the quote(), where `<<-` at the
  ## top level of an eval.parent()'d expression assigns into globalenv - the
  ## fallback never reached the local `definition` (dead code, verified
  ## 2026-07-05). Plain `<-` in the function frame is correct.
  api_definition <- tryCatch({
    Sys.sleep(API_POLITENESS_DELAY)
    fetch_survey_definition(survey_row$id, base_url, api_key)
  }, error = function(e) {
    msg <- sprintf("[%s] survey_definition: %s",
                   survey_row$name, conditionMessage(e))
    log_it(on_log, "warning", msg)
    errors <<- c(errors, msg)
    NULL
  })
  if (!is.null(api_definition)) {
    try_artifact("survey_definition", quote({
      jsonlite::write_json(
        api_definition,
        path = file.path(out_dir, "survey_definition.json"),
        auto_unbox = TRUE,
        pretty = TRUE,
        null = "null",
        na = "null"
      )
    }))
    ## If the API endpoint succeeded AND we don't yet have a definition from
    ## QSF (because QSF failed or didn't parse), use the API one instead.
    if (is.null(definition) && !is.null(api_definition$Questions)) {
      definition <- api_definition
      log_it(on_log, "info",
             sprintf("[%s] Using survey-definitions endpoint as the structure source.",
                     survey_row$name))
    }
  }

  ## ---- Artifact 6: questions.csv + .xlsx (one row per question, wide) ----
  ## Built from the LOCAL definition (parsed from QSF), not via an API call.
  ## This is the scannable summary - one row per question with all metadata
  ## (type, scale, statements, validation, flags) collapsed into cells.
  ## For the exploded choice-level view, see codebook.csv.
  try_artifact("questions.csv", quote({
    if (is.null(definition)) stop("survey definition not available for questions table")
    qt <- build_questions_table(definition)
    readr::write_excel_csv(qt, file = file.path(out_dir, "questions.csv"))
    if (requireNamespace("writexl", quietly = TRUE)) {
      tryCatch(
        writexl::write_xlsx(as.data.frame(qt),
                            path = file.path(out_dir, "questions.xlsx")),
        error = function(e) NULL
      )
    }
  }))

  ## ---- Artifact 7: codebook.csv + .xlsx (richer, choice-level) ----
  try_artifact("codebook.csv", quote({
    if (is.null(definition)) stop("survey definition was not fetched")
    cb <- build_codebook(definition)
    readr::write_excel_csv(cb, file = file.path(out_dir, "codebook.csv"))
    if (requireNamespace("writexl", quietly = TRUE)) {
      tryCatch(
        writexl::write_xlsx(as.data.frame(cb),
                            path = file.path(out_dir, "codebook.xlsx")),
        error = function(e) NULL
      )
    }
  }))

  ## ---- Artifact 8: metadata.json (response counts, dates, language) ----
  ## (v2) Reuses the metadata object fetched upfront (Artifact 0). Only if
  ## that upfront call failed do we try the endpoint again here.
  try_artifact("metadata.json", quote({
    md <- survey_metadata
    if (is.null(md)) {
      Sys.sleep(API_POLITENESS_DELAY)
      md <- qualtRics::metadata(get = c("metadata", "questions", "responsecounts"), surveyID = survey_row$id)
    }
    jsonlite::write_json(
      md,
      path = file.path(out_dir, "metadata.json"),
      auto_unbox = TRUE,
      pretty = TRUE,
      null = "null",
      na = "null"
    )
  }))

  ## ---- Artifact 9b: survey_flow.json (raw SurveyFlow subtree, lossless) ----
  ## Elad 2026-07-10: a backup must capture "what appeared to whom" - the full
  ## flow logic (branches, conditions, randomizers, embedded data, quotas,
  ## endings). The QSF SurveyFlow subtree is the lossless source; we write it
  ## verbatim as JSON so nothing is lost even if our readable renderer misses
  ## an exotic element type.
  try_artifact("survey_flow.json", quote({
    if (is.null(definition)) stop("survey definition was not fetched")
    flow_obj <- definition$SurveyFlow %||% list(Flow = list())
    jsonlite::write_json(
      flow_obj,
      path = file.path(out_dir, "survey_flow.json"),
      auto_unbox = TRUE, pretty = TRUE, null = "null", na = "null"
    )
  }))

  ## ---- Artifact 9c: survey_flow.txt (human-readable indented flow tree) ----
  try_artifact("survey_flow.txt", quote({
    if (is.null(definition)) stop("survey definition was not fetched")
    flow_text <- build_flow_text(definition)
    con <- file(file.path(out_dir, "survey_flow.txt"), open = "w",
                encoding = "UTF-8")
    on.exit(close(con), add = TRUE)
    writeLines(flow_text, con = con)
  }))

  ## ---- Artifact 9d: display_logic.csv (per-question show/skip conditions) --
  ## One row per question that has display logic, skip logic, or carry-forward.
  ## Always written (even with zero rows) so the resume check is satisfied and
  ## downstream code can rely on the file existing.
  try_artifact("display_logic.csv", quote({
    if (is.null(definition)) stop("survey definition was not fetched")
    dlt <- build_display_logic_table(definition)
    if (nrow(dlt) == 0) {
      dlt <- tibble::tibble(
        question_id = character(), block_name = character(),
        question_text = character(), display_logic = character(),
        skip_logic = character(), carries_forward_choices = logical())
    }
    readr::write_excel_csv(dlt, file = file.path(out_dir, "display_logic.csv"))
  }))

  ## ---- Artifact 10: preview.html ----
  try_artifact("preview.html", quote({
    if (is.null(definition)) stop("survey definition was not fetched")
    render_preview_html(definition, survey_row$name,
                        out_path = file.path(out_dir, "preview.html"))
  }))

  ## ---- Artifact 10b: preview.docx (Word version of preview.html) ----
  ## OPTIONAL artifact: needs officer + flextable. When they're missing we
  ## log once and move on - a missing Word mirror must not mark the whole
  ## survey as FAILED (the data artifacts are what matter).
  if (requireNamespace("officer", quietly = TRUE) &&
      requireNamespace("flextable", quietly = TRUE)) {
    if (length(definition$Questions %||% list()) > 300) {
      log_it(on_log, "info", sprintf(
        "[%s] Large survey (%d questions) - the Word preview can take several minutes.",
        survey_row$name, length(definition$Questions)))
    }
    try_artifact("preview.docx", quote({
      if (is.null(definition)) stop("survey definition was not available")
      render_preview_docx(definition, survey_row$name,
                          out_path = file.path(out_dir, "preview.docx"))
    }))
  } else {
    log_it(on_log, "info",
           sprintf("[%s] preview.docx skipped (officer/flextable not installed).",
                   survey_row$name))
  }

  ## ---- Artifact 11+12: portable schema + migration notes ----
  try_artifact("survey_portable.json", quote({
    if (is.null(definition)) stop("survey definition was not fetched")
    portable <- build_portable_schema(definition)
    jsonlite::write_json(
      portable$schema,
      path = file.path(out_dir, "survey_portable.json"),
      auto_unbox = TRUE,
      pretty = TRUE,
      null = "null",
      na = "null"
    )
    ## migration_notes.md - one bullet per Qualtrics-specific feature.
    notes_lines <- c(
      "# Migration Notes",
      "",
      sprintf("Survey: **%s** (ID: `%s`)", survey_row$name, survey_row$id),
      sprintf("Generated: %s", Sys.time()),
      "",
      "This file lists Qualtrics-specific features that **will not transfer**",
      "cleanly to another survey platform via `survey_portable.json` alone.",
      "Each item below needs manual attention if you migrate this survey.",
      "",
      if (length(portable$migration_notes) == 0) {
        "No Qualtrics-specific features detected. Clean port expected."
      } else {
        paste("-", portable$migration_notes)
      }
    )
    writeLines(notes_lines,
               con = file.path(out_dir, "migration_notes.md"),
               useBytes = FALSE)
  }))

  ## (v2) Classify this survey's response-backup outcome for the end-of-run
  ## summary. File presence is the ground truth (deterministic, re-checkable):
  ##   both key response files on disk -> "ok"
  ##   NO_RESPONSES marker on disk     -> "empty"  (0 responses existed - fine)
  ##   neither                         -> "missing" (export failed - act on it)
  responses_status <- if (all(file.exists(file.path(out_dir, c(
    "responses_numeric.csv", "responses_labels.csv"))))) {
    "ok"
  } else if (file.exists(file.path(out_dir, NO_RESPONSES_MARKER))) {
    "empty"
  } else {
    "missing"
  }

  list(ok = length(errors) == 0, errors = errors,
       responses_status = responses_status,
       response_count = response_count)
}


## ==== 11. Account-level orchestrator + index pages =========================
##
## This section has TWO entry points:
##
##   run_backup_session() - the programmatic entry point. Takes every setting
##       as an argument. No globals. Used by the Shiny app (app.R) AND by
##       backup_account() below. This is the function you call from any
##       external code (Shiny server, a scheduled Rscript, a test, etc.).
##
##   backup_account() - the CLI entry point. Reads globals (ACCOUNTS,
##       BACKUP_ROOT, SURVEY_FILTER, SKIP_EMPTY, RESUME, ENCRYPT_OUTPUT),
##       calls load_credentials() for the token, then delegates to
##       run_backup_session(). Used by main() at the bottom of this script.

#' Run a full backup session with explicit configuration.
#'
#' This is the programmatic entry point - it takes ALL configuration as
#' arguments, so callers don't need to set any globals. The Shiny app uses
#' this directly.
#'
#' @param account_name Character. Label for the account (e.g., "ISF"). Used for
#'   the output subfolder and log messages. Never sent to Qualtrics.
#' @param api_key Character. The Qualtrics API token. Used for the session
#'   only - never written to disk, never logged.
#' @param base_url Character. Qualtrics datacenter URL without scheme,
#'   e.g. "biusocialsciences.eu.qualtrics.com".
#' @param backup_root Character. Root folder where the backup is written.
#'   A subfolder <account_name>/<YYYY-MM-DD>/ is created inside it.
#' @param survey_filter NULL or a regex to subset surveys by name.
#' @param survey_subset_ids Optional character vector of survey IDs to limit
#'   the backup to specific surveys (overrides survey_filter's selection).
#'   Used by the Shiny app's survey picker.
#' @param skip_empty Logical. If TRUE, surveys with zero responses are skipped.
#' @param resume Logical. If TRUE, per-survey resume: skip surveys whose folder
#'   already has all 12 artifacts.
#' @param politeness_delay Numeric. Seconds to wait between API calls.
#' @param encrypt_output Logical. If TRUE, tar + encrypt the account folder.
#' @param encryption_passphrase Character. Passphrase used for encryption.
#'   Ignored unless encrypt_output is TRUE.
#' @param on_progress Optional callback: function(current, total, survey_name).
#'   Called once per survey before its backup starts. Used by Shiny's progress bar.
#' @param on_log Optional callback: function(level, message). Streams messages.
#' @return List with: account_name, account_root, surveys_attempted,
#'   surveys_ok, surveys_failed, errors_log.
run_backup_session <- function(account_name,
                               api_key,
                               base_url,
                               backup_root,
                               survey_filter = NULL,
                               survey_subset_ids = NULL,
                               skip_empty = FALSE,
                               resume = TRUE,
                               politeness_delay = 0.5,
                               encrypt_output = FALSE,
                               encryption_passphrase = NULL,
                               on_progress = NULL,
                               on_log = NULL) {

  ## account_name and backup_root are free text (Shiny UI fields, or a CLI
  ## config value someone hand-edited). A trailing space is invisible in a
  ## text box but makes dir.create() fail outright on Windows - confirmed
  ## live: dir.create() returns FALSE for a path whose last segment ends in
  ## a space, even with recursive = TRUE, and the only symptom is "Could not
  ## create the output folder" with no hint why. Trim both here, once, so
  ## every caller (Shiny and CLI) is protected.
  account_name <- trimws(account_name)
  backup_root <- trimws(backup_root)

  log_it(on_log, "info", sprintf("Starting backup for account: %s", account_name))

  ## --- Step 1: wire credentials for this R session ---
  ## We use the caller-supplied token rather than load_credentials(), because
  ## in Shiny the token comes directly from the UI.
  connect_account(api_key, base_url)

  ## --- Step 2: enumerate surveys ---
  log_it(on_log, "info", "Listing surveys (may take a moment for many surveys)...")
  ## Temporarily override API_POLITENESS_DELAY so list_surveys uses the value
  ## the caller asked for. list_surveys reads the global; we save/restore.
  old_delay <- if (exists("API_POLITENESS_DELAY", envir = globalenv())) {
    get("API_POLITENESS_DELAY", envir = globalenv())
  } else NULL
  assign("API_POLITENESS_DELAY", politeness_delay, envir = globalenv())
  on.exit({
    ## Always restore the old value, whether we succeed or error out.
    if (!is.null(old_delay)) {
      assign("API_POLITENESS_DELAY", old_delay, envir = globalenv())
    } else {
      rm("API_POLITENESS_DELAY", envir = globalenv())
    }
  }, add = TRUE)

  ## Fast listing (no response counts). If skip_empty was requested, we'll
  ## fetch counts right below. Otherwise we save ~30 seconds per 50 surveys.
  surveys <- list_surveys(survey_filter, include_response_counts = FALSE)
  log_it(on_log, "success", sprintf("Found %d surveys.", nrow(surveys)))

  ## Apply explicit ID subset FIRST (Shiny survey picker) - so skip_empty
  ## below only pays for metadata calls on surveys actually selected, not the
  ## whole account.
  if (!is.null(survey_subset_ids) && length(survey_subset_ids) > 0) {
    n_before <- nrow(surveys)
    surveys <- dplyr::filter(surveys, id %in% survey_subset_ids)
    log_it(on_log, "info",
           sprintf("Limited to %d selected surveys (from %d).",
                   nrow(surveys), n_before))
  }

  ## Apply skip_empty filter. Only NOW (if needed) do we pay for the metadata
  ## loop. Surveys whose count could NOT be fetched (NA) are KEPT and logged -
  ## silently excluding them would make a 'successful' backup incomplete.
  if (skip_empty && nrow(surveys) > 0) {
    log_it(on_log, "info",
           sprintf("Counting responses for %d surveys (skip_empty=TRUE)...",
                   nrow(surveys)))
    counts <- integer(nrow(surveys))
    for (i in seq_len(nrow(surveys))) {
      Sys.sleep(politeness_delay)
      md <- tryCatch(qualtRics::metadata(get = c("metadata", "questions", "responsecounts"), surveyID = surveys$id[i]),
                     error = function(e) NULL)
      counts[i] <- if (is.null(md)) NA_integer_ else {
        as.integer(md$responsecounts$auditable %||% NA_integer_)
      }
    }
    surveys$response_count <- counts
    n_na <- sum(is.na(counts))
    if (n_na > 0) {
      log_it(on_log, "warning", sprintf(
        "Could not count responses for %d surveys - keeping them in the backup to be safe.",
        n_na))
    }
    n_before <- nrow(surveys)
    surveys <- dplyr::filter(surveys, is.na(response_count) | response_count > 0)
    log_it(on_log, "info",
           sprintf("Skipped %d empty surveys.", n_before - nrow(surveys)))
  }

  if (nrow(surveys) == 0) {
    log_it(on_log, "warning", "No surveys to back up after filtering.")
    return(list(
      account_name = account_name, account_root = NA_character_,
      surveys_attempted = 0, surveys_ok = 0, surveys_failed = 0,
      responses_missing = character(), responses_empty = character(),
      errors_log = NA_character_
    ))
  }

  ## --- Step 3: prepare output folder ---
  ## The account label comes from a free-text UI field; sanitize it exactly
  ## like survey names so a stray ':' or '?' can't burn a whole run's
  ## downloads on an unwritable path.
  safe_account <- safe_folder_name(account_name)
  if (!identical(safe_account, account_name)) {
    log_it(on_log, "warning", sprintf(
      "Account label contains characters Windows forbids - using folder name '%s'.",
      safe_account))
  }
  run_date     <- format(Sys.Date(), "%Y-%m-%d")
  account_root <- file.path(backup_root, safe_account, run_date)
  dir.create(account_root, recursive = TRUE, showWarnings = FALSE)
  if (!dir.exists(account_root)) {
    stop("Could not create the output folder: ", account_root,
         "\nCheck the backup root path and permissions.", call. = FALSE)
  }
  log_it(on_log, "info", sprintf("Output folder: %s", account_root))

  ## A stale _errors.log from an earlier partial run must not survive a
  ## clean re-run - delete it now; step 6 rewrites it if needed.
  old_errlog <- file.path(account_root, "_errors.log")
  if (file.exists(old_errlog)) file.remove(old_errlog)

  ## --- Step 4: per-survey backup ---
  per_survey_results <- vector("list", nrow(surveys))
  for (i in seq_len(nrow(surveys))) {
    ## Notify the progress callback BEFORE starting the survey so the UI can
    ## show "(i of N) survey_name" while the download is in flight.
    if (!is.null(on_progress)) {
      tryCatch(
        on_progress(i, nrow(surveys), surveys$name[i]),
        error = function(e) NULL  # broken UI callback must not stop backup
      )
    }
    log_it(on_log, "info",
           sprintf("[%d/%d] %s", i, nrow(surveys), surveys$name[i]))

    per_survey_results[[i]] <- backup_one_survey(
      account_name = account_name,
      survey_row   = surveys[i, ],
      account_root = account_root,
      api_key      = api_key,
      base_url     = base_url,
      resume       = resume,
      on_log       = on_log
    )

    ## Refresh _index.html every 10 surveys so a LONG run is browsable while
    ## it is still going (otherwise the index only exists at end-of-run).
    if (i %% 10 == 0 && i < nrow(surveys)) {
      ok_so_far <- sum(vapply(per_survey_results[seq_len(i)],
                              function(r) isTRUE(r$ok), logical(1)))
      tryCatch(
        write_account_index_html(account_name, run_date,
                                 surveys[seq_len(i), ],
                                 n_ok = ok_so_far, n_fail = i - ok_so_far,
                                 account_root = account_root),
        error = function(e) NULL
      )
    }
  }

  ## --- Step 5: aggregate stats ---
  n_ok   <- sum(vapply(per_survey_results, function(r) r$ok, logical(1)))
  n_fail <- nrow(surveys) - n_ok
  all_errors <- unlist(lapply(per_survey_results, function(r) r$errors))

  ## --- Step 5b (v2): response-backup summary - what data is NOT backed up ---
  ## "35 ok, 2 failed" hides the question that actually matters: whose RESPONSE
  ## DATA is missing, and does that data even exist? This block answers it in
  ## plain language, on screen AND in _responses_summary.txt next to the index.
  resp_status <- vapply(per_survey_results, function(r) {
    s <- r$responses_status
    if (is.null(s)) "unknown" else s
  }, character(1))
  resp_count <- vapply(per_survey_results, function(r) {
    n <- r$response_count
    if (is.null(n) || length(n) != 1) NA_integer_ else as.integer(n)
  }, integer(1))

  summary_lines <- c(
    "==== RESPONSE BACKUP SUMMARY ====",
    sprintf("Run: %s / %s", account_name, run_date),
    sprintf("Responses backed up OK: %d of %d surveys.",
            sum(resp_status == "ok"), nrow(surveys))
  )
  if (any(resp_status == "empty")) {
    summary_lines <- c(summary_lines,
      sprintf("Empty surveys - 0 responses in Qualtrics, nothing to lose (fine): %d",
              sum(resp_status == "empty")),
      sprintf("  - %s", surveys$name[resp_status == "empty"]))
  }
  if (any(resp_status == "missing")) {
    missing_names <- surveys$name[resp_status == "missing"]
    missing_counts <- resp_count[resp_status == "missing"]
    count_labels <- ifelse(is.na(missing_counts),
                           "response count UNKNOWN - assume data exists",
                           sprintf("%d responses in Qualtrics", missing_counts))
    summary_lines <- c(summary_lines,
      sprintf("HAS DATA - BACKUP INCOMPLETE (act on these): %d",
              sum(resp_status == "missing")),
      sprintf("  - %s (%s; see %s in its folder)",
              missing_names, count_labels, MISSING_RESPONSES_README))
  }
  if (all(resp_status %in% c("ok", "empty"))) {
    summary_lines <- c(summary_lines,
      "No survey lost response data in this run.")
  }
  ## Print the block through the normal log stream (Shiny log + CLI alike)...
  for (line in summary_lines) {
    log_it(on_log, if (any(resp_status == "missing")) "warning" else "info",
           line)
  }
  ## ...and persist it next to the index so it survives the session.
  summary_con <- file(file.path(account_root, "_responses_summary.txt"),
                      open = "w", encoding = "UTF-8")
  writeLines(summary_lines, con = summary_con)
  close(summary_con)

  ## --- Step 6: write _errors.log if anything failed ---
  if (length(all_errors) > 0) {
    writeLines(
      c(sprintf("# Errors from backup run %s", Sys.time()), "", all_errors),
      con = file.path(account_root, "_errors.log")
    )
  }

  ## --- Step 7: write _index.csv ---
  index_df <- dplyr::transmute(
    surveys,
    id, name, response_count,
    folder = paste0(vapply(name, safe_folder_name, character(1)), "__", id)
  )
  readr::write_excel_csv(index_df, file.path(account_root, "_index.csv"))

  ## --- Step 8: write _index.html ---
  write_account_index_html(account_name, run_date, surveys, n_ok, n_fail,
                           account_root)

  ## --- Step 9: write README.md ---
  write_readme(account_name, run_date,
               n_attempted = nrow(surveys),
               n_ok = n_ok, n_fail = n_fail,
               account_root = account_root)

  ## --- Step 9b: refresh the master index at the backup root ---
  ## One page listing every account and dated run, newest first, so "find
  ## the latest backup of account X" never requires folder spelunking.
  tryCatch(write_master_index(backup_root),
           error = function(e) log_it(on_log, "warning",
             sprintf("Master index update failed: %s", conditionMessage(e))))

  ## --- Step 10: optional encryption (with supplied passphrase, not prompted) ---
  if (encrypt_output) {
    if (is.null(encryption_passphrase) || !nzchar(encryption_passphrase)) {
      log_it(on_log, "warning",
             "encrypt_output=TRUE but no passphrase supplied - skipping encryption.")
    } else {
      encrypt_folder(account_root, passphrase = encryption_passphrase,
                     on_log = on_log)
    }
  }

  log_it(on_log, "success",
         sprintf("Done: %s - %d ok, %d failed.", account_name, n_ok, n_fail))

  list(
    account_name = account_name,
    account_root = account_root,
    surveys_attempted = nrow(surveys),
    surveys_ok = n_ok,
    surveys_failed = n_fail,
    ## (v2) Additive fields - existing callers (app.R) are unaffected.
    responses_missing = surveys$name[resp_status == "missing"],
    responses_empty   = surveys$name[resp_status == "empty"],
    errors_log = if (length(all_errors) > 0) {
      file.path(account_root, "_errors.log")
    } else NA_character_
  )
}


#' CLI-side backup for one account. Reads globals + load_credentials(), then
#' delegates to run_backup_session().
#'
#' @param account_name Character. Key from the ACCOUNTS list.
#' @param account_cfg  List. Value from the ACCOUNTS list (must have base_url).
#' @return List - same shape as run_backup_session().
backup_account <- function(account_name, account_cfg) {
  cli::cli_h1("Account: {account_name}")

  ## Load credentials from the configured secret source. Token is held in this
  ## variable for the duration of the call and never leaves the R session.
  api_key <- load_credentials(account_name)

  ## Delegate to the programmatic entry point. CLI-only flag overrides come
  ## from the top-level globals so command-line runs honor the CONFIG block.
  run_backup_session(
    account_name = account_name,
    api_key      = api_key,
    base_url     = account_cfg$base_url,
    backup_root  = BACKUP_ROOT,
    survey_filter = SURVEY_FILTER,
    skip_empty   = SKIP_EMPTY,
    resume       = RESUME,
    politeness_delay = API_POLITENESS_DELAY,
    encrypt_output = ENCRYPT_OUTPUT,
    encryption_passphrase = NULL,  # CLI path uses askpass inside encrypt_folder
    on_progress  = NULL,           # CLI uses cli_progress_bar inside run loop
    on_log       = NULL            # CLI falls back to cli alerts
  )
}


## ==== 12. Index HTML + README writers ======================================

#' Write _index.html: a clickable landing page for the whole backup.
#' Rows come from the UNION of this run's surveys and folders already
#' on disk; counts/status are read from each folder (metadata.json +
#' artifact presence). Includes search, sort, and a plain-language
#' glossary of every artifact for users who know almost nothing.
write_account_index_html <- function(account_name, run_date, surveys,
                                      n_ok, n_fail, account_root) {

  ## ---- Row list = UNION of this run's surveys and folders already on disk.
  ## A same-day partial re-run (e.g. 2 surveys picked in the Shiny app) must
  ## NOT clobber the index down to those 2 rows; earlier surveys from the
  ## same date stay listed because their folders are still there.
  disk_folders <- list.dirs(account_root, recursive = FALSE, full.names = FALSE)
  disk_folders <- disk_folders[grepl("__SV_", disk_folders)]
  run_folders <- paste0(vapply(surveys$name, safe_folder_name, character(1)),
                        "__", surveys$id)
  extra <- setdiff(disk_folders, run_folders)
  if (length(extra) > 0) {
    surveys <- dplyr::bind_rows(
      surveys,
      tibble::tibble(
        id   = sub("^.*__(SV_[A-Za-z0-9]+)$", "\\1", extra),
        name = sub("__SV_[A-Za-z0-9]+$", "", extra),
        response_count = NA_integer_
      )
    )
  }

  ## ---- Per-survey facts read from DISK (source of truth for this run) ----
  survey_facts <- lapply(seq_len(nrow(surveys)), function(i) {
    s <- surveys[i, ]
    folder <- paste0(safe_folder_name(s$name), "__", s$id)
    fdir <- file.path(account_root, folder)
    present <- file.exists(file.path(fdir, SURVEY_ARTIFACT_FILES))
    n_present <- sum(present)

    auditable <- NA_integer_
    md_path <- file.path(fdir, "metadata.json")
    if (file.exists(md_path)) {
      md <- tryCatch(jsonlite::fromJSON(md_path, simplifyVector = FALSE),
                     error = function(e) NULL)
      ## responsecounts arrives as a data.frame and serializes as a
      ## one-element ARRAY - unwrap before reading auditable.
      rc <- if (is.list(md)) md$responsecounts else NULL
      if (is.list(rc) && is.null(names(rc)) && length(rc) >= 1) rc <- rc[[1]]
      a <- if (is.list(rc)) rc$auditable else NULL
      if (!is.null(a)) auditable <- as.integer(a)
    }

    resp_files <- c("responses_numeric.rds", "responses_numeric.csv",
                    "responses_labels.csv", "responses_labels.xlsx",
                    "display_order.csv")
    non_resp_ok <- all(present[!(SURVEY_ARTIFACT_FILES %in% resp_files)])

    status <- if (n_present == length(SURVEY_ARTIFACT_FILES)) {
      "complete"
    } else if (!is.na(auditable) && auditable == 0 && non_resp_ok) {
      "no responses (structure saved)"
    } else {
      sprintf("partial (%d/%d files)", n_present, length(SURVEY_ARTIFACT_FILES))
    }
    list(folder = folder, auditable = auditable, status = status,
         complete = n_present == length(SURVEY_ARTIFACT_FILES),
         has_docx = present[SURVEY_ARTIFACT_FILES == "preview.docx"],
         has_xlsx = present[SURVEY_ARTIFACT_FILES == "responses_labels.xlsx"])
  })

  css <- "
    body { font-family: Poppins, 'Segoe UI', Tahoma, Arial, sans-serif;
           max-width: 1150px; margin: 1.5em auto; padding: 0 1em;
           color: #202124; background: #fafafa; }
    h1 { font-size: 1.5em; border-bottom: 3px solid #24365f;
         padding-bottom: 0.3em; }
    .runinfo { background: #eef2fb; border-radius: 6px; padding: 0.6em 1em;
               font-size: 0.92em; color: #24365f; }
    .warn { color: #b3261e; font-weight: 600; }
    input.search { font: inherit; font-size: 0.95em; padding: 8px 12px;
                   width: 340px; max-width: 100%; border: 1px solid #bbb;
                   border-radius: 6px; margin: 12px 0; }
    table.idx { border-collapse: collapse; width: 100%; background: #fff;
                box-shadow: 0 1px 4px rgba(0,0,0,0.12); font-size: 0.92em; }
    table.idx th { background: #24365f; color: #fff; text-align: start;
                   padding: 9px 12px; cursor: pointer; user-select: none; }
    table.idx td { padding: 8px 12px; border-bottom: 1px solid #eee;
                   vertical-align: top; }
    table.idx tr:hover td { background: #f4f7ff; }
    td.num { text-align: center; font-variant-numeric: tabular-nums; }
    .status-ok { color: #137333; }
    .status-empty { color: #6d6e71; }
    .status-partial { color: #b3261e; font-weight: 600; }
    a { color: #0b57d0; text-decoration: none; }
    a:hover { text-decoration: underline; }
    code { background: #f1f3f4; padding: 1px 5px; border-radius: 3px;
           font-size: 0.85em; }
    details.glossary { background: #fff; border: 1px solid #ddd;
           border-radius: 6px; padding: 0.8em 1.2em; margin: 1.2em 0; }
    details.glossary summary { cursor: pointer; font-weight: 600;
           color: #24365f; }
    details.glossary dt { font-weight: 600; margin-top: 0.7em; }
    details.glossary dd { margin: 0.15em 0 0 1.2em; color: #3c4043; }
    .foot { color: #6d6e71; font-size: 0.85em; margin: 1.5em 0; }
  "

  ## Inline JS: search filter + click-to-sort on the Name / Responses columns.
  js <- "
    function idxFilter() {
      var q = document.getElementById('idx-search').value.toLowerCase();
      var rows = document.querySelectorAll('table.idx tbody tr');
      rows.forEach(function(r) {
        r.style.display =
          r.getAttribute('data-name').indexOf(q) > -1 ? '' : 'none';
      });
    }
    var idxAsc = {};
    function idxSort(col, numeric) {
      var tb = document.querySelector('table.idx tbody');
      var rows = Array.from(tb.querySelectorAll('tr'));
      idxAsc[col] = !idxAsc[col];
      rows.sort(function(a, b) {
        var va = a.children[col].getAttribute('data-sort') ||
                 a.children[col].textContent;
        var vb = b.children[col].getAttribute('data-sort') ||
                 b.children[col].textContent;
        if (numeric) { va = parseFloat(va) || -1; vb = parseFloat(vb) || -1;
                       return idxAsc[col] ? va - vb : vb - va; }
        return idxAsc[col] ? va.localeCompare(vb) : vb.localeCompare(va);
      });
      rows.forEach(function(r) { tb.appendChild(r); });
    }
  "

  rows <- lapply(seq_len(nrow(surveys)), function(i) {
    s <- surveys[i, ]
    fx <- survey_facts[[i]]
    folder <- fx$folder
    resp_disp <- if (is.na(fx$auditable)) "?" else fx$auditable
    ## URL-encode the folder for hrefs: Hebrew, spaces, #, % in survey names
    ## all break plain relative links.
    href_to <- function(folder, file) {
      paste(utils::URLencode(folder, reserved = TRUE), file, sep = "/")
    }
    status_class <- if (fx$complete) "status-ok"
      else if (startsWith(fx$status, "no responses")) "status-empty"
      else "status-partial"

    htmltools::tags$tr(`data-name` = tolower(s$name),
      htmltools::tags$td(dir = "auto", s$name),
      htmltools::tags$td(htmltools::tags$code(s$id)),
      htmltools::tags$td(class = "num", `data-sort` = resp_disp, resp_disp),
      htmltools::tags$td(class = status_class, fx$status),
      htmltools::tags$td(
        htmltools::tags$a(href = href_to(folder, "preview.html"),
                          target = "_blank",
                          title = "The questionnaire as respondents saw it",
                          "preview"),
        if (isTRUE(fx$has_docx)) htmltools::tagList(" | ",
          htmltools::tags$a(href = href_to(folder, "preview.docx"),
                            title = "Same preview as a Word document", "Word")),
        " | ",
        htmltools::tags$a(href = href_to(folder, "responses_numeric.csv"),
                          title = "Answers as numbers - for SPSS/R/Excel",
                          "data (numbers)"),
        if (isTRUE(fx$has_xlsx)) htmltools::tagList(" | ",
          htmltools::tags$a(href = href_to(folder, "responses_labels.xlsx"),
                            title = "Answers as the text respondents clicked - opens in Excel",
                            "data (labels)")),
        " | ",
        htmltools::tags$a(href = href_to(folder, "codebook.csv"),
                          title = "Which number means which answer",
                          "codebook"),
        " | ",
        htmltools::tags$a(href = href_to(folder, "survey.qsf"),
                          title = "Re-import this file into Qualtrics to restore the survey",
                          "QSF"),
        " | ",
        htmltools::tags$a(href = href_to(folder, "survey_portable.json"),
                          target = "_blank",
                          title = "Open-format structure for rebuilding on another platform",
                          "portable")
      )
    )
  })

  glossary <- htmltools::tags$details(class = "glossary",
    htmltools::tags$summary(
      "What is each file? (click to open - written for someone who knows almost nothing)"),
    htmltools::tags$dl(
      htmltools::tags$dt("preview.html"),
      htmltools::tags$dd("The questionnaire as respondents saw it - questions, answer options, page breaks. Opens in any browser, no internet needed. A button at the top shows technical details (question IDs, answer codes)."),
      htmltools::tags$dt("preview.docx"),
      htmltools::tags$dd("The same questionnaire preview as a Word document - convenient to print or send to a colleague."),
      htmltools::tags$dt("responses_numeric.csv / .rds"),
      htmltools::tags$dd("The collected answers, coded as numbers (e.g. 1 = strongly disagree). One row per respondent. The .csv opens in Excel/SPSS; the .rds is the same data in R's native format."),
      htmltools::tags$dt("responses_labels.csv / .xlsx"),
      htmltools::tags$dd("The same answers, but as the TEXT the respondent actually clicked (e.g. 'strongly disagree' instead of 1). The .xlsx version opens cleanly in Excel, including Hebrew."),
      htmltools::tags$dt("survey.qsf"),
      htmltools::tags$dd("Qualtrics' own survey file (QSF = Qualtrics Survey Format). This is the file that brings the questionnaire BACK to life: in Qualtrics choose Create New Project > Survey > Import a QSF file, select this file, and you get a working editable copy of the survey."),
      htmltools::tags$dt("survey_definition.json"),
      htmltools::tags$dd("The complete raw survey structure exactly as Qualtrics stores it internally. Technical and lossless - the ultimate reference if any question ever arises about how the survey was built."),
      htmltools::tags$dt("survey_portable.json"),
      htmltools::tags$dd("The survey structure translated into a simple, open, platform-neutral format. Use it to rebuild the survey on a different platform (REDCap, LimeSurvey, a custom website)."),
      htmltools::tags$dt("questions.csv / .xlsx"),
      htmltools::tags$dd("A simple table: one row per question, with its text, type, and answer options. The fastest way to scan what the survey asked."),
      htmltools::tags$dt("codebook.csv / .xlsx"),
      htmltools::tags$dd("A table with one row per ANSWER OPTION: which number in the data file means which answer text. Essential when analyzing the numeric data."),
      htmltools::tags$dt("metadata.json"),
      htmltools::tags$dd("Housekeeping facts: how many responses, survey language, creation and modification dates."),
      htmltools::tags$dt("display_order.csv"),
      htmltools::tags$dd("For surveys that randomize question or answer order: records what order each respondent actually saw."),
      htmltools::tags$dt("migration_notes.md"),
      htmltools::tags$dd("A plain-text list of Qualtrics-specific features in this survey (piped text, custom JavaScript, branch logic) that would need manual attention if you rebuild the survey on another platform."),
      htmltools::tags$dt("_errors.log"),
      htmltools::tags$dd("Only exists if something went wrong during the backup - says exactly what failed and why.")
    )
  )

  head_tag <- htmltools::tags$head(
    htmltools::tags$meta(charset = "UTF-8"),
    htmltools::tags$title(sprintf("Qualtrics Backup: %s (%s)",
                                  account_name, run_date)),
    htmltools::tags$style(htmltools::HTML(css)),
    htmltools::tags$script(htmltools::HTML(js))
  )

  body_tag <- htmltools::tags$body(
    htmltools::tags$h1(sprintf("Qualtrics Backup: %s", account_name)),
    htmltools::tags$div(class = "runinfo",
      sprintf("Run date: %s | Surveys backed up: %d ok / %d failed | Total: %d",
              run_date, n_ok, n_fail, nrow(surveys))),
    htmltools::tags$p(
      "This folder is a complete, self-contained backup of every questionnaire ",
      "and every response in this Qualtrics account. Everything works offline; ",
      "nothing here needs Qualtrics, an internet connection, or a login."),
    htmltools::tags$p(class = "warn",
      HTML("&#9888; This folder contains participant data. Treat per IRB / privacy obligations.")),
    glossary,
    htmltools::tags$input(id = "idx-search", class = "search",
      type = "search", onkeyup = "idxFilter()",
      placeholder = "Search surveys by name..."),
    htmltools::tags$table(class = "idx",
      htmltools::tags$thead(
        htmltools::tags$tr(
          htmltools::tags$th(onclick = "idxSort(0,false)",
                             title = "Click to sort", "Survey name"),
          htmltools::tags$th("ID"),
          htmltools::tags$th(onclick = "idxSort(2,true)",
                             title = "Click to sort", "Responses"),
          htmltools::tags$th("Backup status"),
          htmltools::tags$th("Open")
        )
      ),
      htmltools::tags$tbody(rows)
    ),
    htmltools::tags$p(class = "foot",
      "See README.md in this folder for the full manual. ",
      "Generated by the Qualtrics Backup Tool.")
  )

  html_doc <- paste0(
    "<!DOCTYPE html>\n<html lang=\"en\">\n",
    htmltools::doRenderTags(head_tag), "\n",
    htmltools::doRenderTags(body_tag), "\n",
    "</html>\n"
  )
  con <- file(file.path(account_root, "_index.html"), open = "w",
              encoding = "UTF-8")
  writeLines(html_doc, con = con)
  close(con)
  invisible(NULL)
}


#' Write a master index.html at the BACKUP ROOT listing every account and
#' every dated run (newest first). One entry point for the whole archive.
write_master_index <- function(backup_root) {
  if (!dir.exists(backup_root)) return(invisible(NULL))
  accounts <- list.dirs(backup_root, recursive = FALSE, full.names = FALSE)
  entries <- list()
  for (acct in accounts) {
    dates <- list.dirs(file.path(backup_root, acct),
                       recursive = FALSE, full.names = FALSE)
    dates <- dates[grepl("^20[0-9]{2}-[0-9]{2}-[0-9]{2}$", dates)]
    if (length(dates) == 0) next
    for (d in sort(dates, decreasing = TRUE)) {
      n_surveys <- length(grep("__SV_", list.dirs(
        file.path(backup_root, acct, d), recursive = FALSE), value = TRUE))
      entries[[length(entries) + 1]] <- list(
        account = acct, date = d, n = n_surveys,
        latest = identical(d, max(dates)))
    }
  }
  if (length(entries) == 0) return(invisible(NULL))

  rows <- lapply(entries, function(e) {
    href <- paste(utils::URLencode(e$account, reserved = TRUE), e$date,
                  "_index.html", sep = "/")
    htmltools::tags$tr(
      htmltools::tags$td(e$account),
      htmltools::tags$td(htmltools::tags$a(href = href, e$date),
        if (e$latest) htmltools::tags$span(
          style = "color:#137333;font-size:0.85em;margin-inline-start:8px;",
          "latest")),
      htmltools::tags$td(style = "text-align:center;", e$n)
    )
  })

  head_tag <- htmltools::tags$head(
    htmltools::tags$meta(charset = "UTF-8"),
    htmltools::tags$title("Qualtrics Backups - all accounts"),
    htmltools::tags$style(htmltools::HTML("
      body { font-family: Poppins, 'Segoe UI', Arial, sans-serif;
             max-width: 760px; margin: 2em auto; padding: 0 1em;
             color: #202124; }
      h1 { border-bottom: 3px solid #24365f; padding-bottom: 0.3em; }
      table { border-collapse: collapse; width: 100%; }
      th { background: #24365f; color: #fff; text-align: start;
           padding: 8px 12px; }
      td { padding: 7px 12px; border-bottom: 1px solid #eee; }
      a { color: #0b57d0; }
    "))
  )
  body_tag <- htmltools::tags$body(
    htmltools::tags$h1("Qualtrics Backups"),
    htmltools::tags$p("Every backed-up account and run. Click a date to open that backup's index."),
    htmltools::tags$table(
      htmltools::tags$thead(htmltools::tags$tr(
        htmltools::tags$th("Account"), htmltools::tags$th("Backup date"),
        htmltools::tags$th("Surveys"))),
      htmltools::tags$tbody(rows)
    )
  )
  html_doc <- paste0("<!DOCTYPE html>\n<html lang=\"en\">\n",
                     htmltools::doRenderTags(head_tag), "\n",
                     htmltools::doRenderTags(body_tag), "\n</html>\n")
  con <- file(file.path(backup_root, "index.html"), open = "w",
              encoding = "UTF-8")
  writeLines(html_doc, con = con)
  close(con)
  invisible(NULL)
}


#' Write the per-account README.md (the auto-generated legend).
write_readme <- function(account_name, run_date, n_attempted, n_ok, n_fail,
                         account_root) {
  ## Pull session info so future-readers know exactly which package versions
  ## produced this backup. Helpful if a re-import script behaves differently.
  si <- sessionInfo()
  pkg_versions <- vapply(c("qualtRics", "httr", "jsonlite", "htmltools"),
    function(p) tryCatch(as.character(packageVersion(p)),
                         error = function(e) "(not installed)"),
    character(1))

  lines <- c(
    sprintf("# Qualtrics Backup - %s - %s", account_name, run_date),
    "",
    "## What this folder is",
    "",
    sprintf("This is a complete backup of Qualtrics account **%s**, captured on",
            account_name),
    sprintf("**%s**. It contains %d surveys (%d successful, %d failed).",
            run_date, n_attempted, n_ok, n_fail),
    "",
    "The goal is platform independence: every artifact here is in an open or",
    "human-readable format so the data and questionnaires survive even if",
    "Qualtrics goes away or you migrate to a different platform.",
    "",
    "## IMPORTANT - Sensitive data warning",
    "",
    "This folder contains participant response data including potentially",
    "personally identifying information. Handle per your IRB protocol and",
    "institutional privacy obligations. Do not share publicly without review.",
    "",
    "## What's in each survey folder",
    "",
    "| File | What it is | When to use it |",
    "|---|---|---|",
    "| `responses_numeric.rds` | Response data, numeric values, R-native | Statistical analysis in R |",
    "| `responses_numeric.csv` | Same, as CSV (UTF-8 with BOM for Excel) | Sharing or analysis outside R |",
    "| `responses_labels.csv` | Response data with choice labels substituted | Reading what respondents actually saw |",
    "| `survey_definition.json` | Full Qualtrics survey definition (raw) | Lossless source of truth - parse for anything |",
    "| `survey.qsf` | Qualtrics editable format | Re-import into Qualtrics (Create New > Import Survey) |",
    "| `responses_labels.xlsx` | Same labeled data as native Excel | Opening in Excel with Hebrew / long text |",
    "| `questions.csv` / `.xlsx` | One row per question (text, type, options, flags) - built locally from the QSF | Quick scan of question IDs and text |",
    "| `codebook.csv` / `.xlsx` | One row per answer option: which data value means which label | Cross-referencing values <-> labels |",
    "| `metadata.json` | Response counts, language, dates | Audit / verification |",
    "| `display_order.csv` | Per-respondent randomization info | Reconstructing what each person saw |",
    "| `preview.html` | Standalone Qualtrics-look survey preview | Reading the questionnaire in any browser, forever |",
    "| `preview.docx` | The same preview as a Word document | Printing / sending to a colleague |",
    "| `survey_portable.json` | Open-schema platform-neutral export | Rebuilding the survey on a different platform |",
    "| `migration_notes.md` | Qualtrics-specific features that won't port cleanly | Planning a migration |",
    "",
    "## Account-level files",
    "",
    "- `_index.csv` - machine-readable list of all surveys",
    "- `_index.html` - clickable mini-site for browsing this backup",
    "- `_errors.log` - per-survey failures (if any)",
    "",
    "## How to restore a survey",
    "",
    "**Back into Qualtrics:** From the Qualtrics homepage choose Create New",
    "Project > Survey > Import a QSF file > pick the survey's `survey.qsf`.",
    "",
    "**To another platform (REDCap, LimeSurvey, custom):** Use",
    "`survey_portable.json` (open schema) + `responses_labels.csv`. The schema",
    "is documented in PROJECT.md. Read `migration_notes.md` first - it lists",
    "Qualtrics-specific features that need manual handling.",
    "",
    "## How to verify this backup is intact",
    "",
    "1. Open `_index.html` in a browser - confirm all surveys are listed.",
    "2. Open one `preview.html` and confirm it renders.",
    "3. Open one `responses_numeric.csv` and confirm row count matches Qualtrics.",
    "4. Optional: re-import one `survey.qsf` into a sandbox Qualtrics project.",
    "",
    "## Reproducibility - tools used to generate this backup",
    "",
    sprintf("- R version: %s", si$R.version$version.string),
    sprintf("- qualtRics: %s", pkg_versions["qualtRics"]),
    sprintf("- httr: %s", pkg_versions["httr"]),
    sprintf("- jsonlite: %s", pkg_versions["jsonlite"]),
    sprintf("- htmltools: %s", pkg_versions["htmltools"]),
    sprintf("- OS: %s %s", si$running %||% "(unknown)", ""),
    sprintf("- Generated by: qualtrics_backup.R (see PROJECT.md)"),
    ""
  )
  con <- file(file.path(account_root, "README.md"), open = "w",
              encoding = "UTF-8")
  writeLines(lines, con = con)
  close(con)
}


## ==== 13. Optional encryption ==============================================

#' Tar + openssl-encrypt an account folder.
#'
#' @param folder_path Character. The folder to encrypt.
#' @param passphrase  Character. The AES-256 passphrase. If NULL or empty and
#'   an interactive session exists, we fall back to askpass::askpass(). Shiny
#'   always supplies the passphrase explicitly.
#' @param on_log      Optional log callback (see log_it).
#' @return Invisible NULL. Side effect: creates <folder>.tar.enc.
encrypt_folder <- function(folder_path, passphrase = NULL, on_log = NULL) {
  ## Guard: the `openssl` package is optional. We load it here rather than at
  ## the top of the script so users who never encrypt don't need to install it.
  if (!requireNamespace("openssl", quietly = TRUE)) {
    log_it(on_log, "danger",
           "Encryption requires the 'openssl' R package - install it first.")
    return(invisible(NULL))
  }

  log_it(on_log, "info", "Encrypting backup folder...")

  ## If no passphrase was supplied, prompt interactively (CLI path only).
  if (is.null(passphrase) || !nzchar(passphrase)) {
    if (interactive() && requireNamespace("askpass", quietly = TRUE)) {
      passphrase <- askpass::askpass("Passphrase for encryption: ")
    } else {
      log_it(on_log, "danger",
             "No passphrase supplied and no interactive prompt available.")
      return(invisible(NULL))
    }
  }

  tar_path <- paste0(folder_path, ".tar")
  enc_path <- paste0(folder_path, ".tar.enc")

  ## Build a compressed tar of the folder first. NOTE: the tar briefly
  ## exists unencrypted on disk (and in any cloud-sync version history if
  ## the backup root is synced) - we delete it below, but true at-rest
  ## secrecy requires an unsynced backup root.
  utils::tar(tarfile = tar_path, files = folder_path, compression = "gzip")

  ## AES-256-CBC with the passphrase's SHA-256 as the key. The IV is
  ## generated explicitly and PREPENDED to the output file - an earlier
  ## version let openssl pick a random IV and then never persisted it,
  ## which made every archive undecryptable.
  raw <- readBin(tar_path, what = "raw", n = file.info(tar_path)$size)
  iv  <- openssl::rand_bytes(16)
  enc <- openssl::aes_cbc_encrypt(
    raw,
    key = openssl::sha256(charToRaw(passphrase)),
    iv  = iv
  )
  con <- file(enc_path, open = "wb")
  writeBin(iv, con)                # first 16 bytes of the file = IV
  writeBin(as.raw(enc), con)       # then the ciphertext
  close(con)

  ## Remove the unencrypted tar (the original folder is still on disk - the
  ## caller is responsible for deciding whether to remove it).
  file.remove(tar_path)

  log_it(on_log, "success", sprintf("Encrypted to %s", enc_path))
  log_it(on_log, "info",
         "To decrypt: decrypt_folder('<file>.tar.enc', 'passphrase') from this library.")
  invisible(NULL)
}

#' Decrypt an archive produced by encrypt_folder(): the file's first 16
#' bytes are the IV, the rest is the AES-256-CBC ciphertext. Writes the
#' decrypted .tar next to the .enc file.
#'
#' @param enc_path Character. Path to the .tar.enc file.
#' @param passphrase Character. The same passphrase used to encrypt.
#' @return Character. Path of the restored .tar (invisibly).
decrypt_folder <- function(enc_path, passphrase) {
  if (!requireNamespace("openssl", quietly = TRUE)) {
    stop("Decryption requires the 'openssl' R package.", call. = FALSE)
  }
  bytes <- readBin(enc_path, what = "raw", n = file.info(enc_path)$size)
  if (length(bytes) <= 16) stop("File too short to be a valid archive.",
                                call. = FALSE)
  iv  <- bytes[1:16]
  enc <- bytes[-(1:16)]
  dec <- openssl::aes_cbc_decrypt(
    enc,
    key = openssl::sha256(charToRaw(passphrase)),
    iv  = iv
  )
  tar_path <- sub("\\.enc$", "", enc_path)
  writeBin(as.raw(dec), tar_path)
  invisible(tar_path)
}


## ==== 14. Main entry point =================================================

#' Run the backup for every configured account. Prints a summary at the end.
main <- function() {
  cli::cli_h1("Qualtrics backup - run started {format(Sys.time())}")

  ## Loop accounts (sequentially - keeps logs readable, avoids token mixing).
  ## Each iteration logs its own progress and aggregates a result row.
  results <- purrr::imap(ACCOUNTS, function(cfg, name) {
    tryCatch(
      backup_account(name, cfg),
      error = function(e) {
        cli::cli_alert_danger("Account {name} aborted: {conditionMessage(e)}")
        list(surveys_attempted = NA, surveys_ok = NA, surveys_failed = NA,
             errors_log = NA_character_, fatal_error = conditionMessage(e))
      }
    )
  })

  ## Final summary table.
  cli::cli_h1("Summary")
  for (name in names(results)) {
    r <- results[[name]]
    if (!is.null(r$fatal_error)) {
      cli::cli_alert_danger("{name}: FATAL - {r$fatal_error}")
    } else {
      cli::cli_alert_success(
        "{name}: {r$surveys_ok}/{r$surveys_attempted} surveys ok, {r$surveys_failed} failed"
      )
      if (!is.na(r$errors_log)) {
        cli::cli_alert_info("  Errors logged in: {r$errors_log}")
      }
    }
  }

  invisible(results)
}


## ==== 15. Run it ===========================================================
## When this script is sourced or run with Rscript, execute main().
## You can also source the file and call main() yourself, or call
## backup_account("ISF", ACCOUNTS$ISF) for a single-account run.
if (sys.nframe() == 0L) {
  main()
}
