#!/bin/bash
# ===========================================================
#  Qualtrics Backup - "Do I have R?" checker (Mac / Linux)
# ===========================================================
#  Double-click this file (Mac) or run it from a terminal.
#  It tells you clearly whether R is installed.
# ===========================================================

cd "$(dirname "$0")"

echo ""
echo "============================================================"
echo "  Checking whether R is installed on this computer..."
echo "============================================================"
echo ""

if command -v Rscript >/dev/null 2>&1; then
    echo "============================================================"
    echo "  YES - R is installed. You are ready!"
    echo "============================================================"
    echo ""
    Rscript --version
    echo ""
    echo "  Next step: double-click 'Run Me (Mac-Linux).command'"
    echo "  (the first run installs R packages - 2 to 5 minutes)."
else
    echo "============================================================"
    echo "  NO - R is NOT installed on this computer."
    echo "============================================================"
    echo ""
    echo "  Opening the R download page in your browser now."
    echo "  Install R, then double-click 'Run Me (Mac-Linux).command'."
    if [[ "$OSTYPE" == "darwin"* ]]; then
        open "https://cran.r-project.org/bin/macosx/"
    else
        xdg-open "https://cran.r-project.org/" 2>/dev/null || true
    fi
fi

echo ""
read -p "Press Enter to close..."
