@echo off
REM ===========================================================
REM  Qualtrics Backup - Windows one-click launcher
REM ===========================================================
REM  Double-click this file. It:
REM    1. Goes to the folder this script lives in.
REM    2. Finds Rscript on your machine (checks PATH + common
REM       R install locations under Program Files).
REM    3. If R is missing, opens the download page.
REM    4. Runs run_app.R. The Shiny app auto-installs any missing
REM       R packages on first run, then launches in your browser.
REM ===========================================================

setlocal enableextensions enabledelayedexpansion

REM Navigate to the folder this .cmd file is in (so relative paths work).
cd /d "%~dp0"

echo.
echo ============================================================
echo   Qualtrics Backup - starting...
echo ============================================================
echo   Folder: %CD%
echo.

REM ---- Try to locate Rscript.exe ------------------------------
set "RSCRIPT="

REM (1) Already on PATH?
where Rscript.exe >nul 2>&1
if not errorlevel 1 (
    set "RSCRIPT=Rscript.exe"
    goto :found
)

REM (2) Scan common R install locations under Program Files / Program Files (x86).
for /d %%D in ("C:\Program Files\R\R-*") do (
    if exist "%%D\bin\x64\Rscript.exe" (
        set "RSCRIPT=%%D\bin\x64\Rscript.exe"
        goto :found
    )
    if exist "%%D\bin\Rscript.exe" (
        set "RSCRIPT=%%D\bin\Rscript.exe"
        goto :found
    )
)
for /d %%D in ("C:\Program Files (x86)\R\R-*") do (
    if exist "%%D\bin\Rscript.exe" (
        set "RSCRIPT=%%D\bin\Rscript.exe"
        goto :found
    )
)

REM ---- R not found: send the user to the download page --------
echo.
echo ============================================================
echo  R is NOT installed on this computer.
echo ============================================================
echo.
echo  Please download and install R from:
echo    https://cran.r-project.org/
echo.
echo  (Opening the page in your browser now...)
echo.
echo  After installing R, close this window and double-click
echo  "Run Me (Windows).cmd" again.
echo.
start "" "https://cran.r-project.org/"
pause
exit /b 1

:found
echo   Using R at: !RSCRIPT!
echo.

REM ---- Sanity check: are the app files actually here? ---------
REM If you double-click this file WHILE STILL INSIDE THE ZIP (Windows lets
REM you browse into a .zip like a folder and open files from it), Windows
REM silently copies out ONLY this .cmd to a temp folder to run it -
REM run_app.R and friends are never there. On this kind of machine, R then
REM fails on the missing file with NO error text at all (a silent crash),
REM so without this check the user just sees "App stopped." and nothing
REM else. Catch it here with a clear message instead.
if not exist "run_app.R" (
    echo ============================================================
    echo   Cannot find run_app.R next to this file.
    echo ============================================================
    echo.
    echo   This usually means the ZIP was not extracted - you opened
    echo   it and ran this file directly from inside the ZIP.
    echo.
    echo   Fix: close this window, right-click qualtrics_backup_shiny.zip,
    echo   choose "Extract All...", open the EXTRACTED folder, and
    echo   double-click "Run Me (Windows).cmd" from there.
    echo.
    echo   Folder Windows actually ran this from:
    echo     %CD%
    echo ============================================================
    pause
    exit /b 1
)

echo   First run will install R packages (2-5 minutes).
echo   After that, launches are instant.
echo ============================================================
echo.

REM ---- Launch the Shiny app -----------------------------------
"!RSCRIPT!" run_app.R

REM Keep the window open so any error messages stay visible.
echo.
echo ============================================================
echo   App stopped.
echo ============================================================
pause
endlocal
