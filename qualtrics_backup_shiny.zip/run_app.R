## ===========================================================================
## run_app.R
## ---------------------------------------------------------------------------
## Starts the Qualtrics backup Shiny app with safe settings:
##   - Binds to 127.0.0.1 only (localhost). The app is NEVER reachable from
##     the network, even if you're on a shared Wi-Fi.
##   - Launches the system browser to the app URL.
##   - Uses a stable port (default 4975 - unused by common services); override
##     by setting the APP_PORT env var before running.
##
## Usage
## -----
##   From R console:     source("run_app.R")
##   From terminal:      Rscript run_app.R
##
## Stop the app: Ctrl+C in the R console, or close the R session.
##
## Security
## --------
## Host-binding to 127.0.0.1 is the single most important safety setting: it
## ensures that your typed API token stays on your own machine even if the
## machine is on a coffee-shop network. DO NOT change host to "0.0.0.0" or
## any external IP unless you fully understand what that exposes.
## ===========================================================================


## ---- Ensure dependencies are installed (auto-install if missing) ---------
## The recipient shouldn't need a separate install step. If any required
## package is missing, we install it from CRAN on the fly. Only the first
## run touches the network; subsequent runs are instant.
##
## Covers the full dependency surface of app.R + qualtrics_backup.R including
## Word export (officer + flextable).
required <- c("shiny", "qualtRics", "httr", "jsonlite", "tibble", "dplyr",
              "purrr", "readr", "cli", "htmltools", "fs",
              "officer", "flextable", "writexl")

missing <- required[!vapply(required, function(p) {
  requireNamespace(p, quietly = TRUE)
}, logical(1))]

if (length(missing) > 0) {
  cat("\nFirst-run setup: installing", length(missing),
      "R packages from CRAN.\nThis happens ONCE per machine and may take",
      "a few minutes...\n\n")
  ## Vanilla non-interactive Rscript has NO default CRAN mirror and
  ## install.packages() would die with "trying to use CRAN without setting
  ## a mirror". Point at the cloud mirror when none is configured.
  repos <- getOption("repos")
  if (is.null(repos) || identical(unname(repos["CRAN"]), "@CRAN@") ||
      is.na(repos["CRAN"])) {
    options(repos = c(CRAN = "https://cloud.r-project.org"))
  }
  install.packages(missing)

  ## Re-check. If anything still failed, fail loudly with guidance.
  still_missing <- missing[!vapply(missing, function(p) {
    requireNamespace(p, quietly = TRUE)
  }, logical(1))]
  if (length(still_missing) > 0) {
    stop(
      "Could not install: ", paste(still_missing, collapse = ", "),
      "\nPlease install manually:\n",
      "  install.packages(c(",
      paste(shQuote(still_missing), collapse = ", "), "))\n",
      "Check your CRAN mirror / internet / write permissions to your R library.",
      call. = FALSE
    )
  }
  cat("\nAll packages ready. Launching app...\n\n")
}


## ---- Config ---------------------------------------------------------------
## Port: 4975 by default (arbitrary high port unlikely to clash).
## Override with APP_PORT env var if 4975 is already in use on your machine.
.app_port <- as.integer(Sys.getenv("APP_PORT", unset = "4975"))
if (is.na(.app_port) || .app_port < 1024 || .app_port > 65535) {
  stop("APP_PORT must be an integer between 1024 and 65535.", call. = FALSE)
}

## ---- Locate the script's own folder (robust across RStudio/Rscript/source) --
## We need app.R + qualtrics_backup.R to be findable as relative paths from
## Shiny's runApp. If we can't identify the folder, we fall back to getwd()
## and hope the user sourced from the right directory.
.script_dir <- tryCatch({
  if (requireNamespace("rstudioapi", quietly = TRUE) &&
      rstudioapi::isAvailable()) {
    ## RStudio: use the source editor path or the active document.
    ctx <- rstudioapi::getSourceEditorContext()
    if (!is.null(ctx$path) && nzchar(ctx$path)) {
      dirname(normalizePath(ctx$path))
    } else {
      getwd()
    }
  } else if (sys.nframe() > 0L) {
    ## source() from R console: sys.frame(1)$ofile holds the script path.
    this_file <- sys.frame(1)$ofile
    if (!is.null(this_file) && nzchar(this_file)) {
      dirname(normalizePath(this_file))
    } else {
      getwd()
    }
  } else {
    ## Rscript run_app.R: commandArgs has the file path.
    args <- commandArgs(trailingOnly = FALSE)
    file_arg <- grep("^--file=", args, value = TRUE)
    if (length(file_arg) > 0) {
      dirname(normalizePath(sub("^--file=", "", file_arg[1])))
    } else {
      getwd()
    }
  }
}, error = function(e) getwd())

## Change to the script dir so Shiny can find app.R + qualtrics_backup.R via
## relative paths inside app.R (source("qualtrics_backup.R", local = FALSE)).
setwd(.script_dir)


## ---- Banner ---------------------------------------------------------------
cat("\n")
cat("===========================================================\n")
cat("  Qualtrics backup - Shiny app\n")
cat("===========================================================\n")
cat(sprintf("  URL:   http://127.0.0.1:%d\n", .app_port))
cat(sprintf("  Dir:   %s\n", .script_dir))
cat("  Host:  localhost only (safe - not reachable from network)\n")
cat("  Stop:  Ctrl+C in this console, or close the browser tab\n")
cat("===========================================================\n\n")


## ---- Launch --------------------------------------------------------------
## Literal "127.0.0.1" inline (NOT a variable) to avoid any lazy-eval issue
## where Shiny might re-evaluate the host arg in a different scope later.
shiny::runApp(
  appDir = .script_dir,
  host   = "127.0.0.1",
  port   = .app_port,
  launch.browser = TRUE,
  display.mode = "normal",
  quiet = FALSE
)
