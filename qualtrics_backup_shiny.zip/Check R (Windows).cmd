@echo off
REM ===========================================================
REM  Qualtrics Backup - "Do I have R?" checker (Windows)
REM ===========================================================
REM  Double-click this file. It looks for R in the same places
REM  the launcher does and tells you clearly YES or NO.
REM ===========================================================

setlocal enableextensions enabledelayedexpansion
cd /d "%~dp0"

echo.
echo ============================================================
echo   Checking whether R is installed on this computer...
echo ============================================================
echo.

set "RSCRIPT="

REM (1) Already on PATH?
where Rscript.exe >nul 2>&1
if not errorlevel 1 (
    set "RSCRIPT=Rscript.exe"
    goto :found
)

REM (2) Common install locations under Program Files.
for /d %%D in ("C:\Program Files\R\R-*") do (
    if exist "%%D\bin\x64\Rscript.exe" (
        set "RSCRIPT=%%D\bin\x64\Rscript.exe"
        goto :found
    )
    if exist "%%D\bin\Rscript.exe" (
        set "RSCRIPT=%%D\bin\Rscript.exe"
        goto :found
    )
)
for /d %%D in ("C:\Program Files (x86)\R\R-*") do (
    if exist "%%D\bin\Rscript.exe" (
        set "RSCRIPT=%%D\bin\Rscript.exe"
        goto :found
    )
)

echo ============================================================
echo   NO - R is NOT installed on this computer.
echo ============================================================
echo.
echo   Opening the R download page in your browser now.
echo   Install R (click Next, Next, Next - defaults are fine),
echo   then double-click "Run Me (Windows).cmd".
echo.
start "" "https://cran.r-project.org/bin/windows/base/"
pause
exit /b 1

:found
echo ============================================================
echo   YES - R is installed. You are ready!
echo ============================================================
echo.
"!RSCRIPT!" --version 2>nul
echo.
echo   Next step: double-click "Run Me (Windows).cmd"
echo   (the first run installs R packages - 2 to 5 minutes).
echo.
pause
endlocal
