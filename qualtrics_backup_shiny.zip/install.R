## Install every R package the Shiny backup app needs.
## Run this ONCE per machine: source("install.R")

required <- c(
  ## Shiny UI
  "shiny",
  ## Qualtrics + HTTP
  "qualtRics", "httr", "jsonlite",
  ## Data wrangling
  "tibble", "dplyr", "purrr", "readr",
  ## UI helpers
  "cli", "htmltools", "fs",
  ## Word + Excel export
  "officer", "flextable", "writexl"
)

missing <- required[!vapply(required, function(p) {
  requireNamespace(p, quietly = TRUE)
}, logical(1))]

if (length(missing) == 0) {
  cat("\nAll packages already installed. You can run:\n  source(\"run_app.R\")\n\n")
} else {
  cat("\nInstalling:", paste(missing, collapse = ", "), "\n\n")
  ## Vanilla Rscript has no default CRAN mirror - point at the cloud one.
  repos <- getOption("repos")
  if (is.null(repos) || identical(unname(repos["CRAN"]), "@CRAN@") ||
      is.na(repos["CRAN"])) {
    options(repos = c(CRAN = "https://cloud.r-project.org"))
  }
  install.packages(missing)

  ## Re-check after install.
  still_missing <- missing[!vapply(missing, function(p) {
    requireNamespace(p, quietly = TRUE)
  }, logical(1))]
  if (length(still_missing) > 0) {
    cat("\nSome packages failed to install:",
        paste(still_missing, collapse = ", "),
        "\nPlease install them manually.\n")
  } else {
    cat("\nDone. You can now run:\n  source(\"run_app.R\")\n\n")
  }
}
