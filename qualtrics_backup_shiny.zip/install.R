## Install every R package the Shiny backup app needs.
## Run this ONCE per machine: source("install.R")

required <- c(
  ## Shiny UI
  "shiny",
  ## Qualtrics + HTTP
  "qualtRics", "httr", "jsonlite",
  ## Data wrangling
  "tibble", "dplyr", "purrr", "readr",
  ## UI helpers
  "cli", "htmltools", "fs",
  ## Word + Excel export
  "officer", "flextable", "writexl"
)

## ---- Make sure there is a WRITABLE package library ------------------------
## R's default library sits next to the R installation itself (e.g.
## "C:/Program Files/R/R-4.6.1/library"). If R was installed "for all users",
## that folder is admin-owned - install.packages() then fails outright
## ("is not writable" / "unable to install packages") under Rscript, which
## never gets the interactive "use a personal library instead?" prompt.
## Point at the user's own per-version library first, creating it if needed.
.user_lib <- Sys.getenv("R_LIBS_USER")
if (!nzchar(.user_lib)) {
  .user_lib <- file.path(
    Sys.getenv("USERPROFILE", unset = Sys.getenv("HOME")),
    "AppData", "Local", "R", "win-library",
    paste(R.version$major, strsplit(R.version$minor, "\\.")[[1]][1], sep = ".")
  )
}
if (!dir.exists(.user_lib)) {
  dir.create(.user_lib, recursive = TRUE, showWarnings = FALSE)
}
if (dir.exists(.user_lib)) {
  .libPaths(c(.user_lib, .libPaths()))
}

missing <- required[!vapply(required, function(p) {
  requireNamespace(p, quietly = TRUE)
}, logical(1))]

if (length(missing) == 0) {
  cat("\nAll packages already installed. You can run:\n  source(\"run_app.R\")\n\n")
} else {
  cat("\nInstalling:", paste(missing, collapse = ", "), "\n\n")
  ## Vanilla Rscript has no default CRAN mirror - point at the cloud one.
  repos <- getOption("repos")
  if (is.null(repos) || identical(unname(repos["CRAN"]), "@CRAN@") ||
      is.na(repos["CRAN"])) {
    options(repos = c(CRAN = "https://cloud.r-project.org"))
  }
  .install_lib <- if (dir.exists(.user_lib)) .user_lib else .libPaths()[1]
  install.packages(missing, lib = .install_lib)

  ## Re-check after install.
  still_missing <- missing[!vapply(missing, function(p) {
    requireNamespace(p, quietly = TRUE)
  }, logical(1))]
  if (length(still_missing) > 0) {
    cat("\nSome packages failed to install:",
        paste(still_missing, collapse = ", "),
        "\nPlease install them manually.\n")
  } else {
    cat("\nDone. You can now run:\n  source(\"run_app.R\")\n\n")
  }
}
