# Qualtrics Backup Tool

> **The friendly way to start: double-click `START_HERE.html`** - a guided
> page with download links, an "is R installed?" check, and a live button
> that opens the tool once it is running. This file covers the same ground
> in plain text.

Back up **everything** from your Qualtrics account to your own computer:
every questionnaire (as it looks in Qualtrics, restorable into Qualtrics) and
every response (as numbers for analysis and as readable text). Everything is
saved in open formats that will still open in 20 years, with no Qualtrics, no
internet, and no login.

**Written for someone who knows almost nothing - start here.**

---

## מדריך מהיר בעברית (Quick start in Hebrew)

1. **מתקינים R** (חד פעמי): מורידים מ- https://cran.r-project.org ומתקינים כרגיל.
2. **לוחצים פעמיים** על `Run Me (Windows).cmd` (או `Run Me (Mac-Linux).command` במק).
   בהרצה הראשונה יותקנו חבילות R אוטומטית (2-5 דקות). אחר כך נפתח דפדפן עם הכלי.
3. **משיגים טוקן** (מפתח גישה אישי) מקוולטריקס: מתחברים לקוולטריקס בדפדפן,
   לוחצים על האייקון של המשתמש (למעלה מימין) > Account Settings > בצד
   Qualtrics IDs > בקופסה **API** לוחצים Generate Token ומעתיקים.
   הטוקן הוא כמו סיסמה - לא שולחים אותו במייל ולא משתפים.
4. **מדביקים את הטוקן** בכלי, לוחצים "Test connection", מסמנים אילו שאלונים
   לגבות (ברירת המחדל: הכל), ולוחצים "Start backup".
5. **בסוף** נפתחת תיקיה עם כל הגיבוי. פותחים את הקובץ `_index.html` בדפדפן -
   הוא מציג את כל השאלונים עם קישורים לכל הקבצים, כולל מילון מונחים שמסביר
   מה זה כל קובץ.
6. **בסוף הלוג** מופיע סיכום תשובות (RESPONSE BACKUP SUMMARY) שאומר בדיוק
   לאילו שאלונים התשובות גובו, לאילו לא היו תשובות בכלל (תקין), ואילו עדיין
   מחכים בקוולטריקס (נשמר גם כקובץ `_responses_summary.txt` בתיקיית הגיבוי).
   אפשר תמיד להריץ שוב על אותה תיקיית גיבוי - שאלונים שכבר הושלמו מדולגים
   אוטומטית, ורק מה שחסר מנוסה שוב.

הכלי **רק קורא** מקוולטריקס. הוא אף פעם לא משנה ולא מוחק שום דבר בחשבון.

---

## What you need (once)

1. **R** - a free statistics program. Download from https://cran.r-project.org
   and install with all the default choices. You never need to open R itself.
2. **A Qualtrics API token** - a personal access key. See the next section.

That's it. No other software.

## Getting your API token (2 minutes)

An API token is a long string of letters and numbers that lets this tool read
the surveys of **your** Qualtrics account. It is like a password: do not email
it, do not share it. The tool keeps it only in memory while running - it is
never written to any file.

1. Log into Qualtrics in your browser.
2. Click your account icon (top-right corner) and choose **Account Settings**.
3. In the left sidebar click **Qualtrics IDs**.
4. Find the box named **API**. If a token is shown, copy it. Otherwise click
   **Generate Token**, then copy it.
5. Paste it into the app when asked.

*No "Generate Token" button?* Your institution's Qualtrics administrator must
enable API access for your account - ask them.

**Your base URL:** the app also asks for your Qualtrics server address. Look
at your browser's address bar while logged into Qualtrics - it looks like
`something.qualtrics.com` (for example `biusocialsciences.eu.qualtrics.com`).
Type that part, without `https://`.

## Running a backup

1. Double-click **`Run Me (Windows).cmd`** (Windows) or
   **`Run Me (Mac-Linux).command`** (Mac/Linux).
   - First run: R packages install automatically (2-5 minutes, one time).
   - A browser tab opens with the tool (it runs only on YOUR computer -
     nobody on the network can reach it).
2. Paste your token, check the base URL, click **Test connection & list surveys**.
3. Pick which surveys to back up (all are selected by default; there is a
   search box for long lists).
4. Choose where to save (default: a "Qualtrics Backups" folder in your home
   directory) and click **Start backup**.
5. Watch the live log. It ends with a **RESPONSE BACKUP SUMMARY** telling
   you, survey by survey, whose responses are safely backed up, which surveys
   had no responses to begin with (fine), and which still have data waiting in
   Qualtrics (also saved as `_responses_summary.txt` in the backup folder).
   When it finishes, click **Open output folder**.
6. Need to run again (after a failure, or just to be safe)? Run it on the
   SAME backup folder - surveys that are already complete are skipped
   automatically (resume), and only the missing pieces are retried.

## What you get

For every survey, a folder with (among others):

| File | What it is |
|---|---|
| `preview.html` | The questionnaire as respondents saw it - opens in any browser, looks like Qualtrics, works offline. Starts with a **Survey Flow** section (what appeared to whom), then the questions. A button shows technical info (question IDs, answer codes). |
| `preview.docx` | The same preview as a Word document (including the Survey Flow section). |
| `survey_flow.json` | The survey's FLOW, exactly as Qualtrics stores it - every branch, condition, randomizer, embedded-data assignment, quota, and end-of-survey point. This is the lossless copy. |
| `survey_flow.txt` | The same flow, written out in plain language and indented so you can read it: e.g. "Branch 'Consent Decline': if answer to Q3 is selected choice 2 -> End of survey". This is "who saw what". |
| `display_logic.csv` | One row per question that only appeared under a condition (or triggered a skip), with the condition spelled out. |
| `responses_numeric.csv` / `.rds` | The answers as numbers - for SPSS / R / Excel. One row per respondent. |
| `responses_labels.csv` / `.xlsx` | The answers as the TEXT respondents clicked. The .xlsx opens cleanly in Excel, including Hebrew. |
| `survey.qsf` | **The restore file.** QSF = Qualtrics Survey Format. In Qualtrics: Create New Project > Survey > Import a QSF file - and your survey is back, editable, even if the original was deleted. |
| `codebook.csv` / `.xlsx` | Which number in the data means which answer. |
| `questions.csv` / `.xlsx` | One row per question - a quick way to scan the survey. |
| `survey_portable.json` | The survey in a simple open format, for rebuilding outside Qualtrics (REDCap, LimeSurvey...). |
| `migration_notes.md` | Qualtrics-specific features (piped text, branching, JavaScript) that need manual attention if you rebuild elsewhere. |
| `NO_RESPONSES.txt` | Appears instead of the response files when the survey simply has zero recorded responses. Nothing was lost - there was nothing to download. |
| `MISSING_RESPONSES_README.txt` | Appears ONLY if the response download failed. It says what is missing, how many responses exist in Qualtrics, and what to do (usually: the survey is owned by another account - back it up with the owner's token). |

Plus, per backup run: **`_index.html`** - a clickable page listing every
survey with links to everything and a full plain-language glossary - a
**`_responses_summary.txt`** report saying exactly which surveys' responses
are backed up, which had none to begin with, and which still have data
waiting in Qualtrics - and a master `index.html` at the backup root listing
all your accounts and runs.

## Safety, in one paragraph

The tool is **read-only** against Qualtrics: it can never modify, create, or
delete anything in your account. Your token lives only in the app's memory
while the browser tab is open - it is never saved to disk, never logged, and
you can wipe it any time with "Clear token from session". The app is reachable
only from your own computer (localhost). The backup folder contains your
participants' data - treat it according to your IRB / privacy obligations
(it stays entirely on your computer; nothing is uploaded anywhere).

## Troubleshooting

| Problem | Fix |
|---|---|
| Double-click opens then closes | Install R first: https://cran.r-project.org |
| "Connection failed: Unauthorized" | Wrong token or wrong base URL - re-copy both. |
| Browser does not open | Open http://127.0.0.1:4975 manually. |
| Hebrew looks wrong in Excel | Open the `.xlsx` files (not the .csv), or import the CSV as UTF-8. |
| A survey shows "partial" in the index | See `_errors.log` in the backup folder for the exact reason, then run the backup again (it resumes - already-finished surveys are skipped). |
| A survey folder has no `responses_...` files | Look inside the folder. `NO_RESPONSES.txt` = the survey has zero responses; nothing was lost. `MISSING_RESPONSES_README.txt` = the download failed - open it for the exact reason and the fix, then re-run on the same backup folder (finished surveys are skipped). |

---

Built by Elad Refoua (Bar-Ilan University) + Claude. Free to use and share.
Questions: eladrefoua@gmail.com
